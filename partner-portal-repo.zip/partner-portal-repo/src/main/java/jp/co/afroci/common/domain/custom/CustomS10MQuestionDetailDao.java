package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10MQuestionDetail;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10MQuestionDetailDao {

    /**
     * @param questionId
     * @return the S10MQuestionDetail entity
     */
    @Select
    List<S10MQuestionDetail> selectAll(String questionId);

}