package jp.co.afroci.common.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;

/**
 * Dto, Entityデータコピー
 */
public class DataCopyUtil {

	private static BeanUtilsBean utilsBean;

	static {
		ConvertUtilsBean convert = new ConvertUtilsBean();
		utilsBean = new BeanUtilsBean(convert);
	}

	/**
	 * データコピー
	 *
	 * @param dest
	 *            コピー先
	 * @param orig
	 *            コピー元
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	public static <D> D copyEntity(Map<String, Object> orig, Class<D> d) {
		D dest = newConstInstance(d);
        try {
			for (Field field : d.getFields()) {
				field.setAccessible(true);
				String strFiled = "";
				Object objFiled = orig.get(field.getName());
				if (objFiled != null) {
					if (objFiled.getClass().getName().equals(Integer.class.getName())) {
						strFiled = String.valueOf(objFiled);
					} else {
						strFiled = (String) objFiled;
					}
				}
				String typeName = field.getType().getName();
				if (typeName.equals(String.class.getName())) {
					field.set(dest, strFiled);
				} else if (typeName.equals(LocalDate.class.getName())) {
					if (!strFiled.equals("")) {
						field.set(dest, LocalDate.parse(strFiled));
					}
				} else if (typeName.equals(BigDecimal.class.getName())) {
					if (!strFiled.equals("")) {
						field.set(dest, new BigDecimal(strFiled));
					}
				} else if (typeName.equals(LocalDateTime.class.getName())) {
					if (!strFiled.equals("")) {
						field.set(dest, LocalDateTime.parse(strFiled));
					}
				} else if (typeName.equals(Integer.class.getName())) {
					if (!strFiled.equals("")) {
						field.set(dest, Integer.parseInt(strFiled));
					}
				} else {
					field.set(dest, strFiled);
				}
			}
		} catch (IllegalArgumentException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return dest;
	}

	/**
	 * データコピー
	 *
	 * @param dest
	 *            コピー先
	 * @param orig
	 *            コピー元
	 */
	public static Object copy(Object orig, Object dest) {
		if (orig == null) {
			return new NullPointerException("orig");
		}
		if (dest == null) {
			return new NullPointerException("dest");
		}
		try {
			utilsBean.copyProperties(dest, orig);
		} catch (IllegalAccessException | InvocationTargetException e) {
			throw new IllegalArgumentException("Failed to copy the properties from " + orig + " to " + dest, e);
		}
		return dest;
	}

	/**
	 * 異なるクラスのデータコピー
	 * @param <D>
	 *
	 * @param dest
	 *            コピー先
	 * @param orig
	 *            コピー元
	 * @return
	 */
	public static <D> D copyTo(Object orig, Class<D> d) {
		D dest = newConstInstance(d);
		copy(orig, dest);
		return dest;
	}

	private static <T> T newConstInstance(Class<T> clazz) {
		try {
			Constructor<T> constructor = clazz.getDeclaredConstructor();
			constructor.setAccessible(true);
			return constructor.newInstance();
		} catch (NoSuchMethodException | InstantiationException
				| IllegalAccessException| InvocationTargetException e) {
			throw new IllegalArgumentException("Failed to create and initialize a new instance of the specified class " + clazz, e);
		}
	}
}