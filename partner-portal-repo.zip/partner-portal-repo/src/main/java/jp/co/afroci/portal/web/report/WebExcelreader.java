package jp.co.afroci.portal.web.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.afroci.common.service.AbstractService;


/**
 * Excelのサービスのスーパークラス.
 *
 * @author Gao Jiayi.
 */
public abstract class WebExcelreader {

	/** ワークブック. */
	public XSSFWorkbook wkBook;
	/** セル. */
    protected List<ExcelCellConst> cells;
    /** 汎用サービス */
    protected AbstractService service;


    /** サービス. */
	/**
	 * コンストラクタ.
	 * @throws Exception
	 * */
	public WebExcelreader(String file_path) throws Exception {
		// セル定義初期化
		this.cells = new ArrayList<ExcelCellConst>();

		// POIのワークブック生成
		File file = new File(file_path);
		if (file.exists()) {
			// POIのワークブック生成
			FileInputStream in = new FileInputStream(file);
			this.wkBook = new XSSFWorkbook(in);
		}
	}


	/**
	 * ファイル書込.
	 *
	 * @param シート名
	 *  */
	protected void write(String sheetName) throws IOException {
		// シート取得
		XSSFSheet sheet = this.getSheet(sheetName);
		// 各設定項目の値セット
		for (int i = 0; i <  this.cells.size(); i++) {
			ExcelCellConst cell = this.cells.get(i);
			// 行存在しなければ、新規作成
			XSSFRow r = sheet.getRow(cell.row);
			if (r == null) r = sheet.createRow(cell.row);
			// セル存在しなければ、新規作成
			XSSFCell c = r.getCell(cell.col);
			if (c == null) c = r.createCell(cell.col);
			// セル値設定
			c.setCellValue(cell.val);
		}
		// 再計算実施
		sheet.setForceFormulaRecalculation(true);
	};

	protected 	XSSFSheet getSheet(String sheetName) {
		// シート取得
		return this.wkBook.getSheet(sheetName);
	}

	/**
	 * 指定した範囲のセルをコピーする。
	 *
	 * @param copyRowStart    開始行
	 * @param copyColStart 開始列
	 * @param copyRowEnd    終了行
	 * @param copyColEnd 終了列
	 * @param startRow    貼り付け行
	 * @param startColumn 貼り付け列
	 */
	protected void copyStyle(String sheetName, final int copyRow0, final int copyColumn0, final int copyRow1,
			final int copyColumn1, final int startRow, final int startColumn) {
		XSSFSheet sheet = this.getSheet(sheetName);
		// 結合の設定
		for (int i = 0; i < sheet.getNumMergedRegions(); i++) {
			CellRangeAddress merged = sheet.getMergedRegion(i);
			if (merged.getFirstRow() >= copyRow0 && merged.getFirstRow() <= copyRow1 && merged.getLastColumn() >= copyColumn0 && merged.getLastColumn() <= copyColumn1) {
				int moveRows = startRow - copyRow0;
				int moveCols = startColumn - copyColumn0;
				CellRangeAddress newMaerged = new CellRangeAddress(moveRows + merged.getFirstRow(),
						moveRows + merged.getLastRow(),
						moveCols + merged.getFirstColumn(),
						moveCols + merged.getLastColumn());
				try {
					sheet.addMergedRegion(newMaerged);
				} catch (Exception e) {
					// コピー失敗する分をスルー
				}
			}
		}
		// セルコピー
		for (int i = 0; copyRow0 + i <= copyRow1; i++) {
			for (int j = 0; copyColumn0 + j <= copyColumn1; j++) {
				// コピー元
				Cell srcCell = this.getCell(sheet, copyRow0 + i, copyColumn0 + j);
				// コピー先
				Cell destCell = this.getCell(sheet, startRow + i, startColumn + j);
				// スタイルをコピー
				destCell.setCellStyle(cloneCellStyle(srcCell.getCellStyle()));
				// 行の高さをコピー
				destCell.getRow().setHeight(srcCell.getRow().getHeight());
			}
		}
	}

	protected void printArea(int cnt) {
		if (cnt > 1) {
			this.wkBook.setPrintArea(
					//印刷範囲を設定するシートのインデックス
					0,
					//印刷範囲開始位置のカラムのインデックス
					0,
					//印刷範囲終了位置のカラムのインデックス
					35,
					//印刷範囲開始位置の行のインデックス
					0,
					//印刷範囲終了位置の行のインデックス
					8 + cnt * 10);
		}
	}

	/**
	 * Cell を返す。
	 *
	 * @param row 行
	 * @param column 列
	 * @return Cell
	 */
	protected Cell getCell(XSSFSheet sheet, final int row, final int column) {
		return CellUtil.getCell(CellUtil.getRow(row, sheet), column);
	}

	/**
	 * セルの書式設定を複製します。
	 *
	 * @param originalStyle コピー元となるセルスタイル
	 * @return コピー先のセルスタイル
	 */
	private CellStyle cloneCellStyle(final CellStyle originalStyle) {
		CellStyle newStyle = this.wkBook.createCellStyle();
		newStyle.cloneStyleFrom(originalStyle);
		return newStyle;
	}

}
