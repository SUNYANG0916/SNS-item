package jp.co.afroci.portal.web.controller;

import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.afroci.common.dto.ApplyDto;

/**
 * アプリケーション共通コントローラ.
 */
@Controller
public class ApplyController extends AbstractBaseController {

    /**
     * アプリ画面表示.
     *
	 * @param request
	 * @param response
     * @return "user/userTop"
     */
    @RequestMapping(value = {"/user/apply"}, method = RequestMethod.GET)
    public String getApply(HttpServletRequest request, Model model) {

        // リクエストアプリケーションID
        String applyId = request.getParameter(ApplyDto.KEY_APPLY_ID);

        String param = "";
        // 引数
        Enumeration<String> names = request.getParameterNames();
        while (names.hasMoreElements()){
            String name = names.nextElement();
            if (param.equals("")) {
            	param += "?";
            } else {
            	param += "＆";
            }
            param += name + "=" + request.getParameter(name);
        }
        String context = request.getContextPath();
        // アプリケーションID
        model.addAttribute(ApplyDto.KEY_CONTEXT, context);
        // アプリケーションID
        model.addAttribute(ApplyDto.KEY_APPLY_ID, applyId);
        // アプリパス
        model.addAttribute(ApplyDto.KEY_CSJS, applyId + "/" + applyId);
        // パラメタを渡す
        model.addAttribute(ApplyDto.KEY_PARAMS, param);
        // パラメタを渡す
        if (super.settingsConfig.isDebug()) {
            model.addAttribute(ApplyDto.KEY_VERSION, String.valueOf((new Date()).getTime()));
        } else {
            model.addAttribute(ApplyDto.KEY_VERSION, super.settingsConfig.getVersion());
        }

        return "user/userTop";
    }
}
