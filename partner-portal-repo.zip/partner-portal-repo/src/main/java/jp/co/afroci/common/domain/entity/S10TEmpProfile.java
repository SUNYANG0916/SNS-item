package jp.co.afroci.common.domain.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * 社員基本情報
 * @author Afroci Co., Ltd.
 */

@Data
@Entity
@Table(name = "s10_t_emp_profile")
public class S10TEmpProfile {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 社員番号 */
    @Column(name = "emp_no")
    public String empNo;

    /** 入社年月日 */
    @Column(name = "nyusya_ymd")
    public LocalDate nyusyaYmd;

    /** 部署名 */
    @Column(name = "busyo_cd")
    public String busyoCd;

    /** 役職名 */
    @Column(name = "yakusyoku_kbn")
    public String yakusyokuKbn;

    /** 姓（漢字） */
    @Column(name = "kanji_sei")
    public String kanjiSei;

    /** 名（漢字） */
    @Column(name = "kanji_mei")
    public String kanjiMei;

    /** 姓（カナ） */
    @Column(name = "kana_sei")
    public String kanaSei;

    /** 名（カナ） */
    @Column(name = "kana_mei")
    public String kanaMei;

    /** 姓（英字） */
    @Column(name = "eiji_sei")
    public String eijiSei;

    /** 名（英字） */
    @Column(name = "eiji_mei")
    public String eijiMei;

    /** 生年月日 */
    @Column(name = "seinentukihi_ymd")
    public LocalDate seinentukihiYmd;

    /** 男性／女性 */
    @Column(name = "seibetu_kbn")
    public String seibetuKbn;

    /** A／B／AB／O */
    @Column(name = "ketuekigata_kbn")
    public String ketuekigataKbn;

    /** 日本国籍／外国 */
    @Column(name = "kokuseki_kbn")
    public String kokusekiKbn;

    /** 未婚／既婚 */
    @Column(name = "konyin_kbn")
    public String konyinKbn;

    /** １人目生年月日 */
    @Column(name = "kodomo_1_ymd")
    public LocalDate kodomo1Ymd;

    /** ２人目生年月日 */
    @Column(name = "kodomo_2_ymd")
    public LocalDate kodomo2Ymd;

    /** ３人目生年月日 */
    @Column(name = "kodomo_3_ymd")
    public LocalDate kodomo3Ymd;

    /** 郵便番号 */
    @Column(name = "post_no")
    public String postNo;

    /** 都道府県 */
    @Column(name = "todofuken_cd")
    public String todofukenCd;

    /** 市区郡以降 */
    @Column(name = "shikuchoson")
    public String shikuchoson;

    /** ビル名／部屋番号 */
    @Column(name = "birumei")
    public String birumei;

    /** 沿線名 */
    @Column(name = "ensen_cd")
    public String ensenCd;

    /** 駅名 */
    @Column(name = "eki")
    public String eki;

    /** メールアドレス */
    @Column(name = "mail")
    public String mail;

    /** メールアドレス（個人） */
    @Column(name = "mai_kojinl")
    public String maiKojinl;

    /** 固定電話 */
    @Column(name = "tel_kotei")
    public String telKotei;

    /** 携帯電話 */
    @Column(name = "tel_keitai")
    public String telKeitai;

    /** 希望通勤時間（H） */
    @Column(name = "tukin_jikan")
    public String tukinJikan;

    /** 日本語資格（N1 or N2 or N3） */
    @Column(name = "sikaku_nihongo_kbn")
    public String sikakuNihongoKbn;

    /** TOEIC/TOEFL */
    @Column(name = "toeic")
    public String toeic;

    /** 得意技術 */
    @Column(name = "tokui_gijutu_cd")
    public String tokuiGijutuCd;

    /** 得意工程 */
    @Column(name = "tokui_kotei_cd")
    public String tokuiKoteiCd;

    /** 自己アピール */
    @Column(name = "jiko_pr")
    public String jikoPr;

    /** 出張可否（国内） */
    @Column(name = "syucho_kokunai_kbn")
    public String syuchoKokunaiKbn;

    /** 出張可否（海外） */
    @Column(name = "syucho_kaigai_kbn")
    public String syuchoKaigaiKbn;

    /** 興味／趣味 */
    @Column(name = "kyomi_syumi")
    public String kyomiSyumi;

    /** 関係 */
    @Column(name = "kinkyu_kankei_kbn")
    public String kinkyuKankeiKbn;

    /** 氏名 */
    @Column(name = "kinkyu_shimei")
    public String kinkyuShimei;

    /** メールアドレス */
    @Column(name = "kinkyu_mail")
    public String kinkyuMail;

    /** 固定電話 */
    @Column(name = "kinkyu_tel_kotei")
    public String kinkyuTelKotei;

    /** 携帯電話 */
    @Column(name = "kinkyu_tel_keitai")
    public String kinkyuTelKeitai;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}