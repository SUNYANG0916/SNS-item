package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TKintaiMeisaiDao;
import jp.co.afroci.common.domain.entity.S11TKintaiMeisai;

@Service
public class AppKinmuMeisaiService extends AbstractService {

	@Autowired
	private S11TKintaiMeisaiDao dao;

	/**
	 * 新規登録.
	 */
	public int insert(S11TKintaiMeisai entity) {
		return dao.insert(entity);
	}

	/**
	 * 更新.
	 */
	public int update(S11TKintaiMeisai entity) {
		return dao.update(entity);
	}

	/**
	 * 削除.
	 */
	public int delete(S11TKintaiMeisai entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S11TKintaiMeisai getKinmuMeisaiDay(String userCd, String kintaiDate) {
		return dao.selectById(userCd, kintaiDate);
	}
	
	public List<S11TKintaiMeisai> getKinmuMeisaiMon(String userCd, String kintaiDate) {
		return (List<S11TKintaiMeisai>) dao.selectKinmuMeisaiMon(userCd, kintaiDate);
	}

}
