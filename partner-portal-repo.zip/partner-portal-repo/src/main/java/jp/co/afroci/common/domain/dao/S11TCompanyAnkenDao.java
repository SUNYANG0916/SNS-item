package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S11TCompanyAnken;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S11TCompanyAnkenDao {

    /**
     * @param userCd
     * @param companyId
     * @param businessId
     * @return the S11TCompanyAnken entity
     */
    @Select
    S11TCompanyAnken selectByMaxBusinessIdUserId(String userCd);
    
    /**
     * @param userCd
     * @param companyId
     * @param businessId
     * @return the S11TCompanyAnken entity
     */
    @Select
    S11TCompanyAnken selectById(String userCd,int companyId,int businessId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S11TCompanyAnken entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S11TCompanyAnken entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S11TCompanyAnken entity);
}