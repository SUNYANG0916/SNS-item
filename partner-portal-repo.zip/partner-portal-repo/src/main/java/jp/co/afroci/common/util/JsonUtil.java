package jp.co.afroci.common.util;

import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

/**
 * JsonUtil
 */
public class JsonUtil {

    private static ObjectMapper mapper = null;

    private Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    static {
        mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        mapper.registerModule(getEnumSimpleModule()).registerModule(new ParameterNamesModule())
        .registerModule(new Jdk8Module())
        .registerModule(new JavaTimeModule());
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        mapper.setDateFormat(format);

    }

    public static String toJson(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static String toJson(Object key, Object value) {
        Map<Object, Object> map = new HashMap<>();
        map.put(key, value);
        try {
            return mapper.writeValueAsString(map);
        } catch (JsonProcessingException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static String toFormJson(Object obj, boolean success) {
        Map<String, Object> map = new HashMap<>();
        map.put("success", success);
        map.put("data", obj);
        try {
            return mapper.writeValueAsString(map);
        } catch (JsonProcessingException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static String writePageJson(Object list, Object total) {
        Map<String, Object> map = new HashMap<>();
        map.put("list", list);
        map.put("total", total);
        try {
            return mapper.writeValueAsString(map);
        } catch (JsonProcessingException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static <T> T fromJson(String jsonString, Class<T> clazz) {
        if (!StringUtils.hasText(jsonString)) {
            return null;
        }
        try {
            return mapper.readValue(jsonString, clazz);
        } catch (IOException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static <T> T fromJsonType(String jsonString, TypeReference typeReference) {
        if (!StringUtils.hasText(jsonString)) {
            return null;
        }
        try {
            return mapper.readValue(jsonString, typeReference);
        } catch (IOException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * Collection to List<Bean>
     */
    public static <L extends Collection<E>, E> L fromJson(String jsonString,
                                                          Class<L> collectionClass,
                                                          Class<E> elementClass) {
        if (!StringUtils.hasText(jsonString)) {
            return null;
        }
        try {
            CollectionType type = mapper.getTypeFactory().constructCollectionType(collectionClass,
                    elementClass);
            return mapper.readValue(jsonString, type);
        } catch (Exception e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
            return null;
        }
    }

    public static void update(String jsonString, Object object) {
        try {
            mapper.readerForUpdating(object).readValue(jsonString);
        } catch (IOException e) {
            (new JsonUtil()).logger.error(e.getMessage(), e);
        }
    }

    public static String toJsonP(String functionName, Object object) {
        return toJson(new JSONPObject(functionName, object));
    }


    public static SimpleModule getEnumSimpleModule() {
        SimpleModule module = new SimpleModule();
        module.setDeserializerModifier(new BeanDeserializerModifier() {
            @Override
            public JsonDeserializer<Enum> modifyEnumDeserializer(DeserializationConfig config,
                                                                 final JavaType type,
                                                                 BeanDescription beanDesc,
                                                                 final JsonDeserializer<?> deserializer) {
                return new JsonDeserializer<Enum>() {
                    @Override
                    public Enum deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
                        Class rawClass =  type.getRawClass();

                        return getEnum(jp.getValueAsString(), rawClass);
                    }
                };
            }
        });

        return module;
    }

    private static <E extends Enum<E>> E getEnum(String enumStr, Class rawClass) {
        if (enumStr == null)
            return null;
        Class<E> enumClass = getGenericClass(rawClass);
        E[] objs = enumClass.getEnumConstants();
        try {

            for (E obj : objs) {
                if (obj.toString().equalsIgnoreCase(enumStr)) {
                    return obj;
                }
            }
        } catch (Exception e) {
            if ((new JsonUtil()).logger != null)
                (new JsonUtil()).logger.error(enumClass.getName() + "_" + e.getMessage(), e);
        }
        return null;
    }

    private static <E extends Enum<E>> Class<E> getGenericClass(Class rawClass) {
        Type genType = rawClass.getGenericSuperclass();
        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
        return (Class) params[0];
    }

    public static <T> List<T> decodeToList(String json, Class<T> t) throws IOException {
        final TypeFactory factory = mapper.getTypeFactory();
        final JavaType listOfT = factory.constructCollectionType(List.class, t);
        return mapper.readValue(json, listOfT);
    }

}