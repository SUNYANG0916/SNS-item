package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TWorkingReportDao;
import jp.co.afroci.common.domain.dao.S10TWorkingReportDao;
import jp.co.afroci.common.domain.entity.S10TWorkingReport;

/**
 * 作業報告情報を取り扱うService
 */
@Service
public class WorkingReportService extends AbstractService {

	@Autowired
	private S10TWorkingReportDao dao;
	@Autowired
	private CustomS10TWorkingReportDao customDao;

    /**
     * 主キー検索.
     */
    public S10TWorkingReport selectId(String userCd, String workingDate) {
        return dao.selectById(userCd, workingDate);
    }

	/**
	 * 新規登録
	 */
	public int insert(S10TWorkingReport entity) {
		return dao.insert((S10TWorkingReport) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TWorkingReport entity) {
		return dao.update((S10TWorkingReport) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TWorkingReport entity) {
		return dao.delete(entity);
	}

	/**
	 * ユーザの作業情報を検索.
	 */
	public List<S10TWorkingReport> selectByYM(String userCd, String workingMonth) {
		return customDao.selectByYM(userCd, workingMonth);
	}

}