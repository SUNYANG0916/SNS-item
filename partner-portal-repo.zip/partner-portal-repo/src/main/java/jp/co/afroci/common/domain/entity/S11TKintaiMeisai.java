package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 勤怠明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s11_t_kintai_meisai")
public class S11TKintaiMeisai {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 勤務日 */
    @Id
    @Column(name = "kintai_date")
    public String kintaiDate;

    /** 案件ＩＤ */
    @Column(name = "business_id")
    public Integer businessId;

    /** 更新日時回数 */
    @Column(name = "update_times")
    public Integer updateTimes;

    /** 勤務ステータス */
    @Column(name = "kintai_state")
    public Integer kintaiState;

    /** 勤務開始時間 */
    @Column(name = "duty_on_time")
    public String dutyOnTime;

    /** 勤務終了時間 */
    @Column(name = "duty_off_time")
    public String dutyOffTime;

    /** 勤怠時間 */
    @Column(name = "kinmu_time")
    public String kinmuTime;

    /** 休日判定フラグ */
    @Column(name = "holiday")
    public Integer holiday;

    /** 作業内容 */
    @Column(name = "re_marks")
    public String reMarks;

    /** 作成日時 */
    @Column(name = "insert_date")
    public LocalDateTime insertDate;

    /** 更新日時 */
    @Column(name = "last_update")
    public LocalDateTime lastUpdate;
}