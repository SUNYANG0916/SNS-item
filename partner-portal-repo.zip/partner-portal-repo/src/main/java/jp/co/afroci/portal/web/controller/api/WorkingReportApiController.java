package jp.co.afroci.portal.web.controller.api;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TWorkingReport;
import jp.co.afroci.common.service.WorkingReportService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * 作業報告情報コントローラ.
 */
@RestController
public class WorkingReportApiController extends AbstractApiController {

	@Autowired
	private WorkingReportService service;

	/**
	 * 作業情報初期化.
	 */
	@RequestMapping(value="/user/s20f007_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F007, request.getParameter("userRow"));
		applyObj.put("rtnApply", request.getParameter("rtnApply"));
		return JSON.encode(applyObj);
	}

	/**
	 * 作業情報検索.
	 */
	@RequestMapping(value="/user/s20f007_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String search(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_working_list", this.service.selectByYM(super.getTargetUserCd(), request.getParameter("workingMonth")));
		return JSON.encode(applyObj);
	}


	/**
	 * 作業情報詳細検索.
	 */
	@RequestMapping(value="/user/s20f007_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
		S10TWorkingReport detail = this.service.selectId(super.getTargetUserCd(), request.getParameter("workingDate"));

		applyObj.put("tbl_working_info", detail);

		return JSON.encode(applyObj);
	}

	/**
	 * 作業情報登録.
	 */
	@RequestMapping(value="/user/s20f007_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TWorkingReport inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		inEntity.userCd = super.getTargetUserCd();

		// 更新
		S10TWorkingReport entity = this.service.selectId(inEntity.userCd, inEntity.workingDate);
		if (entity == null) {
			// 新規
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;

			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}
		return JSON.encode(resutlObj);
	}

	/**
	 * 作業情報削除.
	 */
	@RequestMapping(value="/user/s20f007_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TWorkingReport dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getTargetUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

}
