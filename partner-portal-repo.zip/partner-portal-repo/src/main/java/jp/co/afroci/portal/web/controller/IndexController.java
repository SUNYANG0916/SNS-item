package jp.co.afroci.portal.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * ログイン
 */
@Controller
public class IndexController  extends AbstractBaseController  {

	/**
	 * 初期表示
	 *
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String index(HttpServletRequest request, HttpServletResponse response, Model model) {
		return "index";
	}

	/**
	 * ユーザログイン
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = { "/user/login" }, method = RequestMethod.GET)
	public String userLogin(HttpServletRequest request, HttpServletResponse response, Model model) {
    	HttpSession session = request.getSession();
    	String errorMessage = (String) session.getAttribute("errorMessage");
    	if(StringUtils.isNotEmpty(errorMessage)) {
    		model.addAttribute("errorMessage", errorMessage);
    		session.removeAttribute("errorMessage");
    	}

		return "user/userLogin";
	}

    /**
     * メニュー表示
     *
	 * @param request
	 * @param response
     * @return
     */
    @RequestMapping(value = {"/user/menu"}, method = RequestMethod.GET)
    public String postMenu(HttpServletRequest request, HttpServletResponse response, Model model) {
    	model.addAttribute("userName", getUserInfo().getUsername());
        return "user/userMenu";
    }

	/**
	 * timeout
	 *
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "/timeout" }, method = RequestMethod.POST)
	public String index(HttpServletRequest request, HttpServletResponse response) {
		return "timeout";
	}

}
