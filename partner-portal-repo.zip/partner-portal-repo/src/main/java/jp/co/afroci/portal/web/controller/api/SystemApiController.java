package jp.co.afroci.portal.web.controller.api;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.service.MenuService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * メニューコントローラ.
 */
@RestController
public class SystemApiController extends AbstractApiController {

    @Autowired
    private MenuService service;

	public SystemApiController() {
        super();
    }

    /**
     * 画面初期ロードリクエスト.
     */
    @RequestMapping(value="/user/s00f001_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S00F001, null);

        String userCd = super.getUserInfo().getUserCd();

        applyObj.put("list_menu_work_val", this.service.getMenuListMap("0", userCd));
        applyObj.put("list_menu_manager_val", this.service.getMenuListMap("1", userCd));
        applyObj.put("list_menu_seikyu_val", this.service.getMenuListMap("2", userCd));

        return JSON.encode(applyObj);
    }

}
