package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 宿泊詳細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s30_t_travel_lodging")
public class S30TTravelLodging {

    /** 請求書番号 */
    @Id
    @Column(name = "travel_no")
    public String travelNo;

    /** 行番号 */
    @Id
    @Column(name = "row_number")
    public Integer rowNumber;

    /** 宿泊地名 */
    @Column(name = "lodging_location")
    public String lodgingLocation;

    /** 項目 */
    @Column(name = "lodging_item")
    public String lodgingItem;

    /** 料金 */
    @Column(name = "amount")
    public BigDecimal amount;

    /** 割引 */
    @Column(name = "discount")
    public BigDecimal discount;

    /** オプション */
    @Column(name = "option")
    public String option;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}