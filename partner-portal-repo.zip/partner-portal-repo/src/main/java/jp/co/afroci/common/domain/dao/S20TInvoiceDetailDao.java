package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S20TInvoiceDetail;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S20TInvoiceDetailDao {

    /**
     * @param invoiceNo
     * @param rowNumber
     * @return the S20TInvoiceDetail entity
     */
    @Select
    S20TInvoiceDetail selectById(String invoiceNo, Integer rowNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S20TInvoiceDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S20TInvoiceDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S20TInvoiceDetail entity);
}