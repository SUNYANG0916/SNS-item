package jp.co.afroci.portal.web.controller;

import org.postgresql.util.PSQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractBaseController extends AbstractController {
	public Logger log = LoggerFactory.getLogger(AbstractApiController.class);

	/**
	 * コンストラクタ.
	 * */
	protected AbstractBaseController() {

	}

	@ExceptionHandler(PSQLException.class)
	public ModelAndView handleAllExceptions(PSQLException ex, WebRequest request, ModelAndView mav) {
		String msg = "システムデータベースが混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		mav.addObject("errorMessage", msg);
		mav.setViewName("error");
		return mav;
	}

	@ExceptionHandler(UsernameNotFoundException.class)
	public ModelAndView handleAllExceptions(UsernameNotFoundException ex, WebRequest request, ModelAndView mav) {
		String msg = "ログイン認証に失敗しました";
		mav.addObject("errorMessage", msg);
		mav.setViewName("error");
		return mav;
	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleAllExceptions(Exception ex, WebRequest request, ModelAndView mav) {
		String msg = "ただいま混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		mav.addObject("errorMessage", msg);
		mav.setViewName("error");
		return mav;
	}

	@ExceptionHandler(Throwable.class)
	public ModelAndView handleAllExceptions(Throwable ex, WebRequest request, ModelAndView mav) {
		String msg = "システムが混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		mav.addObject("errorMessage", msg);
		mav.setViewName("error");
		return mav;
	}
}
