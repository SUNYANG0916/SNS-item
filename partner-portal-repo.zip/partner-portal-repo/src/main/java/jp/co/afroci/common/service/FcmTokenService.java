package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TFcmTokenDao;
import jp.co.afroci.common.domain.entity.S11TFcmToken;

/**
 * メニュー取り扱うService
 */
@Service
public class FcmTokenService extends AbstractService {
	@Autowired
	private S11TFcmTokenDao dao;

	/**
	 * 全件検索.
	 */
	public List<S11TFcmToken> selectAll() {
		return dao.selectAll();
	}

	/**
	 * 主キー(ユーザ)検索.
	 */
	public S11TFcmToken selectId(String userCd) {
		return dao.selectById(userCd);
	}

	public int insert(S11TFcmToken entity) {
		return dao.insert(entity);
	}

	/**
	 * 更新登録.
	 */
	public int update(S11TFcmToken entity) {
		return dao.update(entity);
	}

}