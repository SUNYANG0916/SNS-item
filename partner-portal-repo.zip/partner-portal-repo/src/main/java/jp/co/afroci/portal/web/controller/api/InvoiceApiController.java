package jp.co.afroci.portal.web.controller.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10MPj;
import jp.co.afroci.common.domain.entity.S20TInvoice;
import jp.co.afroci.common.domain.entity.S20TInvoiceDetail;
import jp.co.afroci.common.dto.MasterEstimateDto;
import jp.co.afroci.common.service.EmpProjectService;
import jp.co.afroci.common.service.EstimateService;
import jp.co.afroci.common.service.InvoiceDetailService;
import jp.co.afroci.common.service.InvoiceService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import jp.co.afroci.portal.web.util.Constants.DELETE_FLAG;
import jp.co.afroci.portal.web.util.Constants.TAX_RATE;
import net.arnx.jsonic.JSON;


/**
 * 請求書マスタコントローラ.
 */
@RestController
public class InvoiceApiController extends AbstractApiController {

    @Autowired
    private InvoiceService service;

    @Autowired
    private EstimateService estimateService;

    @Autowired
    private EmpProjectService pjService;

    @Autowired
    private InvoiceDetailService invoiceDetailService;

    /** コンストラクタ. */
    public InvoiceApiController() {
        super();
    }

    /**
     * 画面初期ロードリクエスト.
     */
    @RequestMapping(value="/user/s30f003_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S30F003, null);
        // 項目マスタリスト取得対象
        String[][] items = {
                { Constants.ITEMS.ITEM_30030, "selKouzaType", "" ,""},
                { Constants.ITEMS.ITEM_30031, "selDelete", "", ""},
                { Constants.ITEMS.ITEM_30026, "selTaxType", "", ""}
        };
        this.service.setSelectItems(applyObj, items);

        return JSON.encode(applyObj);
    }

    /**
     * 請求書マスタ検索.
     */
    @RequestMapping(value="/user/s30f003_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();

        // キーワード検索条件
        String conditions = "%" + request.getParameter("cond") + "%";
        // 有効／失効（削除フラグ）
        String selDelete = request.getParameter("selDelete");
        String deleteFlag = null;
        if (selDelete.equals("30031-001")) {
            // 有効のみ
            deleteFlag = DELETE_FLAG.OFF;
        } else if (selDelete.equals("30031-002")) {
            // 失効のみ
            deleteFlag = DELETE_FLAG.ON;
        }

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (S20TInvoice entity : service.selectAll(conditions, deleteFlag)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("invoiceNo", entity.invoiceNo);
            map.put("matterName", entity.matterName);
            map.put("suppliersToName", entity.suppliersToName);
            map.put("amountTotal", entity.amountTotal);
            list.add(map);
        }
        applyObj.put("tbl_invoice_list", list);
        return JSON.encode(applyObj);
    }

    /**
     * 請求書明細検索.
     */
    @RequestMapping(value="/user/s30f003_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        List<Map<String, Object>> tbl_working_list = new ArrayList<Map<String, Object>>();
        String invoiceNo = request.getParameter("invoiceNo");
        // 請求データ
        S20TInvoice s20TInvoice = service.selectId(invoiceNo);

        applyObj.put("kouzaTypeNm", this.service.getItemName(s20TInvoice.kouzaType));
        applyObj.put("taxAmount", s20TInvoice.amountTotal.multiply(TAX_RATE.TAX_RATE_8));
        applyObj.put("tbl_invoice_list", s20TInvoice);

        // 請求明細データ
        BigDecimal amountTotal = BigDecimal.ZERO;
        for (S20TInvoiceDetail entity : invoiceDetailService.selectByInvoiceDetail(invoiceNo)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("invoiceNo", entity.invoiceNo);
            map.put("pjCd", entity.pjCd);
            map.put("pjNm", entity.pjNm);
            map.put("quantity", entity.quantity);
            map.put("unitPrice", entity.unitPrice);
            map.put("unitPriceNm", this.service.getItemName(entity.unitPrice));
            map.put("amount", entity.amount);
			amountTotal.add(entity.amount);
            map.put("deliveryDate", entity.deliveryDate);
            map.put("dueDate", entity.dueDate);
            map.put("workingInfo", entity.workingInfo);
            tbl_working_list.add(map);
        }
        // 明細リスト
        applyObj.put("tbl_working_list", tbl_working_list);
        // 金額合計
        applyObj.put("amountTotal", amountTotal);

        return JSON.encode(applyObj);
    }

    /**
     * 請求書マスタ登録.
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s30f003_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String update(@RequestBody S20TInvoice inEntity) {
        Map<String, Object> resultObj = new HashMap<String, Object>();
        resultObj.put("result", "ok");

        S20TInvoice entity = service.selectId(inEntity.invoiceNo);
        try {
            if (entity == null) {
                // 新規
                String suppliersNo = "000" + String.valueOf(service.selectSeq());
                inEntity.invoiceNo = "I" + suppliersNo.substring(suppliersNo.length() - 4);
                service.insert(inEntity);
                resultObj.put("msg", "登録処理が完了しました。");
            } else {
                // 更新
                inEntity.deleteFlg = entity.deleteFlg;
                service.update(inEntity);
                resultObj.put("msg", "更新処理が完了しました。");
            }
            resultObj.put("invoiceNo", inEntity.invoiceNo);
        } catch (IllegalArgumentException | SecurityException e) {
        	resultObj.put("msg", "処理失敗しました。");
        	resultObj.put("result", "error");
        }

        return JSON.encode(resultObj);
    }


    /**
     * 請求書明細登録.
     */
    @RequestMapping(value="/user/s30f003_updateDetails", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    private String updateUserRole(HttpServletRequest request, @RequestBody List<S20TInvoiceDetail> inEntitys) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");

        // 一括削除
        String invoiceNo = inEntitys.get(0).invoiceNo;
        for (S20TInvoiceDetail invoiceDetail : this.invoiceDetailService.selectByInvoiceDetail(invoiceNo)) {
            this.invoiceDetailService.delete(invoiceDetail);
        }

        // 一括登録
        for (S20TInvoiceDetail entity : inEntitys) {
            this.invoiceDetailService.insert(entity);
            resutlObj.put("msg", "登録処理が完了しました。");
        }
        return JSON.encode(resutlObj);
    }



    /**
     * 請求書マスタ論理削除.
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s30f003_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String delete(@RequestBody S20TInvoice inEntity) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");
        try {
            S20TInvoice entity = service.selectId(inEntity.invoiceNo);
            entity.deleteFlg = DELETE_FLAG.ON;
            service.update(entity);
            resutlObj.put("msg", "廃止処理が完了しました。");
        } catch (IllegalArgumentException | SecurityException e) {
            resutlObj.put("msg", "処理失敗しました。");
            resutlObj.put("result", "error");
        }

        return JSON.encode(resutlObj);
    }

    /**
     * 見積検索.
     */
    @RequestMapping(value="/user/s30f003_master_estimate", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterSuppliers(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        List<MasterEstimateDto> list = estimateService.selectMasterAll("%" + request.getParameter("cond") + "%", "0");
        applyObj.put("tbl_estimates_list", list);

        return JSON.encode(applyObj);
    }


    /**
     * プロジェクト検索.
     */
    @RequestMapping(value="/user/s30f003_master_project", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterProjects(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        String cond = "%" + request.getParameter("cond") + "%";

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (S10MPj s10MPj : pjService.selectAll(cond, DELETE_FLAG.OFF)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("pjCd", s10MPj.pjCd);
			map.put("pjNm", s10MPj.pjNm);
			map.put("unitPriceNm", this.service.getItemName(s10MPj.unitPrice));
			map.put("unitPrice", s10MPj.unitPrice);
			map.put("quantity", s10MPj.quantity);
			map.put("amount", s10MPj.amount);
			map.put("pjNote", s10MPj.pjNote);
			list.add(map);
		}
        applyObj.put("tbl_project_list", list);

        return JSON.encode(applyObj);
    }
}
