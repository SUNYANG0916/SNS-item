package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MUserRoles;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS00MUserRolesDao {

    /**
     * @return the S00MUserRoles entity
     */
    @Select
    List<S00MUserRoles> selectAll();

    /**
     * @return the S00MUserRoles entity
     */
    @Select
    List<S00MUserRoles> selectByUserCd(String userCd);
}