package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 請求書
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s20_t_invoice")
public class S20TInvoice {

    /** 請求書番号 */
    @Id
    @Column(name = "invoice_no")
    public String invoiceNo;

    /** 見積書番号 */
    @Column(name = "estimate_no")
    public String estimateNo;

    /** 見積書名称 */
    @Column(name = "estimate_name")
    public String estimateName;

    /** 請求先取引先コード */
    @Column(name = "suppliers_to_no")
    public String suppliersToNo;

    /** 請求先取引先名称 */
    @Column(name = "suppliers_to_name")
    public String suppliersToName;

    /** 請求元取引先コード */
    @Column(name = "suppliers_from_no")
    public String suppliersFromNo;

    /** 請求元取引先名称 */
    @Column(name = "suppliers_from_name")
    public String suppliersFromName;

    /** 代表者 */
    @Column(name = "pepresentative")
    public String pepresentative;

    /** 郵便番号 */
    @Column(name = "postal_code")
    public String postalCode;

    /** 住所（都道府県） */
    @Column(name = "address_1")
    public String address1;

    /** 住所（市区町村） */
    @Column(name = "address_2")
    public String address2;

    /** 住所（番地以降） */
    @Column(name = "address_3")
    public String address3;

    /** ビル名／部屋 */
    @Column(name = "address_4")
    public String address4;

    /** 電話 */
    @Column(name = "tel")
    public String tel;

    /** 代表Fax */
    @Column(name = "fax")
    public String fax;

    /** 件名 */
    @Column(name = "matter_name")
    public String matterName;

    /** 内容 */
    @Column(name = "matter_info")
    public String matterInfo;

    /** 作業期間_開始日 */
    @Column(name = "start_date")
    public LocalDate startDate;

    /** 作業期間_終了日 */
    @Column(name = "end_date")
    public LocalDate endDate;

    /** 振込先銀行コード */
    @Column(name = "ginko_cd")
    public String ginkoCd;

    /** 振込先銀行名 */
    @Column(name = "ginko_mei")
    public String ginkoMei;

    /** 支店番号 */
    @Column(name = "shiten_no")
    public String shitenNo;

    /** 支店名 */
    @Column(name = "shiten_mei")
    public String shitenMei;

    /** 口座区分 */
    @Column(name = "kouza_type")
    public String kouzaType;

    /** 口座名 */
    @Column(name = "kouza_mei")
    public String kouzaMei;

    /** 口座番号 */
    @Column(name = "kouza_no")
    public String kouzaNo;

    /** 金額合計 */
    @Column(name = "amount_total")
    public BigDecimal amountTotal;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}