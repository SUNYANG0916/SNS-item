package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 項目マスタ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s00_m_item")
public class S00MItem {

    /** 項目タイプ */
    @Id
    @Column(name = "item_type")
    public String itemType;

    /** 項目コード */
    @Id
    @Column(name = "item_cd")
    public String itemCd;

    /** 項目値 */
    @Column(name = "item_val")
    public String itemVal;

    /** 項目テキスト */
    @Column(name = "item_txt")
    public String itemTxt;

    /** 項目備考 */
    @Column(name = "item_note")
    public String itemNote;

    /** ソート */
    @Column(name = "item_sort")
    public Integer itemSort;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}