package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.dto.WorkingListDto;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TWorkingDetailDao {

    /**
     * @param userCd
     * @return the S10TEmpEduc entity
     */
    @Select
    List<WorkingListDto> selectByUserCd(String userCd);

    /**
     * @param userCd
     * @return the S10TEmpEduc entity
     */
    @Select
    List<WorkingListDto> selectByYM(String userCd, String workingMonth);

}