package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TEmpEduc;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.service.EmpEducService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * 学歴情報コントローラ.
 */
@RestController
public class EmpEducApiController extends AbstractApiController {

	@Autowired
	private EmpEducService service;

	/**
	 * 学歴情報初期化.
	 */
	@RequestMapping(value="/user/s20f002_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F002, request.getParameter("userRow"));

		// 項目マスタリスト取得対象
		String[][] items = {{Constants.ITEMS.ITEM_10001,"selItSkilKbn", "" ,""}};
		this.service.setSelectItems(applyObj, items);
		// リスト初期表示
        applyObj.put("tbl_educ_list", this.getList());

		return JSON.encode(applyObj);
	}

	/**
	 * 学歴情報検索.
	 */
	@RequestMapping(value="/user/s20f002_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String search(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_educ_list", this.getList());
		return JSON.encode(applyObj);
	}

	/**
	 * 学歴情報一覧取得.
	 */
	private List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (S10TEmpEduc s10TEmpEduc : this.service.selectUser(super.getTargetUserCd())) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("sequence", s10TEmpEduc.sequence);
			map.put("gakkouMei", s10TEmpEduc.gakkouMei);
			map.put("nyugakuYm", s10TEmpEduc.nyugakuYm);
			map.put("sotugyoYm", s10TEmpEduc.sotugyoYm);
			map.put("itSkilKbn", this.service.getItemName(s10TEmpEduc.itSkilKbn));
			map.put("bunriKbn", (s10TEmpEduc.bunriKbn.equals("1"))? "理" :"文");
			list.add(map);
		}
		return list;
	}

	/**
	 * 学歴情報検索.
	 */
	@RequestMapping(value="/user/s20f002_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_educ_list", this.service.selectId(super.getTargetUserCd(),
        		super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}

	/**
	 * 学歴情報登録.
	 */
	@RequestMapping(value="/user/s20f002_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TEmpEduc inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		LoginUserDto userinfo = super.getUserInfo();
		inEntity.userCd = userinfo.getUserCd();

		if (inEntity.saisyuGakurekiKbn == null) inEntity.saisyuGakurekiKbn = "0";

		if (inEntity.sequence == null) {
			// 新規
			inEntity.sequence = this.service.selectSeq();
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			S10TEmpEduc entity = this.service.selectId(inEntity.userCd, inEntity.sequence);
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;

			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 学歴情報削除.
	 */
	@RequestMapping(value="/user/s20f002_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TEmpEduc dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getUserInfo().getUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}
}
