package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MItem;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS00MItemDao {

    /**
     * @return the S00MItem entity
     */
    @Select
    List<S00MItem> selectAll();

    /**
     * @return the S00MItem entity
     */
    @Select
    List<S00MItem> selectByItemType(String itemType, String deleteFlg);

    /**
     * @return the S00MItem entity
     */
    @Select
    S00MItem selectByItemVal(String itemVal);

    /**
     * @return the S00MItem entity
     */
    @Select
    S00MItem selectItemNumbering(String itemType);
}