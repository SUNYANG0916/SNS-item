package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * 職務履歴情報
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_carrier")
public class S10TEmpCarrier {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 会社名 */
    @Column(name = "kaisya_mei")
    public String kaisyaMei;

    /** 入社年月 */
    @Column(name = "nyusya_ym")
    public String nyusyaYm;

    /** 退社年月 */
    @Column(name = "taisya_ym")
    public String taisyaYm;

    /** 雇用形態 */
    @Column(name = "koyokeitai_kbn")
    public String koyokeitaiKbn;

    /** 年収 */
    @Column(name = "nensyu")
    public Integer nensyu;

    /** 退職理由 */
    @Column(name = "taisyoku_riyu")
    public String taisyokuRiyu;

    /** 退職理由詳細 */
    @Column(name = "taisyoku_riyu_syosai")
    public String taisyokuRiyuSyosai;

    /** 役職 */
    @Column(name = "yakusyoku_kbn")
    public String yakusyokuKbn;

    /** 職務内容 */
    @Column(name = "syoku_naiyo")
    public String syokuNaiyo;

    /** ITスキル区分 */
    @Column(name = "it_skil_kbn")
    public String itSkilKbn;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}