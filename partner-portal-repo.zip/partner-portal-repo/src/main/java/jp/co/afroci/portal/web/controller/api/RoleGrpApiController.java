package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MRoleGrp;
import jp.co.afroci.common.domain.entity.S00MRoles;
import jp.co.afroci.common.dto.RolesInfoDto;
import jp.co.afroci.common.service.RoleGrpService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import jp.co.afroci.portal.web.util.Constants.DELETE_FLAG;
import net.arnx.jsonic.JSON;


/**
 * ロールグループコントローラ.
 */
@RestController
public class RoleGrpApiController extends AbstractApiController {

	@Autowired
	private RoleGrpService service;

	/**
	 * ロールグループ情報初期化.
	 */
	@RequestMapping(value="/user/s00f007_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S00F007, null);
		return JSON.encode(applyObj);
	}

	/**
	 * ロールグループ一覧検索.
	 */
	@RequestMapping(value="/user/s00f007_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
		applyObj.put("tbl_rolegrp_list", this.service.getItems(Constants.ITEMS.ITEM_30023));

		return JSON.encode(applyObj);
	}

	/**
	 * ロール詳細一覧検索.
	 */
	@RequestMapping(value="/user/s00f007_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();

        // ロールID
		String roleGrpId = request.getParameter("roleGrpId");
		// 管理者の場合、全件対象
		if (roleGrpId.equals("30023-admin")) {
			roleGrpId = null;
		}
		// ロール情報検索
		List<RolesInfoDto> s00MRoles = this.service.selectViewAll(roleGrpId);

		applyObj.put("tbl_role_list", s00MRoles);
		return JSON.encode(applyObj);
	}

	/**
	 * ロール情報登録.
	 *
	 */
	@RequestMapping(value="/user/s00f007_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	private String update(HttpServletRequest request, @RequestBody List<S00MRoleGrp> inEntitys) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		// 一括削除
		List<S00MRoleGrp> details = this.service.selectAll(inEntitys.get(0).roleGrpId);
		for (S00MRoleGrp s00MRoleGrp : details) {
			this.service.delete(s00MRoleGrp);
		}

		// 一括登録
		List<String> roleIds = new ArrayList<String>();
		for (S00MRoleGrp entity : inEntitys) {
			// 重複を取り除く
			if (!roleIds.contains(entity.roleId)) {
				entity.sort = roleIds.size() + 1;
				roleIds.add(entity.roleId);
				this.service.insert(entity);
			}
		}
		resutlObj.put("msg", "登録処理が完了しました。");
		return JSON.encode(resutlObj);
	}

    /**
     * ロールマスタ検索.
     */
    @RequestMapping(value="/user/s00f007_master_roles", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterProjects(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        String cond = "%" + request.getParameter("cond") + "%";

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (S00MRoles s00MRole : service.selectRolesAll(cond, DELETE_FLAG.OFF)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("roleId", s00MRole.roleId);
			map.put("roleNm", s00MRole.roleNm);
			list.add(map);
		}
        applyObj.put("tbl_master_roles_list", list);

        return JSON.encode(applyObj);
    }

}
