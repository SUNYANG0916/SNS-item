package jp.co.afroci.portal.web.util;

import java.math.BigDecimal;

public class Constants {

    /** アプリケーションID. */
    public static class APPLY_ID {
        /** メニュー. */
        public static final String S00F001 = "s00f001";
        /** ロールマスタ. */
        public static final String S00F002 = "s00f002";
        /** パスワード変更. */
        public static final String S00F003 = "s00f003";
        /** ユーザマスタ. */
        public static final String S00F004 = "s00f004";
        /** 項目マスタ. */
        public static final String S00F005 = "s00f005";
        /** パスワードリマインド. */
        public static final String S00F006 = "s00f006";
        /** ロールグループ. */
        public static final String S00F007 = "s00f007";
        /** 部署要員管理. */
        public static final String S00F101 = "s00f101";
        /** プロジェクト情報. */
        public static final String S10F001 = "s10f001";
        /** 取引先情報. */
        public static final String S10F002 = "s10f002";
        /** 稼働情報. */
        public static final String S10F003 = "s10f003";
        /** 旅行見積書. */
        public static final String S10F005 = "s10f005";
        /** 基本情報. */
        public static final String S20F001 = "s20f001";
        /** 学歴情報. */
        public static final String S20F002 = "s20f002";
        /** 資格情報. */
        public static final String S20F003 = "s20f003";
        /** 職務情報. */
        public static final String S20F004 = "s20f004";
        /** スキル情報. */
        public static final String S20F005 = "s20f005";
        /** 個人情報保護（プライバシーポリシー）. */
        public static final String S20F006 = "s20f006";
        /** 作業報告情報. */
        public static final String S20F007 = "s20f007";
        /** 経費交通費申請. */
        public static final String S20F008 = "s20f008";
        /** 見積書. */
        public static final String S30F001 = "s30f001";
        /** 注文書. */
        public static final String S30F002 = "s30f002";
        /** 請求書. */
        public static final String S30F003 = "s30f003";
        /** 旅行見積書. */
        public static final String S40F001 = "s40f001";
    }

    /** 項目マスタID. */
    public static class ITEMS {
        /** 項目マスタ区分：有無. */
        public static final String ITEM_10001 = "10001";
        /** 項目マスタ区分：OS. */
        public static final String ITEM_30001 = "30001";
        /** 項目マスタ区分：データベース. */
        public static final String ITEM_30002 = "30002";
        /** 項目マスタ区分：プログラム言語. */
        public static final String ITEM_30003 = "30003";
        /** 項目マスタ区分：JavaScriptライブラリ. */
        public static final String ITEM_30004 = "30004";
        /** 項目マスタ区分：フレームワーク. */
        public static final String ITEM_30005 = "30005";
        /** 項目マスタ区分：ミドルウェア. */
        public static final String ITEM_30006 = "30006";
        /** 項目マスタ区分：クラウドツール. */
        public static final String ITEM_30007 = "30007";
        /** 項目マスタ区分：開発ツール. */
        public static final String ITEM_30008 = "30008";
        /** 項目マスタ区分：ユーティリティツール. */
        public static final String ITEM_30009 = "30009";
        /** 項目マスタ区分：ビジネスツール. */
        public static final String ITEM_30010 = "30010";
        /** 項目マスタ区分：業界. */
        public static final String ITEM_30011 = "30011";
        /** 項目マスタ区分：開発工程. */
        public static final String ITEM_30012 = "30012";
        /** 項目マスタ区分：案件感想. */
        public static final String ITEM_30013 = "30013";
        /** 項目マスタ区分：プロジェクト役割. */
        public static final String ITEM_30014 = "30014";
        /** 項目マスタ区分：部署. */
        public static final String ITEM_30015 = "30015";
        /** 項目マスタ区分：感想. */
        public static final String ITEM_30016 = "30016";
        /** 項目マスタ区分：在職状態. */
        public static final String ITEM_30017 = "30017";
        /** 項目マスタ区分：契約形態. */
        public static final String ITEM_30018 = "30018";
        /** 項目マスタ区分：退職理由. */
        public static final String ITEM_30019 = "30019";
        /** 項目マスタ区分：稼働状況. */
        public static final String ITEM_30020 = "30020";
        /** 項目マスタ区分：規模. */
        public static final String ITEM_30021 = "30021";
        /** 項目マスタ区分：役職. */
        public static final String ITEM_30022 = "30022";
        /** 項目マスタ区分：ロール. */
        public static final String ITEM_30023 = "30023";
        /** 項目マスタ区分：交通費経費区分. */
        public static final String ITEM_30024 = "30024";
        /** 項目マスタ区分：経費種類. */
        public static final String ITEM_30025 = "30025";
        /** 項目マスタ区分：消費税. */
        public static final String ITEM_30026 = "30026";
        /** 項目マスタ区分：受発注送付先. */
        public static final String ITEM_30027 = "30027";
        /** 項目マスタ区分：取引状態. */
        public static final String ITEM_30028 = "30028";
        /** 項目マスタ区分：プロジェクト種別. */
        public static final String ITEM_30029 = "30029";
        /** 項目マスタ区分：口座種別. */
        public static final String ITEM_30030 = "30030";
        /** 項目マスタ区分：有効区分. */
        public static final String ITEM_30031 = "30031";
        /** 項目マスタ区分：稼働単位. */
        public static final String ITEM_30032 = "30032";
        /** 項目マスタ区分：お支払条件. */
        public static final String ITEM_30033 = "30033";
        /** 項目マスタ区分：お支払手数料分類. */
        public static final String ITEM_30034 = "30034";
        /** 項目マスタ区分：契約形態（業者）. */
        public static final String ITEM_30035 = "30035";
        /** 項目マスタ区分：ロール種別. */
        public static final String ITEM_30036 = "30036";
        /** 項目マスタ区分：移動手段. */
        public static final String ITEM_30037 = "30037";
        /** 項目マスタ区分：食事. */
        public static final String ITEM_30038 = "30038";
        /** 項目マスタ区分：税区分. */
        public static final String ITEM_30039 = "30039";
        /** 項目マスタ区分：代金種類. */
        public static final String ITEM_30040 = "30040";
    }

    /** 削除フラグ. */
    public static class DELETE_FLAG {
        /** ON. */
        public static final String OFF = "0";
        /** OFF. */
        public static final String ON = "1";
    }

    /** 税率. */
    public static class TAX_RATE {
        /** 税率. */
        public static final BigDecimal TAX_RATE_8 = new BigDecimal("0.08");
    }
}
