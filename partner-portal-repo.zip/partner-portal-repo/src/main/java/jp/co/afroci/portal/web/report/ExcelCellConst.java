package jp.co.afroci.portal.web.report;

/**
 * Southerlyのセルクラス.
 *
 * @author Gao Jiayi.
 */
public class ExcelCellConst {

	/** 行番号. */
	public int row;
	/** 列番号. */
	public int col;
	/** 値. */
	public String val;

	/**
	 * コンストラクタ.
	 * */
	public ExcelCellConst(int rowIndex, int colIndex, String value) {
		// 行番号
		this.row = rowIndex;
		// 列番号
		this.col = colIndex;
		// 値
		this.val = value;
	}

}
