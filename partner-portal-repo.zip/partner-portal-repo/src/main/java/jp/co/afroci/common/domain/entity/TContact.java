package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "t_contact")
public class TContact {

    /** */
    @Id
    @Column(name = "contact_seq")
    public String contactSeq;

    /** */
    @Column(name = "name")
    public String name;

    /** */
    @Column(name = "tel")
    public String tel;

    /** */
    @Column(name = "mail")
    public String mail;

    /** */
    @Column(name = "contact_details")
    public String contactDetails;

    /** */
    @Column(name = "sort")
    public BigDecimal sort;

    /** */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** */
    @Column(name = "create_user")
    public String createUser;

    /** */
    @Column(name = "create_date")
    public LocalDateTime createDate;
}