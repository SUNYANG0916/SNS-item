package jp.co.afroci.common.service;

import org.springframework.stereotype.Service;

/**
 * メニュー取り扱うService
 */
@Service
public class ExpSkillReportService extends AbstractService {



}