package jp.co.afroci.common.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS00MUserDao;
import jp.co.afroci.common.domain.dao.S00MUserDao;
import jp.co.afroci.common.domain.entity.S00MUser;

/**
 * ユーザ情報を取り扱うService
 */
@Service
public class UserInfoService extends AbstractService {

	@Autowired
	private S00MUserDao dao;
	@Autowired
	private CustomS00MUserDao customDao;

	/**
	 * 全件検索.
	 */
	public List<Map<String, Object>> selectAll() throws UsernameNotFoundException {
		return super.jdbcTemplate.queryForList("select * from s00_m_user");
	}

	/**
	 * 主キー(ユーザ)検索.
	 */
	public S00MUser selectId(String userCd) {
		return this.dao.selectById(userCd);
	}

	/**
	 * 主キー(ユーザ)検索.
	 *
	 * @param userCd
	 * @param password
	 */
	public S00MUser selectPassword(String userCd, String password) {
        RowMapper<S00MUser> mapper = new BeanPropertyRowMapper<S00MUser>(S00MUser.class);
        List<S00MUser> list = super.jdbcTemplate.query("select * from s00_m_user where user_cd = '" + userCd + "' and password='" + password + "'", mapper);
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;
	}

	/**
	 * パスワードリマインド検索.
	 *
	 * @param nyusyaYmd
	 * @param eijiSei
	 * @param eijiMei
	 */
	public S00MUser selectPasswordReminder(String nyusyaYmd, String eijiSei, String eijiMei) {
        List<S00MUser> list = customDao.selectPasswordReminder(nyusyaYmd, eijiSei, eijiMei);
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;
	}

	/**
	 * 更新登録.
	 *
	 * @param S00MUser
	 */
	public int update(S00MUser entity) throws UsernameNotFoundException {
		return dao.update((S00MUser) super.getEntity(entity));
	}

}