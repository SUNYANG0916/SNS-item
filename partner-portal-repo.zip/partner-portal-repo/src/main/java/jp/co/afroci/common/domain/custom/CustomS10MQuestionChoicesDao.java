package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10MQuestionChoices;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10MQuestionChoicesDao {

    /**
     * @param questionId
     * @param detailsNo
     * @param choicesCode
     * @return the S10MQuestionChoices entity
     */
    @Select
    List<S10MQuestionChoices> selectAll(String questionId, Integer detailsNo);

}