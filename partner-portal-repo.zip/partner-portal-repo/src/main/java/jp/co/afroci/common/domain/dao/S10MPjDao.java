package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10MPj;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10MPjDao {

    /**
     * @param pjCd
     * @return the S10MPj entity
     */
    @Select
    S10MPj selectById(String pjCd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10MPj entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10MPj entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10MPj entity);
}