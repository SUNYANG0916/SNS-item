package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * プロジェクトマスタ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_m_pj")
public class S10MPj {

    /** PJコード */
    @Id
    @Column(name = "pj_cd")
    public String pjCd;

    /** 有効期間（始） */
    @Column(name = "period_s")
    public String periodS;

    /** 有効期間（終） */
    @Column(name = "period_e")
    public String periodE;

    /** PJ名称 */
    @Column(name = "pj_nm")
    public String pjNm;

    /** PJマネージャ */
    @Column(name = "pj_pm")
    public String pjPm;

    /** PJリーダー */
    @Column(name = "pj_pl")
    public String pjPl;

    /** PJ種別 */
    @Column(name = "pj_type")
    public String pjType;

    /** 契約種別 */
    @Column(name = "agree_type")
    public String agreeType;

    /** 備考 */
    @Column(name = "pj_note")
    public String pjNote;

    /** 取引先コード */
    @Column(name = "suppliers_no")
    public String suppliersNo;

    /** 取引先名 */
    @Column(name = "suppliers_name")
    public String suppliersName;

    /** 作業場所 */
    @Column(name = "pj_work_lot")
    public String pjWorkLot;

    /** 時間上限 */
    @Column(name = "pj_times_max")
    public String pjTimesMax;

    /** 時間下限 */
    @Column(name = "pj_times_min")
    public String pjTimesMin;

    /** 数量(人月) */
    @Column(name = "quantity")
    public BigDecimal quantity;

    /** 単位 */
    @Column(name = "unit_price")
    public String unitPrice;

    /** 金額 */
    @Column(name = "amount")
    public BigDecimal amount;

    /** 税区分 */
    @Column(name = "tax_type")
    public String taxType;

    /** ソート */
    @Column(name = "sort")
    public Integer sort;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}