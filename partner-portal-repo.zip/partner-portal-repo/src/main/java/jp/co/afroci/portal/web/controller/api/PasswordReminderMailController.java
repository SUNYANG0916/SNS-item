package jp.co.afroci.portal.web.controller.api;

import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.codec.CharEncoding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.service.UserInfoService;
import jp.co.afroci.common.util.CipherUtil;
import jp.co.afroci.portal.web.config.SettingsConfig;
import net.arnx.jsonic.JSON;

@RestController
public class PasswordReminderMailController {

	@Autowired
	private UserInfoService service;

	private SettingsConfig emailCfg;
	public PasswordReminderMailController(SettingsConfig emailCfg) {
		this.emailCfg = emailCfg;
	}

	/**
	 * send mail contact company.
	 */
	@CrossOrigin
	@RequestMapping(value="/passwordReset_mail", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public String sentMailPasswordReminder(@RequestBody Map<String, String> model) throws Exception {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		// 入社年月日
		String nyusyaYmd = (String) model.get("nyusyaYmd");
		// 英字姓
		String eijiSei = model.get("eijiSei");
		// 英字名
		String eijiMei = model.get("eijiMei");

		// ユーザパスワード取得
		S00MUser s00MUser = this.service.selectPasswordReminder(nyusyaYmd, eijiSei.toUpperCase(), eijiMei.toUpperCase());

		if (s00MUser == null) {
			resutlObj.put("msg", "当該ユーザは見つからないため、送信できませんでした。");
		} else {
			// パスワード復号化
			String DncPassword = CipherUtil.decrypt(s00MUser.password, CipherUtil.key, CipherUtil.ALGORITHM_AES);

			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			mailSender.setHost(this.emailCfg.getHostName());
			mailSender.setPort(this.emailCfg.getPort());
			mailSender.setUsername(this.emailCfg.getUserName());
			mailSender.setPassword(this.emailCfg.getPassword());

			MimeMessage message = mailSender.createMimeMessage();

			// use the true flag to indicate you need a multipart message
			try {
				MimeMessageHelper helper = new MimeMessageHelper(message, true, CharEncoding.UTF_8);
				helper.setFrom(this.emailCfg.getSentFrom());
				helper.setTo(s00MUser.loginId);
				helper.setSubject("パスワードの再通知");

				StringBuilder html = new StringBuilder();
					html.append("<html><head>"
	                    + "<title></title>"
	                    + "</head>"
	                    + "<body>"
	                    +"<div style='width: 900px;padding: 10px; margin: 10px; background-color: #f5f5f5'>"
	                    +"<label>パスワードの再通知を申請されたため、通知いたします。</label>"
	                    +"<table width='900' cellpadding='0' cellspacing='0' border='0' style='background-color: #fff; padding:12px;'>"
		                    +"<tr><th style='width: 25%; text-align: left;'>パスワード: </th><td>"+ DncPassword +"</td></tr>"
		            	+"</table>"
	              +"</div>"
				+"</body>"
	           +"</html>");

				helper.setText(html.toString(), true);
			} catch (MessagingException e1) {
				e1.printStackTrace();
			}

			// Send mail
			try {
				mailSender.send(message);
				// save data to tcontact
//				TContact contact = new TContact();
//				Date date= new Date();
//
//				contact.contactSeq = ("C" + date.getTime()).substring(0, 10);
//				contact.name = eijiMei + " " + eijiSei;
//				//contact.tel = contactDto.getTel();
//				contact.mail = s00MUser.loginId;
//				//contact.contactDetails = contactDto.getContactDetail();
//				contact.sort = new BigDecimal(0);
//				contact.deleteFlg = "0";
//				contact.createUser = "";
//				contact.createDate = LocalDateTime.now();
//				int isSuccess = contactService.save(contact);
//				if(isSuccess == 1) {
//					resutlObj.put("msg", "送信失敗しました。");
//				}
				resutlObj.put("msg", "送信しました。");
			} catch (MailException e) {
				resutlObj.put("msg", "送信失敗しました。");
				System.out.println(e.getMessage());
			}

		}
		return JSON.encode(resutlObj);
	}
}
