package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

/**
 * ユーザ
 * @author Afroci Co., Ltd.
 */
@Entity
@Data
@Table(name = "s00_m_user")
public class S00MUser {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** ログインID */
    @Column(name = "login_id")
    public String loginId;

    /** パスワード */
    @Column(name = "password")
    public String password;

    /** ユーザ名 */
    @Column(name = "login_user_name")
    public String loginUserName;

    /** アクセスキー */
    @Column(name = "access_key")
    public String accessKey;

    /** アクセスキー有効期限 */
    @Column(name = "access_key_expir_date")
    @JsonFormat(pattern = "yyyy-MM-dd")
    public LocalDateTime accessKeyExpirDate;

    /** アカウントロック */
    @Column(name = "acount_locked")
    public String acountLocked;

    /** ログイン失敗回数 */
    @Column(name = "login_failure_count")
    public Integer loginFailureCount;

    /** 部署CD */
    @Column(name = "busyo_cd")
    public String busyoCd;

    /** 雇用種類 */
    @Column(name = "employment_type")
    public String employmentType;

    /** 在籍状態 */
    @Column(name = "employment_status")
    public String employmentStatus;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}