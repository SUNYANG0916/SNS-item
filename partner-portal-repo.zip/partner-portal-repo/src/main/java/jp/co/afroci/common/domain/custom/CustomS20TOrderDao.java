package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S20TOrder;
import jp.co.afroci.common.dto.MasterEstimateDto;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS20TOrderDao {

    /**
     * @return the S20TOrder entity
     */
    @Select
    List<S20TOrder> selectAll(String conditions, String deleteFlag);

    /**
     * @return the S10MSuppliers entity
     */
    @Select
    List<MasterEstimateDto> selectMasterAll(String conditions, String deleteFlag);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();
}