package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TEmpEduc;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10TEmpEducDao {

    /**
     * @param userCd
     * @param sequence
     * @return the S10TEmpEduc entity
     */
    @Select
    S10TEmpEduc selectById(String userCd, Integer sequence);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TEmpEduc entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TEmpEduc entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TEmpEduc entity);
}