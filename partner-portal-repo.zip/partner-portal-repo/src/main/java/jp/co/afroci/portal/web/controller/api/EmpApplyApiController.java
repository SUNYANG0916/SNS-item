package jp.co.afroci.portal.web.controller.api;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.afroci.common.domain.entity.S10TEmpApply;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.service.EmpApplyService;
import jp.co.afroci.common.service.EmpProfileService;
import jp.co.afroci.portal.web.WebAppApplication;
import jp.co.afroci.portal.web.config.SettingsConfig;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;

/**
 * 社員申請情報コントローラ.
 */
@RestController
public class EmpApplyApiController extends AbstractApiController {

	@Autowired
	SettingsConfig settingsConfig;

	@Autowired
	private EmpApplyService service;
	@Autowired
	private EmpProfileService profileService;

	/**
	 * ユーザ名英字を取得
	 *
	 * @param userCd
	 * @return
	 */
	private String getUserNameEiji(String userCd) {
		S10TEmpProfile profile = profileService.selectId(userCd);
		StringBuilder sb = new StringBuilder();
		sb.append(profile.eijiMei);
		sb.append(".");
		sb.append(profile.eijiSei);
		return sb.toString();
	}

	/**
	 * 申請情報初期化.
	 */
	@RequestMapping(value = "/user/s20f008_init", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F008, request.getParameter("userRow"));
		// 項目マスタリスト取得対象
		String[][] items = {
				{ Constants.ITEMS.ITEM_30024, "selSearchType", "", "" },
				{ Constants.ITEMS.ITEM_30025, "selExpType", "", "" }
		};
		this.service.setSelectItems(applyObj, items);

		applyObj.put("userCd", super.getTargetUserCd());

		return JSON.encode(applyObj);
	}

	/**
	 * 申請情報検索.
	 */
	@RequestMapping(value = "/user/s20f008_search", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
		String userCd = super.getTargetUserCd();
		String occurYm = request.getParameter("occurYm");
		String settleType = request.getParameter("settleType");

		// 全種類を指定する場合、精算種類を検索条件にしない
		if (settleType.equals("30024-099")) {
			settleType = null;
		}

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();

		List<S10TEmpApply> list = this.service.selectByUserYm(userCd, occurYm, settleType);
		for (S10TEmpApply s10TEmpApply : list) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("sequence", s10TEmpApply.sequence);
			map.put("settleType", s10TEmpApply.settleType);
			map.put("occurDate", s10TEmpApply.occurDate);
			map.put("transRootStart", s10TEmpApply.transRootStart);
			map.put("transRootEnd", s10TEmpApply.transRootEnd);
			map.put("settleAmount", s10TEmpApply.settleAmount);
			map.put("expType", this.service.getItemName(s10TEmpApply.expType));
			map.put("note", s10TEmpApply.note);

			result.add(map);
		}

		applyObj.put("tbl_apply_list", result);

		String fileDir = this.settingsConfig.getApplyFileDir();
		occurYm = occurYm.replaceAll("/", "");
		StringBuilder workReportPath = new StringBuilder();
		workReportPath.append(fileDir);
		workReportPath.append(userCd);
		File uploadDir = new File(workReportPath.toString());
		boolean isWkFile = Boolean.FALSE;
		if(uploadDir.exists()) {
			String wkFile = "WorkReport_" + occurYm;
			File[] files = uploadDir.listFiles();
			for (int i = 0; i < files.length; i++) {
				File file = files[i];
				String wkFileName = file.getName();
				if (wkFileName.indexOf(wkFile) == 0) {
					isWkFile = Boolean.TRUE;
					applyObj.put("wkFileName", file.getName());
				}
			}
		} else {
			uploadDir.mkdirs();
		}
		applyObj.put("isWkFile", isWkFile);

		return JSON.encode(applyObj);
	}

	/**
	 * 申請情報詳細検索.
	 */
	@RequestMapping(value = "/user/s20f008_details", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
		S10TEmpApply tmpApply = this.service.selectId(super.getTargetUserCd(),
				request.getParameter("occurYm"),
				super.getTargetSequence(request));
		applyObj.put("tbl_apply_list", tmpApply);

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		File dir = mkdirs(tmpApply.occurDate);
		File[] files = dir.listFiles();
		for (int i = 0; i < files.length; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			File file = files[i];
			map.put("tmpFileName", file.getName());
			result.add(map);
		}
		applyObj.put("tbl_tmp_list", result);
		return JSON.encode(applyObj);
	}

	/**
	 * 申請情報登録.
	 */
	@RequestMapping(value = "/user/s20f008_update", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TEmpApply inEntity) {
		Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		LoginUserDto userinfo = super.getUserInfo();
		inEntity.userCd = userinfo.getUserCd();

		if (inEntity.sequence == null) {
			// 新規
			inEntity.sequence = this.service.selectSeq();
			if (inEntity.roundTrip == null) {
				inEntity.roundTrip = "0";
			}

			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			S10TEmpApply entity = this.service.selectId(inEntity.userCd, inEntity.occurYm, inEntity.sequence);
			// 引継ぎ項目
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;
			// 更新実施
			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 申請情報削除.
	 */
	@RequestMapping(value = "/user/s20f008_delete", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TEmpApply dto) {
		Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getUserInfo().getUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 勤務表アップロードを行う
	 *
	 * @param multipartFile
	 * @param fileType
	 * @param registrationType
	 * @param dailyAttendanceYyyymm
	 * @param loginUser
	 * @return
	 */
	@RequestMapping(value = "/user/s20f008_wkupload", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String wkUpload(HttpServletRequest request, @RequestParam("wkFile") MultipartFile multipartFile,
			@RequestParam("targerYm") String targerYm) {
		Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		// 勤務表ファイル名
		String fileExtension = this.getExtension(multipartFile.getOriginalFilename());

		try {

			String userCd = "";
			if (super.getTargetUser() == null) {
				// メニューから遷移した場合
				userCd = super.getUserInfo().getUserCd();
			} else {
				// 社員管理一覧から遷移した場合
				userCd = super.getTargetUser().userCd;
			}
			String userName = getUserNameEiji(userCd);
			StringBuilder fileName = new StringBuilder();
			targerYm = targerYm.replaceAll("/", "");
			fileName.append("WorkReport_");
			fileName.append(targerYm);
			fileName.append("_");
			fileName.append(userName);
			if (!fileExtension.equals("")) {
				fileName.append(".");
				fileName.append(fileExtension);
			}
			// アップロードファイルを置く
			StringBuilder uploadPath = new StringBuilder();
			uploadPath.append(this.settingsConfig.getApplyFileDir());
			uploadPath.append(userCd);

			File dir = new File(uploadPath.toString());
			if(!dir.exists()) {
				this.mkdirs(uploadPath.toString());
			}
			uploadPath.append("/");
			uploadPath.append(fileName.toString());
			File uploadFile = new File(uploadPath.toString());
			BufferedOutputStream uploadFileStream = new BufferedOutputStream(new FileOutputStream(uploadFile));
			uploadFileStream.write(multipartFile.getBytes());
			uploadFileStream.close();
		} catch (Exception e) {
			// 異常終了時の処理
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		} catch (Throwable t) {
			// 異常終了時の処理
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}
		return JSON.encode(resutlObj);
	}

	/**
	 * 勤務表ファイルをダウンロードする
	 *
	 * @param filePath
	 * @return
	 */
	@RequestMapping(value = { "/user/s20f008_wk_download" }, method = RequestMethod.GET)
	public String wkDownload(HttpServletRequest request, HttpServletResponse response) throws Exception {
		response.setHeader("Content-Disposition", "attachment;");
		response.setHeader("Cache-Control", "private");
		response.setHeader("Pragma", "");

		OutputStream out = null;
		String userCd = "";
		if (super.getTargetUser() == null) {
			// メニューから遷移した場合
			userCd = super.getUserInfo().getUserCd();
		} else {
			// 社員管理一覧から遷移した場合
			userCd = super.getTargetUser().userCd;
		}
		String userName = getUserNameEiji(userCd);

		String targerYm = (String) request.getParameter("targerYm");

		StringBuilder fileName = new StringBuilder();
		fileName.append("WorkReport_");
		fileName.append(targerYm);
		fileName.append("_");
		fileName.append(userName);

		try {
			File file = null;

			//Fileクラスのオブジェクトを生成する
			File dir = new File(this.settingsConfig.getApplyFileDir() + userCd);

			//listFilesメソッドを使用して一覧を取得する
			File[] fileList = dir.listFiles();
			for (File f : fileList) {
				if (f.getPath().indexOf(fileName.toString()) > 0) {
					file = f;
				}
			}
			if (file != null && file.exists()) {
				String fileExtension = this.getExtension(file.getPath());
				if (!fileExtension.equals("")) {
					fileName.append(".");
					fileName.append(fileExtension);
				}
				response.setHeader("fileName", fileName.toString());

				// POIのワークブック生成
				FileInputStream in = new FileInputStream(file);
				out = response.getOutputStream();
				String classPath = WebAppApplication.class.getProtectionDomain().getCodeSource().getLocation().getPath();

				StringBuilder downloadPath = new StringBuilder();
				downloadPath.append(classPath);
				downloadPath.append("static/js/report/");
				downloadPath.append(userCd);
				downloadPath.append("/");

				File dlDir = new File(downloadPath.toString());
				if (!dlDir.exists()) {
					// フォルダ作成
					dlDir.mkdirs();
				}

				downloadPath = new StringBuilder();
				downloadPath.append(dlDir.getPath());
				downloadPath.append("/");
				downloadPath.append(fileName.toString());
				FileOutputStream outTemp = new FileOutputStream(downloadPath.toString());
				int data;
				while ((data = in.read()) != -1) {
					out.write((byte) data);
					outTemp.write((byte) data);
				}
				if (outTemp != null) {
					outTemp.close();
				}
				in.close();
			}
		} finally {
			if (out != null) {
				out.close();
			}
		}

		return null;
	}

	/**
	 * 勤務表を削除
	 *
	 * @param multipartFile
	 * @param fileType
	 * @param registrationType
	 * @param dailyAttendanceYyyymm
	 * @param loginUser
	 * @return
	 */
	@RequestMapping(value = "/user/s20f008_wkFileDelete", method = RequestMethod.GET)
	@ResponseBody
	public String wkFileDelete(HttpServletRequest request, Model model) {
		String fileName = (String) request.getParameter("fileName");
		String userCd = "";
		if (super.getTargetUser() == null) {
			// メニューから遷移した場合
			userCd = super.getUserInfo().getUserCd();
		} else {
			// 社員管理一覧から遷移した場合
			userCd = super.getTargetUser().userCd;
		}
		String fileDir = this.settingsConfig.getApplyFileDir() + userCd;
		return JSON.encode(this.deleteFile(fileName, fileDir));
	}

	/**
	 * 領収書アップロードを行う
	 *
	 * @param multipartFile
	 * @param fileType
	 * @param registrationType
	 * @param dailyAttendanceYyyymm
	 * @param loginUser
	 * @return 処理結果（JSON文字列）
	 */
	@RequestMapping(value = "/user/s20f008_upload", method = RequestMethod.POST)
	@ResponseBody
	public String upload(@RequestParam("tmpfile") MultipartFile multipartFile,
			@RequestParam("targerDate") String targerDate,
			@RequestParam("sequence") String sequence,
			@RequestParam("settleType") String settleType) {
		Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		// ファイルが空の場合は異常終了
		if (multipartFile.isEmpty()) {
			// 異常終了時の処理
		}
		// アップロードファイルを格納するディレクトリを作成する
		String userCd = "";
		if (super.getTargetUser() == null) {
			// メニューから遷移した場合
			userCd = super.getUserInfo().getUserCd();
		} else {
			// 社員管理一覧から遷移した場合
			userCd = super.getTargetUser().userCd;
		}
		String userName = getUserNameEiji(userCd);
		targerDate = targerDate.replace("-", "");
		File uploadDir = mkdirs(targerDate);
		String fileName = "receipt_" + targerDate + "_" + sequence + "_" + userName;
		String extension = this.getExtension(multipartFile.getOriginalFilename());
		if (!extension.equals("")) {
			fileName += "." + extension;
		}
		try {
			// アップロードファイルを置く
			File uploadFile = new File(uploadDir.getPath() + "/" + fileName);
			byte[] bytes = multipartFile.getBytes();
			BufferedOutputStream uploadFileStream = new BufferedOutputStream(new FileOutputStream(uploadFile));
			uploadFileStream.write(bytes);
			uploadFileStream.close();
		} catch (Exception e) {
			// 異常終了時の処理
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		} catch (Throwable t) {
			// 異常終了時の処理
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}
		return JSON.encode(resutlObj);
	}

	/**
	 * 領収書ファイルをダウンロードする
	 *
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = { "/user/s20f008_download" }, method = RequestMethod.GET)
	public String dawnload(HttpServletRequest request, HttpServletResponse response) throws Exception {
		response.setHeader("Content-Disposition", "attachment;");
		response.setHeader("Cache-Control", "private");
		response.setHeader("Pragma", "");

		OutputStream out = null;
		String targerDate = (String) request.getParameter("targerDate");
		String fileName = (String) request.getParameter("file_name");

		File uploadDir = mkdirs(targerDate);

		if (fileName.indexOf(".pdf") > 0) {
			response.setContentType("application/pdf");
		} else {
			response.setContentType("application/octet-stream");
		}

		try {
			// ダウンロードファイル生成
			File file = new File(uploadDir.getPath() + "/" + fileName);
			if (file.exists()) {
				FileInputStream in = new FileInputStream(file);
				out = response.getOutputStream();
				String classPath = WebAppApplication.class.getProtectionDomain().getCodeSource().getLocation().getPath();

				File dlDir = new File(classPath + "static/js/report/" + super.getUserInfo().getUserCd() + "/"
						+ targerDate.replace("-", "") + "/");
				if (!dlDir.exists()) {
					// フォルダ作成
					dlDir.mkdirs();
				}
				FileOutputStream outTemp = new FileOutputStream(dlDir.getPath() + "/" + fileName);
				int data;
				while ((data = in.read()) != -1) {
					out.write((byte) data);
					outTemp.write((byte) data);
				}
				if (outTemp != null) {
					outTemp.close();
				}
				in.close();
			}
		} finally {
			if (out != null) {
				out.close();
			}
		}

		return null;
	}


	/**
	 * 領収書を削除
	 *
	 * @param request
	 * @param model
	 * @return 処理結果（JSON文字列）
	 */
	@RequestMapping(value = "/user/s20f008_tmpFileDelete", method = RequestMethod.GET)
	@ResponseBody
	public String _tmpFileDelete(HttpServletRequest request, Model model) {
		String targerDate = (String) request.getParameter("targerDate");
		String fileName = (String) request.getParameter("fileName");
		return JSON.encode(this.deleteFile(fileName, this.mkdirs(targerDate).getPath()));
	}

	/**
	 * ファイルを削除
	 *
	 * @param fileName ファイル名
	 * @param fileDir ファイルディレクトリ
	 * @return 処理結果（JSON文字列）
	 */
	private Map<String, Object> deleteFile(String fileName, String fileDir) {
		Map<String, Object> resultObj = new HashMap<String, Object>();
		resultObj.put("result", "ok");;
		try {
			// 領収書ファイルを削除
			File file = new File(fileDir + "/" + fileName);
			file.delete();
		} catch (Exception e) {
			// 異常終了時の処理
			resultObj.put("msg", "処理失敗しました。");
			resultObj.put("result", "error");
		} catch (Throwable t) {
			// 異常終了時の処理
			resultObj.put("msg", "処理失敗しました。");
			resultObj.put("result", "error");
		}

		return resultObj;
	}

	/**
	 * アップロードファイルを格納するディレクトリを作成する
	 *
	 * @param targerDate
	 * @return ディレクトリパス
	 */
	private File mkdirs(String targerDate) {
		String template = this.settingsConfig.getApplyFileDir();
		String userCd = "";
		if (super.getTargetUser() == null) {
			// メニューから遷移した場合
			userCd = super.getUserInfo().getUserCd();
		} else {
			// 社員管理一覧から遷移した場合
			userCd = super.getTargetUser().userCd;
		}
		File uploadDir = new File(template + userCd + "/" + targerDate.replace("-", "") + "/");
		if (!uploadDir.exists()) {
			// フォルダ作成
			uploadDir.mkdirs();
		}

		return uploadDir;
	}
	/**
	 * アップロードファイルの拡張子を取得する
	 *
	 * @param fileName
	 * @return 拡張子
	 */
	private String getExtension(String fileName) {
		String fileExtension = "";
		// 最後の『 . 』の位置を取得します。
		int lastDotPosition = fileName.lastIndexOf(".");
		// 『 . 』が存在する場合は、『 . 』以降を返します。
		if (lastDotPosition != -1) {
			fileExtension = fileName.substring(lastDotPosition + 1);
		}
		return fileExtension;
	}

}
