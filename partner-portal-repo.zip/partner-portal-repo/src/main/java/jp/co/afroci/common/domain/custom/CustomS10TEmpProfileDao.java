package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TEmpProfile;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TEmpProfileDao {

    /**
     * @param userCd
     * @return the S10TEmpProfile entity
     */
    @Select
    List<S10TEmpProfile> selectAll();

    /**
     * @param userCd
     * @return the S10TEmpProfile entity
     */
    @Select
    List<S10TEmpProfile> selectByUserCd(String userCd);

    /**
     * @return the シーケンス
     */
    @Select
    String selectEmpNoSeq();

}