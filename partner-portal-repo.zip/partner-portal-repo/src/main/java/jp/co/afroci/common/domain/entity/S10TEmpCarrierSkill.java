package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * スキル情報
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_carrier_skill")
public class S10TEmpCarrierSkill {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 案件名 */
    @Column(name = "anken_mei")
    public String ankenMei;

    /** 開始年月 */
    @Column(name = "kaisi_ym")
    public String kaisiYm;

    /** 終了年月 */
    @Column(name = "syuryo_ym")
    public String syuryoYm;

    /** 規模 */
    @Column(name = "kibo")
    public String kibo;

    /** 作業場所 */
    @Column(name = "sagyo_basyo")
    public String sagyoBasyo;

    /** 役割 */
    @Column(name = "yakuwari_kbn")
    public String yakuwariKbn;

    /** 業界 */
    @Column(name = "gyokai_cd")
    public String gyokaiCd;

    /** 工程 */
    @Column(name = "kotei_cd")
    public String koteiCd;

    /** OS */
    @Column(name = "os_cd")
    public String osCd;

    /** DB */
    @Column(name = "db_cd")
    public String dbCd;

    /** ミドルウェア */
    @Column(name = "midoruwea_cd")
    public String midoruweaCd;

    /** プログラム言語 */
    @Column(name = "program_gengo_cd")
    public String programGengoCd;

    /** JavaScriptライブラリ */
    @Column(name = "java_lib_cd")
    public String javaLibCd;

    /** フレームワーク */
    @Column(name = "framework_cd")
    public String frameworkCd;

    /** 開発 */
    @Column(name = "tool_kaihatu_cd")
    public String toolKaihatuCd;

    /** クラウド */
    @Column(name = "tool_cloud_cd")
    public String toolCloudCd;

    /** ユーティリティ */
    @Column(name = "tool_utility_cd")
    public String toolUtilityCd;

    /** ビジネス */
    @Column(name = "tool_bisinesu_cd")
    public String toolBisinesuCd;

    /** 感想 */
    @Column(name = "annken_kansou")
    public String annkenKansou;

    /** 作業内容 */
    @Column(name = "annken_sagyo_syosai")
    public String annkenSagyoSyosai;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}