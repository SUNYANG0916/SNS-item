package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.service.EmpCarrierSkillService;
import jp.co.afroci.common.service.EmpProfileService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * スキル情報コントローラ.
 */
@RestController
public class EmpCarrierSkillApiController extends AbstractApiController {

	@Autowired
	private EmpCarrierSkillService service;

	@Autowired
	private EmpProfileService empService;

	/**
	 * スキル情報初期化.
	 */
	@RequestMapping(value="/user/s20f005_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F005, request.getParameter("userRow"));
		// 項目マスタリスト取得対象
		String[][] items = {{Constants.ITEMS.ITEM_30011,"list_gyokai_val", "gyokaiCd", "gyokaiName"}
	        ,{Constants.ITEMS.ITEM_30021,"list_kibo_val", "kibo", "kiboName"}
	        ,{Constants.ITEMS.ITEM_30012,"list_kotei_val", "koteiCd", "koteiName"}
	        ,{Constants.ITEMS.ITEM_30001,"list_os_val", "osCd", "osName"}
	        ,{Constants.ITEMS.ITEM_30002,"list_db_val", "dbCd", "dbName"}
	        ,{Constants.ITEMS.ITEM_30003,"list_program_gengo_val", "programGengoCd" ,"programGengoName"}
	        ,{Constants.ITEMS.ITEM_30004,"list_java_lib_val", "javaLibCd" ,"javaLibName"}
	        ,{Constants.ITEMS.ITEM_30005,"list_framework_val", "frameworkCd" ,"frameworkName"}
	        ,{Constants.ITEMS.ITEM_30006,"list_midoruwea_val", "midoruweaCd", "midoruweaName"}
	        ,{Constants.ITEMS.ITEM_30007,"list_tool_cloud_val", "toolCloudCd", "toolCloudName"}
	        ,{Constants.ITEMS.ITEM_30008,"list_tool_kaihatu_val", "toolKaihatuCd" ,"toolKaihatuName"}
	        ,{Constants.ITEMS.ITEM_30009,"list_tool_utility_val", "toolUtilityCd" ,"toolUtilityName"}
	        ,{Constants.ITEMS.ITEM_30010,"list_tool_bisinesu_val", "toolBisinesuCd" ,"toolBisinesuName"}
	        ,{Constants.ITEMS.ITEM_30016,"list_annken_kansou_val", "annkenKansou" ,"annkenKansouName"}
	        ,{Constants.ITEMS.ITEM_30014,"selYakuwariKbn", "" ,""}
		};
		this.service.setSelectItems(applyObj, items);

		String userInitial = "未登録";
		S10TEmpProfile dto = this.empService.selectId(super.getTargetUserCd());
		if (dto != null) {
			userInitial = dto.eijiSei.substring(0, 1) + "." + dto.eijiMei.substring(0, 1);
		}
		applyObj.put("userInitial", userInitial);
		return JSON.encode(applyObj);
	}

	/**
	 * スキル情報検索.
	 */
	@RequestMapping(value="/user/s20f005_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		for (S10TEmpCarrierSkill skill : this.service.selectUser(super.getTargetUserCd())) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ankenMei", skill.ankenMei);
			map.put("kaisiYm", skill.kaisiYm);
			map.put("syuryoYm", skill.syuryoYm);
			map.put("sequence", skill.sequence);

			list.add(map);
		}
        applyObj.put("tbl_skill_list", list);
		return JSON.encode(applyObj);
	}

	/**
	 * スキル情報詳細検索.
	 */
	@RequestMapping(value="/user/s20f005_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_skill_list", this.service.selectId(super.getTargetUserCd(),
        		super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}


	/**
	 * スキル情報登録.
	 */
	@RequestMapping(value="/user/s20f005_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TEmpCarrierSkill inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		inEntity.userCd = super.getTargetUserCd();

		if (inEntity.sequence == null) {
			// 新規
			inEntity.sequence = this.service.selectSeq();
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			S10TEmpCarrierSkill entity = this.service.selectId(inEntity.userCd, inEntity.sequence);
			// 引継ぎ項目
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;

			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * スキル情報削除.
	 */
	@RequestMapping(value="/user/s20f005_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TEmpCarrierSkill dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getTargetUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}
}
