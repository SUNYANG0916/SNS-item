package jp.co.afroci.portal.web.controller.api;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.codec.CharEncoding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.TContact;
import jp.co.afroci.common.dto.ContactDto;
import jp.co.afroci.common.service.ContactService;
import jp.co.afroci.portal.web.config.SettingsConfig;

@RestController
public class MailController {

	@Autowired
	private ContactService contactService;

	private SettingsConfig emailCfg;
	public MailController(SettingsConfig emailCfg) {
		this.emailCfg = emailCfg;
	}

	/**
	 * send mail contact company.
	 */
	@CrossOrigin
	@RequestMapping(value="/contact-mail", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public int sentMailContactCompany(@Validated @RequestBody ContactDto contactDto) throws Exception {

		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(this.emailCfg.getHostName());
		mailSender.setPort(this.emailCfg.getPort());
		mailSender.setUsername(this.emailCfg.getUserName());
		mailSender.setPassword(this.emailCfg.getPassword());

		MimeMessage message = mailSender.createMimeMessage();

		// use the true flag to indicate you need a multipart message
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true, CharEncoding.UTF_8);
			helper.setFrom(this.emailCfg.getSentFrom());
			helper.setTo(this.emailCfg.getSentTo());
			helper.setSubject("ホームページからのお問い合わせ");

			StringBuilder html = new StringBuilder();
				html.append("<html><head>"
                    + "<title></title>"
                    + "</head>"
                    + "<body>"
                    +"<div style='width: 900px;padding: 10px; margin: 10px; background-color: #f5f5f5'>"
                    +"<table width='900' cellpadding='0' cellspacing='0' border='0' style='background-color: #fff; padding:12px;'>"
	                    +"<tr><th style='width: 25%; text-align: left;'>名前: </th><td>"+ contactDto.getName() +"</td></tr>"
	                    +"<tr><th style='width: 25%; text-align: left;'>電話番号: </th><td>"+ contactDto.getTel() +"</td></tr>"
	                    +"<tr><th style='width: 25%; text-align: left;'>電子メールアドレス: </th><td>"+ contactDto.getMail() +"</td></tr>"
	    	            +"<tr><th colspan='3'  style='width: 15%; text-align: left;border-bottom: 1px solid #ccc;'>説明: </th></tr>"
	    	            +"<tr><td colspan='3' style='padding-top:15px;'>"+ contactDto.getContactDetail() +"</td></tr>"
	            	+"</table>"
              +"</div>"
			+"</body>"
           +"</html>");

			helper.setText(html.toString(), true);
		} catch (MessagingException e1) {
			e1.printStackTrace();
		}

		// Send mail
		try {
			mailSender.send(message);
			// save data to tcontact
			TContact contact = new TContact();
			Date date= new Date();

			contact.contactSeq = ("C" + date.getTime()).substring(0, 10);
			contact.name = contactDto.getName();
			contact.tel = contactDto.getTel();
			contact.mail = contactDto.getMail();
			contact.contactDetails = contactDto.getContactDetail();
			contact.sort = new BigDecimal(0);
			contact.deleteFlg = "0";
			contact.createUser = "";
			contact.createDate = LocalDateTime.now();
			int isSuccess = contactService.save(contact);
			if(isSuccess == 1) {
				return 1;
			}
			return 0;
		} catch (MailException e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}
}
