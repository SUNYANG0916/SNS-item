package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpCarrierDao;
import jp.co.afroci.common.domain.dao.S10TEmpCarrierDao;
import jp.co.afroci.common.domain.entity.S10TEmpCarrier;

/**
 * 職歴情報を取り扱うService
 */
@Service
public class EmpCarrierService extends AbstractService {

	@Autowired
	private S10TEmpCarrierDao dao;
	@Autowired
	private CustomS10TEmpCarrierDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpCarrier entity) {
		return dao.insert((S10TEmpCarrier) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpCarrier entity) {
		return dao.update((S10TEmpCarrier) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpCarrier entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S10TEmpCarrier selectId(String userCd, int sequence) {
		return dao.selectById(userCd, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpCarrier> selectUser(String userCd) {
		return customDao.selectByUserCd(userCd);
	}

	/**
	 * 全件検索.
	 */
	public List<S10TEmpCarrier> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}

}