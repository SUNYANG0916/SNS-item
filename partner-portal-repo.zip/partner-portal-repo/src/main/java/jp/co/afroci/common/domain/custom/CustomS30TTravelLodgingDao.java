package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S30TTravelLodging;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS30TTravelLodgingDao {

    /**
     * @return the S30TTravelLodging entity
     */
    @Select
    List<S30TTravelLodging> selectAll(String travelNo, String deleteFlag);

}