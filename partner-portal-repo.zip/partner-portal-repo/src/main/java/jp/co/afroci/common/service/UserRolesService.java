package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomLoginUserDao;
import jp.co.afroci.common.domain.custom.CustomLoginUserRolesDao;
import jp.co.afroci.common.domain.custom.CustomS00MUserRolesDao;
import jp.co.afroci.common.domain.dao.S00MUserDao;
import jp.co.afroci.common.domain.dao.S00MUserRolesDao;
import jp.co.afroci.common.domain.entity.S00MRoles;
import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.domain.entity.S00MUserRoles;
import jp.co.afroci.common.dto.EmpInfoDto;

/**
 * ログインユーザロール取り扱うService
 */
@Service
public class UserRolesService extends AbstractService {

	@Autowired
	private S00MUserDao userDao;

	@Autowired
	private CustomLoginUserDao customUserDao;

	@Autowired
	private S00MUserRolesDao roleDao;
	@Autowired
	private CustomLoginUserRolesDao cRoleDao;

	@Autowired
	private CustomS00MUserRolesDao customUserRolesDao;

	/**
	 * ユーザー読み込み
	 */
	public List<S00MRoles> getRoles(String userCd) {
		List<S00MRoles> userRoles = cRoleDao.selectByUserCd(userCd);
		if (userRoles == null || userRoles.size() == 0) {
			throw new UsernameNotFoundException("ユーザーIDが不正です。");
		}
		return userRoles;
	}

	/**
	 * ユーザ新規登録.
	 */
	public int insert(S00MUser entity) {
		return userDao.insert((S00MUser) super.getEntity(entity));
	}

	/**
	 * ユーザ更新.
	 */
	public int update(S00MUser entity) {
		return userDao.update((S00MUser) super.getEntity(entity));
	}

	/**
	 * ユーザ削除.
	 */
	public int delete(S00MUser entity) {
		return userDao.delete(entity);
	}

	/**
	 * ユーザ権限新規登録.
	 */
	public int insertRole(S00MUserRoles entity) {
		return roleDao.insert((S00MUserRoles) super.getEntity(entity));
	}

	/**
	 * ユーザ権限更新.
	 */
	public int updateRole(S00MUserRoles entity) {
		return roleDao.update((S00MUserRoles) super.getEntity(entity));
	}

	/**
	 * ユーザ権限削除.
	 */
	public int deleteRole(S00MUserRoles entity) {
		return roleDao.delete(entity);
	}

	/**
	 * 全件検索.
	 */
	public List<EmpInfoDto> selectAll(String conditions) {
		return customUserDao.selectEmpInfoAll(conditions);
	}

	/**
	 * 主キー(ユーザ)検索.
	 */
	public S00MUser selectId(String userCd) {
		RowMapper<S00MUser> mapper = new BeanPropertyRowMapper<S00MUser>(S00MUser.class);
		List<S00MUser> list = super.jdbcTemplate.query("select * from s00_m_user where user_cd = '" + userCd + "'",
				mapper);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * ロール検索.
	 */
	public S00MUserRoles selectRoleUser(String userCd, String roleId) {
		return roleDao.selectById(userCd, roleId);
	}

	/**
	 * ユーザごとロールを検索.
	 */
	public List<S00MUserRoles> selectByUser(String userCd) {
		return customUserRolesDao.selectByUserCd(userCd);
	}

}