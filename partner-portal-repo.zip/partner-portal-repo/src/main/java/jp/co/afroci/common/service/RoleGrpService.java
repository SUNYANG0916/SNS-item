package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS00MRoleGrpDao;
import jp.co.afroci.common.domain.custom.CustomS00MRolesDao;
import jp.co.afroci.common.domain.dao.S00MRoleGrpDao;
import jp.co.afroci.common.domain.entity.S00MRoleGrp;
import jp.co.afroci.common.domain.entity.S00MRoles;
import jp.co.afroci.common.dto.RolesInfoDto;

/**
 * ロール取り扱うService
 */
@Service
public class RoleGrpService extends AbstractService {

	@Autowired
	private S00MRoleGrpDao dao;
	@Autowired
	private CustomS00MRoleGrpDao customDao;
	@Autowired
	private CustomS00MRolesDao rolesDao;

	public S00MRoleGrp selectById(String roleGrpId, String roleId) {
		return dao.selectById(roleGrpId, roleId);
	}

	public List<S00MRoleGrp> selectAll(String roleGrpId) {
		return customDao.selectAll(roleGrpId);
	}

	public List<RolesInfoDto> selectViewAll(String roleGrpId) {
		return customDao.selectViewAll(roleGrpId);
	}

	public List<S00MRoles> selectRolesAll(String conditions, String deleteFlag) {
		return rolesDao.selectAll(conditions, deleteFlag);
	}

	/**
	 * ユーザ権限新規登録.
	 */
	public int insert(S00MRoleGrp entity) {
		return dao.insert((S00MRoleGrp) super.getEntity(entity));
	}

	/**
	 * ユーザ権限更新.
	 */
	public int update(S00MRoleGrp entity) {
		return dao.update((S00MRoleGrp) super.getEntity(entity));
	}

	/**
	 * ユーザ権限削除.
	 */
	public int delete(S00MRoleGrp entity) {
		return dao.delete(entity);
	}

}