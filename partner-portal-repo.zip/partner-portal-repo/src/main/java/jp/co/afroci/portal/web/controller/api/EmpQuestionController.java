package jp.co.afroci.portal.web.controller.api;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10MQuestion;
import jp.co.afroci.common.domain.entity.S10MQuestionChoices;
import jp.co.afroci.common.domain.entity.S10MQuestionDetail;
import jp.co.afroci.common.domain.entity.S10TEmpQuestion;
import jp.co.afroci.common.service.EmpQuestionService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * 質問情報コントローラ.
 */
@RestController
public class EmpQuestionController extends AbstractApiController {

	@Autowired
	private EmpQuestionService service;

	/**
	 * 質問情報初期化.
	 */
	@RequestMapping(value="/user/s20f006_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		return JSON.encode(super.getApplyObj(Constants.APPLY_ID.S20F006, null));
	}

	/**
	 * 質問情報一覧検索.
	 */
	@RequestMapping(value="/user/s20f006_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
		// メニューから遷移した場合
    	applyObj.put("userName", super.getUserInfo().getLoginUserName());

        List<S10MQuestion> s10TEmpQues = new ArrayList<S10MQuestion>();
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
    	s10TEmpQues = this.service.selectAll();

		// 一覧表示の詰め替え
		for (S10MQuestion s10MQuestion : s10TEmpQues) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("questionId", s10MQuestion.questionId);
			map.put("questionName", s10MQuestion.questionName);
			// 件数
			List<S10MQuestionDetail> s10MQuestionDetails = service.selectDetailAll(s10MQuestion.questionId);
			int detailsCnt = s10MQuestionDetails.size();
			map.put("detailsCnt", detailsCnt);

			Map<Integer, Integer> questionDetail = new HashMap<Integer, Integer>();
			for (S10MQuestionDetail s10MQuestionDetail : s10MQuestionDetails) {
				questionDetail.put(s10MQuestionDetail.detailsNo, s10MQuestionDetail.point);
			}

			int execCnt = 0;
			int point = 0;
			int wrongCnt = 0;
			List<S10TEmpQuestion> empQuestions = service.selectDetailAll(super.getUserInfo().getUserCd(), s10MQuestion.questionId);
			for (S10TEmpQuestion empQuestion : empQuestions) {
				if (empQuestion.status.equals("true")) {
					point += questionDetail.get(empQuestion.detailsNo);
				} else {
					wrongCnt += 1;
				}
				execCnt++;
			}
			map.put("status", String.valueOf(execCnt) + "／" + String.valueOf(detailsCnt));
			map.put("point", String.valueOf(point) );
			map.put("wrongCnt", String.valueOf(wrongCnt));
			list.add(map);
		}
        applyObj.put("tbl_question_list", list);

		return JSON.encode(applyObj);
	}

	/**
	 * 質問情報詳細検索.
	 */
	@RequestMapping(value="/user/s20f006_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String questionId = request.getParameter("questionId");
        String detailsNo = request.getParameter("detailsNo");
        S10MQuestionDetail detail = service.selectDetail(questionId, Integer.valueOf(detailsNo));
        applyObj.put("questionInfo", detail.questionInfo);
        applyObj.put("questionId", detail.questionId);
        applyObj.put("detailsNo", detail.detailsNo);

        applyObj.put("tbl_question_dtl_list", service.selectChoicesDetailAll(questionId, Integer.valueOf(detailsNo)));

		return JSON.encode(applyObj);
	}

	/**
	 * 質問実施結果検索.
	 */
	@RequestMapping(value="/user/s20f006_results", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getResults(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String questionId = request.getParameter("questionId");

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        List<S10MQuestionDetail> detail = service.selectDetailAll(questionId);
        for (int i = 0; i < detail.size(); i++) {
        	Map<String, Object> empQuestionResult = new HashMap<String, Object>();
        	S10TEmpQuestion s10TEmpQuestion = service.selectDetailById(super.getUserInfo().getUserCd(), questionId, detail.get(i).detailsNo);

        	List<S10MQuestionChoices> choices = service.selectChoicesDetailAll(questionId, detail.get(i).detailsNo);
        	empQuestionResult.put("choicesType", choices.get(0).choicesType);
        	String commentary = "";
        	for (S10MQuestionChoices choice : choices) {
        		if (choice.commentary != null) {
        			commentary += "\r\n" + choice.commentary;
        		}
        	}
        	empQuestionResult.put("questionInfo", detail.get(i).questionInfo);
    		empQuestionResult.put("detailsNo", detail.get(i).detailsNo);
        	if (s10TEmpQuestion != null) {
            	empQuestionResult.put("status", (s10TEmpQuestion.status.equals("true")) ? "正解": "不正解");
              	empQuestionResult.put("lastTs", s10TEmpQuestion.lastTs.toString());
            	empQuestionResult.put("execCount", s10TEmpQuestion.execCount);
            	empQuestionResult.put("commentary", commentary);
        	} else {
            	empQuestionResult.put("status", "未実施");
              	empQuestionResult.put("lastTs", "");
            	empQuestionResult.put("execCount", 0);
        	}
        	list.add(empQuestionResult);
        }


        applyObj.put("tbl_question_result_list", list);

		return JSON.encode(applyObj);
	}

	/**
	 * 質問実施登録.
	 */
	@RequestMapping(value="/user/s20f006_update", method=RequestMethod.POST, produces="text/plain;charset=UTF-8")
	public String update(@RequestBody S10TEmpQuestion inEntity) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        inEntity.userCd = super.getUserInfo().getUserCd();
        inEntity.lastTs = LocalDate.now();

		// 更新
        S10TEmpQuestion detail = service.selectDetailById(inEntity.userCd, inEntity.questionId, inEntity.detailsNo);

        if (detail != null) {
        	inEntity.execCount = detail.execCount + 1;

			this.service.update(inEntity);
        } else {
        	inEntity.execCount = 1;

			this.service.insert(inEntity);
        }

		return JSON.encode(applyObj);
	}

}
