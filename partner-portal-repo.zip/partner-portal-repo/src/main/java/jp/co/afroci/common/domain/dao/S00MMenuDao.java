package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S00MMenu;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S00MMenuDao {

    /**
     * @param menuId
     * @return the S00MMenu entity
     */
    @Select
    S00MMenu selectById(String menuId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S00MMenu entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S00MMenu entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S00MMenu entity);
}