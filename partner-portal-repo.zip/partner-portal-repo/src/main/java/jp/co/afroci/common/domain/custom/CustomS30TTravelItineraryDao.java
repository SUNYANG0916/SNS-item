package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S30TTravelItinerary;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS30TTravelItineraryDao {

    /**
     * @return the S20TEstimate entity
     */
    @Select
    List<S30TTravelItinerary> selectAll(String travelNo, String deleteFlag);

}