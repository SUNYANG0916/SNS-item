package jp.co.afroci.common.domain.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 従業員質問回答
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_question")
public class S10TEmpQuestion {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 質問ID */
    @Id
    @Column(name = "question_id")
    public String questionId;

    /** 質問明細番号 */
    @Id
    @Column(name = "details_no")
    public Integer detailsNo;

    /** 実施回数 */
    @Column(name = "exec_count")
    public Integer execCount;

    /** 最終実施日時 */
    @Column(name = "last_ts")
    public LocalDate lastTs;

    /** ステータス */
    @Column(name = "status")
    public String status;

    /** 解説 */
    @Column(name = "commentary")
    public String commentary;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}