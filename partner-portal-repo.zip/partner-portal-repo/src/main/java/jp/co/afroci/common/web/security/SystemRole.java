package jp.co.afroci.common.web.security;

public enum SystemRole {

	ROLE_USER, ROLE_MANAGE, ROLE_ADMIN, ROLE_API
}
