package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S20TEstimate;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S20TEstimateDao {

    /**
     * @param estimateNo
     * @return the S20TEstimate entity
     */
    @Select
    S20TEstimate selectById(String estimateNo);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S20TEstimate entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S20TEstimate entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S20TEstimate entity);
}