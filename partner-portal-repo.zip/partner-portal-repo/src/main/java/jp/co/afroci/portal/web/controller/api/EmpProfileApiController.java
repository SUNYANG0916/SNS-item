package jp.co.afroci.portal.web.controller.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MPostal;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.service.EmpProfileService;
import jp.co.afroci.common.util.JsonUtil;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * S20F001_基本情報コントローラ.
 */
@RestController
public class EmpProfileApiController extends AbstractApiController {

	@Autowired
	private EmpProfileService service;

	/**
	 * 基本情報初期化.
	 */
	@RequestMapping(value="/user/s20f001_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F001, request.getParameter("userRow"));

		// 項目マスタリスト取得対象
		String[][] items = {{Constants.ITEMS.ITEM_30003,"tokui_gijutu_list_val", "tokuiGijutuCd", "tokuiGijutuName"}
		                    ,{Constants.ITEMS.ITEM_30012,"tokui_kotei_list_val", "tokuiKoteiCd", "tokuiKoteiName"}
		                    ,{Constants.ITEMS.ITEM_30015,"selBusyoCd", "" ,""}
		                    ,{Constants.ITEMS.ITEM_30022,"selYakusyokuKbn", "" ,""}
		                    };
		this.service.setSelectItems(applyObj, items);
		return JSON.encode(applyObj);
	}

	/**
	 * 基本情報検索.
	 */
	@RequestMapping(value="/user/s20f001_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getMenuInfo(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
        S10TEmpProfile dto = this.service.selectId(super.getTargetUserCd());
        if (dto != null) {
        	applyObj.put("empProfile", dto);
        }

        return JsonUtil.toJson(applyObj);
	}

	/**
	 * 基本情報登録.
	 */
	@RequestMapping(value="/user/s20f001_update", method=RequestMethod.POST, produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TEmpProfile inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		LoginUserDto userinfo = super.getUserInfo();

        S10TEmpProfile entity = this.service.selectId(userinfo.getUserCd());
		inEntity.deleteFlg = Constants.DELETE_FLAG.OFF;
		if (entity == null) {
			inEntity.userCd = userinfo.getUserCd();
			inEntity.empNo = service.selectEmpNoSeq();
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			inEntity.empNo = entity.empNo;
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;
			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JsonUtil.toJson(resutlObj);
	}

	/**
	 * 住所検索.
	 */
	@RequestMapping(value="/user/s20f001_address", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getZipInfo(HttpServletRequest request, Model model) {

    	Map<String, Object> applyObj = new HashMap<String, Object>();

	    String zipCd = request.getParameter("zipCd");

	    List<S00MPostal> dto = this.service.selectZip(zipCd);
        if (dto != null) {
        	applyObj.put("zipInfo", dto);
        }

		return JSON.encode(dto);
	}

}
