package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 郵便番号マスタ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s00_m_postal")
public class S00MPostal {

    /** 通番 */
    @Id
    @Column(name = "no")
    public BigDecimal no;

    /** 全国地方公共団体コード */
    @Column(name = "local_cd")
    public String localCd;

    /** 郵便番号（旧） */
    @Column(name = "zip_cd_old")
    public String zipCdOld;

    /** 郵便番号 */
    @Column(name = "zip_cd")
    public String zipCd;

    /** 都道府県名_カナ */
    @Column(name = "todoufuken_kana")
    public String todoufukenKana;

    /** 市区町村名_カナ */
    @Column(name = "sikutyouson_kana")
    public String sikutyousonKana;

    /** 町域名_カナ */
    @Column(name = "tyouiki_kana")
    public String tyouikiKana;

    /** 都道府県名_漢字 */
    @Column(name = "todoufuken_kanji")
    public String todoufukenKanji;

    /** 市区町村名_漢字 */
    @Column(name = "sikutyouson_kanji")
    public String sikutyousonKanji;

    /** 町域名_漢字 */
    @Column(name = "tyouiki_kanji")
    public String tyouikiKanji;

    /** 重複郵便番号フラグ */
    @Column(name = "multi_flg")
    public String multiFlg;

    /** 小字毎に起番フラグ */
    @Column(name = "small_flg")
    public String smallFlg;

    /** 丁目フラグ */
    @Column(name = "tyoume_flg")
    public String tyoumeFlg;

    /** 更新フラグ */
    @Column(name = "update_flg")
    public String updateFlg;

    /** 変更理由 */
    @Column(name = "update_note")
    public String updateNote;
}