package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 稼働明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_working_detail")
public class S10TWorkingDetail {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** プロジェクトコード */
    @Id
    @Column(name = "pj_cd")
    public String pjCd;

    /** 稼働年月 */
    @Id
    @Column(name = "working_month")
    public String workingMonth;

    /** 稼働時間 */
    @Column(name = "working_times")
    public BigDecimal workingTimes;

    /** 単価 */
    @Column(name = "unit_amount")
    public BigDecimal unitAmount;

    /** 原価 */
    @Column(name = "cost_amount")
    public BigDecimal costAmount;

    /** 備考 */
    @Column(name = "note")
    public String note;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}