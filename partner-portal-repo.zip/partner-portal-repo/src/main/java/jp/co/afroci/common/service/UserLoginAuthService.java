package jp.co.afroci.common.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomLoginUserDao;
import jp.co.afroci.common.domain.custom.CustomLoginUserRolesDao;
import jp.co.afroci.common.domain.dao.S10TEmpProfileDao;
import jp.co.afroci.common.domain.entity.S00MRoles;
import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.util.CipherUtil;
import jp.co.afroci.common.util.DataCopyUtil;

/**
 * 認証を扱うService
 */
@Service
public class UserLoginAuthService implements UserDetailsService {

	@Autowired
	private CustomLoginUserDao dao;
	@Autowired
	private CustomLoginUserRolesDao customRolesDao;
	@Autowired
	private S10TEmpProfileDao profiledao;
	@Autowired
	private UserRolesService userServer;

	/**
	 * ログインユーザー情報を読み込む
	 */
	public S00MUser loadUserByUserCd(String userCd) throws UsernameNotFoundException {
		S00MUser user = dao.selectByUserCd(userCd);
		if (user == null) {
			throw new UsernameNotFoundException(userCd + "ユーザーIDが不正です。");
		}
		return user;
	}

	/**
	 * ユーザー情報を読み込み
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		if (StringUtils.isBlank(username)) {
			throw new UsernameNotFoundException(username + "ユーザーIDが未入力です");
		}

		S00MUser user = dao.selectByLoginId(username);
		if (user == null) {
			throw new UsernameNotFoundException(username + "ユーザーIDが不正です。");
		}

		S10TEmpProfile profile = profiledao.selectById(user.userCd);
		if (profile != null && StringUtils.isNotEmpty(profile.kanjiSei)) {
			user.loginUserName = profile.kanjiSei + " " + profile.kanjiMei;
		}

		List<S00MRoles> userRoles = customRolesDao.selectByUserCd(user.userCd);
		if (userRoles == null || userRoles.size() == 0) {
			throw new UsernameNotFoundException("ユーザーIDが不正です。");
		}

		LoginUserDto loginUser = DataCopyUtil.copyTo(user, LoginUserDto.class);
		loginUser.setUserRoles(userRoles);
		return loginUser;
	}

	/**
	 * ユーザーのパスワードをれセット
	 *
	 * @param email
	 */
	public boolean resetUserPassword(String userCd, String oldPass, String newPass) {
		S00MUser user = dao.selectByUserCd(userCd);
		if (user == null) {
			throw new UsernameNotFoundException(userCd + "ユーザーIDが不正です。");
		}
		try {
			String oldAESPWD = CipherUtil.encrypt(oldPass, CipherUtil.key, CipherUtil.ALGORITHM_AES);
			if (user.password.compareTo(oldAESPWD) == 0) {
				String newPassword = CipherUtil.encrypt(newPass, CipherUtil.key, CipherUtil.ALGORITHM_AES);
				user.password = newPassword;
				userServer.update(user);
				return true;
			}
		} catch (Exception e) {
			throw new UsernameNotFoundException(userCd + "ユーザーパスワード認証失敗です。");
		}
		return false;
	}

}