package jp.co.afroci.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TCompanyAnkenDao;
import jp.co.afroci.common.domain.entity.S11TCompanyAnken;

@Service
public class AppCompanyAnkenService extends AbstractService {
	@Autowired
	private S11TCompanyAnkenDao dao;

	public S11TCompanyAnken getCompanyMessage(String userCd) {
		return dao.selectByMaxBusinessIdUserId(userCd);
	}

	public void insertCompanyMessage(S11TCompanyAnken entity) {
		dao.insert(entity);
	}

	public void updateCompanyMessage(S11TCompanyAnken entity) {
		dao.update(entity);
	}

	public void deleteCompanyMessage(S11TCompanyAnken entity) {
		dao.delete(entity);
	}
}
