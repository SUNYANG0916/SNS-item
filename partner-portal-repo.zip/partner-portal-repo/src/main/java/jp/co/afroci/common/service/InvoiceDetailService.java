package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS20TInvoiceDetailDao;
import jp.co.afroci.common.domain.dao.S20TInvoiceDetailDao;
import jp.co.afroci.common.domain.entity.S20TInvoiceDetail;

/**
 * 請求先明細情報を取り扱うService
 */
@Service
public class InvoiceDetailService extends AbstractService {

	@Autowired
	private S20TInvoiceDetailDao dao;

	@Autowired
	private CustomS20TInvoiceDetailDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S20TInvoiceDetail entity) {
		return dao.insert((S20TInvoiceDetail) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S20TInvoiceDetail entity) {
		return dao.update((S20TInvoiceDetail) super.getEntity(entity));
	}

	/**
	 * 削除登録.
	 */
	public int delete(S20TInvoiceDetail entity) {
		return dao.delete(entity);
	}

	/**
	 * 請求書明細取得.
	 */
	public List<S20TInvoiceDetail> selectByInvoiceDetail(String invoiceNo) {
		return customDao.selectByInvoiceAll(invoiceNo);
	}
}
