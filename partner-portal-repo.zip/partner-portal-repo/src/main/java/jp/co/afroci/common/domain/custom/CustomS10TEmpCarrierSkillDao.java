package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.dto.EmpSkillDto;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TEmpCarrierSkillDao {

    /**
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    List<S10TEmpCarrierSkill> selectAll();

    /**
     * @param userCd
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    List<S10TEmpCarrierSkill> selectByUserCd(String userCd);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();

    /**
     * @param userCd
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    List<EmpSkillDto> selectEmpOs(String userCd);

    /**
     * @param userCd
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    List<EmpSkillDto> selectEmpDb(String userCd);

    /**
     * @param userCd
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    List<EmpSkillDto> selectEmpProgram(String userCd);

}