package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS20TOrderDetailDao;
import jp.co.afroci.common.domain.dao.S20TOrderDetailDao;
import jp.co.afroci.common.domain.entity.S20TOrderDetail;

/**
 * 見積明細情報を取り扱うService
 */
@Service
public class OrderDetailService extends AbstractService {

	@Autowired
	private S20TOrderDetailDao dao;

	@Autowired
	private CustomS20TOrderDetailDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S20TOrderDetail entity) {
		return dao.insert((S20TOrderDetail) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S20TOrderDetail entity) {
		return dao.update((S20TOrderDetail) super.getEntity(entity));
	}

	/**
	 * 削除登録.
	 */
	public int delete(S20TOrderDetail entity) {
		return dao.delete(entity);
	}

	/**
	 * 見積書明細取得.
	 */
	public List<S20TOrderDetail> selectByOrderDetail(String orderNo) {
		return customDao.selectByOrderAll(orderNo);
	}
}
