package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S00MUserRoles;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S00MUserRolesDao {

    /**
     * @param userCd
     * @param roleGrpId
     * @return the S00MUserRoles entity
     */
    @Select
    S00MUserRoles selectById(String userCd, String roleGrpId);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S00MUserRoles entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S00MUserRoles entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S00MUserRoles entity);
}