package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TWorkingReport;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 */
@Dao
@ConfigAutowireable
public interface S10TWorkingReportDao {

    /**
     * @param userCd
     * @param workingDate
     * @return the S10TWorkingReport entity
     */
    @Select
    S10TWorkingReport selectById(String userCd, String workingDate);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TWorkingReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TWorkingReport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TWorkingReport entity);
}