package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S30TTravelEstimate;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS30TTravelEstimateDao {

    /**
     * @return the S20TEstimate entity
     */
    @Select
    List<S30TTravelEstimate> selectAll(String conditions, String deleteFlag);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();
}