package jp.co.afroci.common.dto;

import java.time.LocalDate;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * 取引先マスタ検索DTO
 */
@Data
@Entity
public class MasterEstimateDto {

	/** 見積番号. */
	public String estimateNo;
	/** 見積名. */
	public String estimateName;
	/** 請求先_取引先番号. */
	public String suppliersToNo;
	/** 請求先_取引先名. */
	public String suppliersToName;
	/** 請求元_取引先番号. */
	public String suppliersFromNo;
	/** 請求元_取引先名. */
	public String suppliersFromName;

	/** 請求元_郵便番号. */
	public String postalCode;

	/** 請求元_住所１. */
	public String address1;

	/** 請求元_住所２. */
	public String address2;

	/** 請求元_住所３. */
	public String address3;

	/** 請求元_住所４. */
	public String address4;

	/** 請求元_代表者. */
	public String pepresentative;

	/** 請求元_電話. */
	public String tel;

	/** 請求元_FAX. */
	public String fax;

	/** 銀行コード. */
	public String ginkoCd;

	/** 銀行名. */
	public String ginkoMei;

	/** 支店番号. */
	public String shitenNo;

	/** 支店名. */
	public String shitenMei;

	/** 口座種別. */
	public String kouzaType;

	/** 口座番号. */
	public String kouzaNo;

	/** 口座名. */
	public String kouzaMei;

	/** 開始日. */
	public LocalDate startDate;

	/** 終了日. */
	public LocalDate endDate;


}
