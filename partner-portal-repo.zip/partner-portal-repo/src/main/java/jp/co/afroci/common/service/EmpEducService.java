package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpEducDao;
import jp.co.afroci.common.domain.dao.S10TEmpEducDao;
import jp.co.afroci.common.domain.entity.S10TEmpEduc;

/**
 * 学歴情報を取り扱うService
 */
@Service
public class EmpEducService extends AbstractService {

	@Autowired
	private S10TEmpEducDao dao;
	@Autowired
	private CustomS10TEmpEducDao customDao;

	/**
	 * 新規登録
	 */
	public int insert(S10TEmpEduc entity) {
		return dao.insert((S10TEmpEduc) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpEduc entity) {
		return dao.update((S10TEmpEduc) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpEduc entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S10TEmpEduc selectId(String userCd, int sequence) {
		return dao.selectById(userCd, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpEduc> selectUser(String userCd) {
		return customDao.selectByUserCd(userCd);
	}

	/**
	 * 全件検索.
	 */
	public List<S10TEmpEduc> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}