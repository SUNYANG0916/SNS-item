package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 請求書明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s20_t_estimate_detail")
public class S20TEstimateDetail {

    /** 請求書番号 */
    @Id
    @Column(name = "estimate_no")
    public String estimateNo;

    /** 行番号 */
    @Id
    @Column(name = "row_number")
    public Integer rowNumber;

    /** 項目 */
    @Column(name = "working_info")
    public String workingInfo;

    /** 稼働日 */
    @Column(name = "working_days")
    public BigDecimal workingDays;

    /** 数量(人月) */
    @Column(name = "quantity")
    public BigDecimal quantity;

    /** 単価 */
    @Column(name = "unit_amount")
    public BigDecimal unitAmount;

    /** 金額 */
    @Column(name = "amount")
    public BigDecimal amount;

    /** 備考 */
    @Column(name = "note")
    public String note;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}