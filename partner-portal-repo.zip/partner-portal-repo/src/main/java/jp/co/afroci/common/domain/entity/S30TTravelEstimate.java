package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 旅行見積書
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s30_t_travel_estimate")
public class S30TTravelEstimate {

    /** 旅行番号 */
    @Id
    @Column(name = "travel_no")
    public String travelNo;

    /** コース名 */
    @Column(name = "course_name")
    public String courseName;

    /** 期間_開始日 */
    @Column(name = "period_s")
    public LocalDate periodS;

    /** 期間_終了日 */
    @Column(name = "period_e")
    public LocalDate periodE;

    /** 数量(人数) */
    @Column(name = "quantity")
    public BigDecimal quantity;

    /** 請求先取引先コード */
    @Column(name = "suppliers_to_no")
    public String suppliersToNo;

    /** 請求先取引先名称 */
    @Column(name = "suppliers_to_name")
    public String suppliersToName;

    /** 請求元取引先コード */
    @Column(name = "suppliers_from_no")
    public String suppliersFromNo;

    /** 請求元取引先名称 */
    @Column(name = "suppliers_from_name")
    public String suppliersFromName;

    /** 代表者 */
    @Column(name = "suppliers_from_pepresentative")
    public String suppliersFromPepresentative;

    /** 郵便番号 */
    @Column(name = "suppliers_from_postal_code")
    public String suppliersFromPostalCode;

    /** 住所（都道府県） */
    @Column(name = "suppliers_from_address_1")
    public String suppliersFromAddress1;

    /** 住所（市区町村） */
    @Column(name = "suppliers_from_address_2")
    public String suppliersFromAddress2;

    /** 住所（番地以降） */
    @Column(name = "suppliers_from_address_3")
    public String suppliersFromAddress3;

    /** ビル名／部屋 */
    @Column(name = "suppliers_from_address_4")
    public String suppliersFromAddress4;

    /** 電話 */
    @Column(name = "suppliers_from_tel")
    public String suppliersFromTel;

    /** 代表Fax */
    @Column(name = "suppliers_from_fax")
    public String suppliersFromFax;

    /** 担当者名 */
    @Column(name = "staff_name")
    public String staffName;

    /** 携帯電話 */
    @Column(name = "mobile_number")
    public String mobileNumber;

    /** 金額合計 */
    @Column(name = "amount_total")
    public BigDecimal amountTotal;

    /** 宿泊費備考 */
    @Column(name = "note1")
    public String note1;

    /** 交通費備考 */
    @Column(name = "note2")
    public String note2;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}