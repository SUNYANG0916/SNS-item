package jp.co.afroci.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.TContactDao;
import jp.co.afroci.common.domain.entity.TContact;

@Service
public class ContactService extends AbstractService {
	@Autowired
	private TContactDao dao;

	public int save(TContact contact) {
		return dao.insert(contact);
	}

}
