package jp.co.afroci.portal.web.controller.api;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.domain.entity.S00MUserRoles;
import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.domain.entity.S10TEmpQua;
import jp.co.afroci.common.dto.EmpInfoDto;
import jp.co.afroci.common.dto.EmpSkillDto;
import jp.co.afroci.common.service.EmpCarrierSkillService;
import jp.co.afroci.common.service.EmpProfileService;
import jp.co.afroci.common.service.EmpQualificationService;
import jp.co.afroci.common.service.UserRolesService;
import jp.co.afroci.common.util.CipherUtil;
import jp.co.afroci.portal.web.WebAppApplication;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.report.TemplateCarrierSkill;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * 社員情報コントローラ.
 */
@RestController
public class UserRolesApiController extends AbstractApiController {

	@Autowired
	private UserRolesService userRoleService;

	@Autowired
	private EmpProfileService empProfileService;

	@Autowired
	private EmpQualificationService empQualificationService;

	@Autowired
	private EmpCarrierSkillService empCarrierSkillService;

	/**
	 * ユーザ情報初期化.
	 */
	@RequestMapping(value="/user/s00f004_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S00F004, null);
		// 項目マスタリスト取得対象
		String[][] items = {
			 {Constants.ITEMS.ITEM_30015,"selBusyoCd", "" ,""}
			,{Constants.ITEMS.ITEM_30017,"selEmploymentStatus", "" ,""}
			,{Constants.ITEMS.ITEM_30018,"selEmploymentType", "" ,""}
			,{Constants.ITEMS.ITEM_30023,"selUserRole", "" ,""}
		};

		this.userRoleService.setSelectItems(applyObj, items);

		return JSON.encode(applyObj);
	}

	/**
	 * ユーザ一覧検索.
	 */
	@RequestMapping(value="/user/s00f004_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        String conditions = request.getParameter("conditions");
        if (!conditions.equals("")) {
        	conditions = "%" + conditions + "%";
        } else {
        	conditions = null;
        }
        List<EmpInfoDto> list = this.userRoleService.selectAll(conditions);
        // セッションへ保持
        super.setUserList(list);
        for (int i = 0; i < list.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            EmpInfoDto user = list.get(i);
            // ユーザ行番号
            map.put("user_row", i);
            map.put("user_name", user.loginUserName);
            map.put("user_initial", user.userInitial);
            map.put("disp_detail1", user.dispDetail1);
            map.put("disp_detail2", user.dispDetail2);
            map.put("disp_detail3", user.dispDetail3);
            map.put("disp_detail4", user.dispDetail4);
            map.put("disp_detail5", user.dispDetail5);
            map.put("disp_detail6", user.dispDetail6);
            map.put("disp_detail7", user.dispDetail7);
            map.put("disp_detail8", user.dispDetail8);
            map.put("disp_detail9", "1");
//            // 基本情報
//            S10TEmpProfile s10TEmpProfile = this.empProfileService.selectId(user.userCd);
//            if (s10TEmpProfile != null) {
//                map.put("disp_detail1", "1");
//                map.put("user_initial", s10TEmpProfile.eijiSei.substring(0, 1) + "." + s10TEmpProfile.eijiMei.substring(0, 1));
//            } else {
//                map.put("disp_detail1", "0");
//            }
//        	// 学歴情報
//        	List<S10TEmpEduc> empEduc = this.empEducService.selectUser(user.userCd);
//        	if (empEduc != null && empEduc.size() > 0) {
//            	map.put("disp_detail2", "1");
//        	} else {
//            	map.put("disp_detail2", "0");
//        	}
//        	// 資格情報
//        	List<S10TEmpQua> empQua = this.empQualificationService.selectUser(user.userCd);
//        	if (empQua != null && empQua.size() > 0) {
//            	map.put("disp_detail3", "1");
//        	} else {
//            	map.put("disp_detail3", "0");
//        	}
//        	// 職務情報
//        	List<S10TEmpCarrier> empCarrier = this.empCarrierService.selectUser(user.userCd);
//        	if (empCarrier != null && empCarrier.size() > 0) {
//            	map.put("disp_detail4", "1");
//        	} else {
//            	map.put("disp_detail4", "0");
//        	}
//        	// スキル情報
//        	List<S10TEmpCarrierSkill> empCarrierSkill = this.empCarrierSkillService.selectUser(user.userCd);
//        	if (empCarrierSkill != null && empCarrierSkill.size() > 0) {
//            	map.put("disp_detail5", "1");
//            	map.put("disp_detail6", "1");
//        	} else {
//            	map.put("disp_detail5", "0");
//            	map.put("disp_detail6", "0");
//        	}
//        	// 申請書
//        	map.put("disp_detail7", "1");
        	result.add(map);
        }

        applyObj.put("tbl_user_list", result);


		return JSON.encode(applyObj);
	}

	/**
	 * ユーザ詳細検索.
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 */
	@RequestMapping(value="/user/s00f004_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        Map<String, Object> applyObj = new HashMap<String, Object>();

		String userRow = request.getParameter("userRow");
		if (userRow != null) {
			EmpInfoDto user = super.getUserList().get(Integer.parseInt(userRow));
			// パスワード復号化
			user.password = CipherUtil.decrypt(user.password, CipherUtil.key, CipherUtil.ALGORITHM_AES);
	        applyObj.put("tbl_user_info", user);

			List<S00MUserRoles> roles = this.userRoleService.selectByUser(user.userCd);
			applyObj.put("tbl_role_list", roles);
		}

		return JSON.encode(applyObj);
	}

	/**
	 * ユーザ情報登録.
	 *
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 */
	@RequestMapping(value="/user/s00f004_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(HttpServletRequest request, @RequestBody Map<String, String> model)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		S00MUser entity = this.userRoleService.selectId(model.get("userCd"));

		// パスワード暗号化
		S00MUser dto = new S00MUser();
		dto.password = CipherUtil.encrypt(model.get("password"), CipherUtil.key, CipherUtil.ALGORITHM_AES);
		String accessKeyExpirDate = model.get("accessKeyExpirDate");
		if(StringUtils.isEmpty(accessKeyExpirDate)) {
			accessKeyExpirDate = "9999-12-31";
		}
		dto.accessKeyExpirDate = LocalDateTime.parse(accessKeyExpirDate + " 00:00:00"
				, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		dto.userCd = model.get("userCd");
		dto.loginId = model.get("loginId");
		dto.loginUserName = model.get("loginUserName");
		dto.acountLocked = model.get("acountLocked");
		dto.busyoCd = model.get("busyoCd");
		dto.employmentStatus = model.get("employmentStatus");
		dto.employmentType = model.get("employmentType");
		String failureCount = model.get("loginFailureCount");
		if(StringUtils.isEmpty(failureCount)) {
			failureCount = "0";
		}
		dto.loginFailureCount = Integer.valueOf(failureCount);

		if (entity == null) {
			// 新規
			dto.loginFailureCount = 0;

			this.userRoleService.insert(dto);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			dto.createUser = entity.createUser;
			dto.createDate = entity.createDate;

			this.userRoleService.update(dto);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * ユーザロール更新.
	 */
	@RequestMapping(value="/user/s00f004_updateUserRole", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	private String updateUserRole(HttpServletRequest request, @RequestBody List<S00MUserRoles> inEntitys) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		// 一括削除
		List<S00MUserRoles> details = this.userRoleService.selectByUser(inEntitys.get(0).userCd);
		for (S00MUserRoles S00MUserRole : details) {
			this.userRoleService.deleteRole(S00MUserRole);
		}

		// 一括登録
		for (S00MUserRoles entity : inEntitys) {
			this.userRoleService.insertRole(entity);
		}
		resutlObj.put("msg", "登録処理が完了しました。");
		return JSON.encode(resutlObj);
	}

	/**
	 * ユーザ情報削除.
	 */
	@RequestMapping(value="/user/s00f004_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S00MUser dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			userRoleService.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException
				| SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * ユーザロール情報削除.
	 */
	@RequestMapping(value="/user/s00f004_deleteUserRole", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String deleteUserRole(@RequestBody S00MUserRoles dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			userRoleService.deleteRole(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException
				| SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

    /**
     * スキル票をダウンロード.
     * @throws Exception 例外発生
     * */
    @RequestMapping(value = {"/user/download"}, method = RequestMethod.GET)
    public String download(HttpServletRequest request,HttpServletResponse response) throws Exception {
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition","attachment;");
		response.setHeader("Cache-Control", "private");
		response.setHeader("Pragma", "");

		OutputStream out = null;

		try {
			String userCd = super.getUserInfo().getUserCd();
			EmpInfoDto user = super.getTargetUser();
			if (user != null) {
				userCd = super.getTargetUser().userCd;
			}
			Object objRow = request.getParameter("userRow");
			if (objRow != null) {
				String userRow = (String) request.getParameter("userRow");
				userCd = super.getTargetUser(userRow).userCd;
			}

			// 基本情報
			S10TEmpProfile s10TEmpProfile = this.empProfileService.selectId(userCd);
			// 資格情報
			List<S10TEmpQua> s10TEmpQuas = this.empQualificationService.selectUser(userCd);
			// スキル情報
			List<S10TEmpCarrierSkill> s10TEmpCarrierSkills = this.empCarrierSkillService.selectUser(userCd);
			TemplateCarrierSkill g001f001 = new TemplateCarrierSkill(super.settingsConfig.getTemplateSkill(), this.userRoleService);

			List<EmpSkillDto> empOsList = this.empCarrierSkillService.selectEmpOs(userCd);
			List<EmpSkillDto> empDbList = this.empCarrierSkillService.selectEmpDb(userCd);
			List<EmpSkillDto> empProgramList = this.empCarrierSkillService.selectEmpProgram(userCd);


			g001f001.makeCarrierSkill(s10TEmpProfile, s10TEmpQuas, s10TEmpCarrierSkills, empOsList, empDbList, empProgramList);
			out = response.getOutputStream();
			g001f001.wkBook.write(out);

			String classPath = WebAppApplication.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String userName = s10TEmpProfile.eijiSei.substring(0, 1) + "." + s10TEmpProfile.eijiMei.substring(0, 1);
			FileOutputStream outExcel = new FileOutputStream(classPath + "static/js/report/スキルシート（" + userName + "）.xlsx");
			g001f001.wkBook.write(outExcel);
			outExcel.close();

		} finally {
			if (out != null) {
				out.close();
			}
		}

		return null;
    }
}
