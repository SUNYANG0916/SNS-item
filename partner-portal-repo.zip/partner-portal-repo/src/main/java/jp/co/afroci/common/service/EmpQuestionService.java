package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10MQuestionChoicesDao;
import jp.co.afroci.common.domain.custom.CustomS10MQuestionDao;
import jp.co.afroci.common.domain.custom.CustomS10MQuestionDetailDao;
import jp.co.afroci.common.domain.custom.CustomS10TEmpQuestionDao;
import jp.co.afroci.common.domain.dao.S10MQuestionDetailDao;
import jp.co.afroci.common.domain.dao.S10TEmpQuestionDao;
import jp.co.afroci.common.domain.entity.S10MQuestion;
import jp.co.afroci.common.domain.entity.S10MQuestionChoices;
import jp.co.afroci.common.domain.entity.S10MQuestionDetail;
import jp.co.afroci.common.domain.entity.S10TEmpQuestion;

/**
 * 質問情報を取り扱うService
 */
@Service
public class EmpQuestionService extends AbstractService {

	@Autowired
	private CustomS10MQuestionDao customDao;

	@Autowired
	private S10MQuestionDetailDao detailDao;

	@Autowired
	private CustomS10MQuestionDetailDao customDetailDao;

	@Autowired
	private CustomS10MQuestionChoicesDao customChoicesDao;

	@Autowired
	private CustomS10TEmpQuestionDao empQuestionDao;

	@Autowired
	private S10TEmpQuestionDao dao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpQuestion entity) {
		return dao.insert((S10TEmpQuestion) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpQuestion entity) {
		return dao.update((S10TEmpQuestion) super.getEntity(entity));
	}


	/**
	 * 主キー検索.
	 */
	public S10MQuestion selectId(String questionId) {
		return customDao.selectById(questionId);
	}

	/**
	 * 質問全件検索.
	 */
	public List<S10MQuestion> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * 質問明細全件検索.
	 */
	public List<S10MQuestionDetail> selectDetailAll(String questionId) {
		return customDetailDao.selectAll(questionId);
	}

	/**
	 * 質問明細検索.
	 */
	public S10MQuestionDetail selectDetail(String questionId, Integer detailsNo) {
		return detailDao.selectById(questionId, detailsNo);
	}

	/**
	 * 質問明細選択肢全件検索.
	 */
	public List<S10MQuestionChoices> selectChoicesDetailAll(String questionId, Integer detailsNo) {
		return customChoicesDao.selectAll(questionId, detailsNo);
	}


	/**
	 * 全件検索.
	 */
	public List<S10TEmpQuestion> selectDetailAll(String userCd, String questionId) {
		return empQuestionDao.selectAll(userCd, questionId);
	}

	/**
	 * 全件検索.
	 */
	public S10TEmpQuestion selectDetailById(String userCd, String questionId, Integer detailsNo) {
		return empQuestionDao.selectDetailById(userCd, questionId, detailsNo);
	}
}