package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * 学歴情報
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_educ")
public class S10TEmpEduc {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 学校名 */
    @Column(name = "gakkou_mei")
    public String gakkouMei;

    /** 学部 */
    @Column(name = "gakubu")
    public String gakubu;

    /** 学科 */
    @Column(name = "gakka")
    public String gakka;

    /** 入学年月 */
    @Column(name = "nyugaku_ym")
    public String nyugakuYm;

    /** 卒業年月 */
    @Column(name = "sotugyo_ym")
    public String sotugyoYm;

    /** 文理区分 */
    @Column(name = "bunri_kbn")
    public String bunriKbn;

    /** 最終学歴 */
    @Column(name = "saisyu_gakureki_kbn")
    public String saisyuGakurekiKbn;

    /** 技術スキル有無 */
    @Column(name = "it_skil_kbn")
    public String itSkilKbn;

    /** 技術スキル詳細 */
    @Column(name = "it_skil_syosai")
    public String itSkilSyosai;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}