package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TEmpQuestion;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TEmpQuestionDao {

    /**
     * @param userCd
     * @param questionId
     * @return the S10TEmpQuestion entity
     */
    @Select
    List<S10TEmpQuestion> selectAll(String userCd, String questionId);

    /**
     * @param userCd
     * @param questionId
     * @return the S10TEmpQuestion entity
     */
    @Select
    S10TEmpQuestion selectDetailById(String userCd, String questionId, Integer detailsNo);

}