package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.domain.entity.S10TEmpQuestion;
import jp.co.afroci.common.dto.EmpInfoDto;
import jp.co.afroci.common.service.EmpCarrierSkillService;
import jp.co.afroci.common.service.EmpProfileService;
import jp.co.afroci.common.service.EmpQuestionService;
import jp.co.afroci.common.service.UserRolesService;
import jp.co.afroci.portal.web.config.SettingsConfig;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;

/**
 * 部署要員管理コントローラ.
 */
@RestController
public class EmpDepartmentManageApiController extends AbstractApiController {

	@Autowired
	SettingsConfig settingsConfig;

	@Autowired
	private UserRolesService userRoleService;

	@Autowired
	private EmpProfileService empProfileService;
	@Autowired
	private EmpCarrierSkillService empCarrierSkillService;
	@Autowired
	private EmpQuestionService empQuestionService;

	/**
	 * ユーザ情報初期化.
	 */
	@RequestMapping(value = "/user/s00f101_init", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S00F101, null);
		return JSON.encode(applyObj);
	}

	/**
	 * ユーザ一覧検索.
	 */
	@RequestMapping(value = "/user/s00f101_search", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		String conditions = request.getParameter("conditions");
		if (!conditions.equals("")) {
			conditions = "%" + conditions + "%";
		} else {
			conditions = null;
		}
		List<EmpInfoDto> tmplist = this.userRoleService.selectAll(conditions);
        // セッションへ保持
        super.setUserList(tmplist);

		for (int i = 0; i < tmplist.size(); i++) {
			if (super.getUserInfo().getBusyoCd().equals(tmplist.get(i).busyoCd)) {

				Map<String, Object> map = new HashMap<String, Object>();
				EmpInfoDto user = tmplist.get(i);
				// ユーザ行番号
				map.put("user_row", i);
				map.put("user_initial", user.loginUserName);

				// 基本情報
				S10TEmpProfile s10TEmpProfile = this.empProfileService.selectId(user.userCd);
				if (s10TEmpProfile != null) {
					if(s10TEmpProfile.updateDate == null) {
						s10TEmpProfile.updateDate = s10TEmpProfile.createDate;
					}
					map.put("kihonYmd", s10TEmpProfile.updateDate.toLocalDate());
				} else {
					map.put("kihonYmd", "");
				}

				// スキル情報
				List<S10TEmpCarrierSkill> skils = this.empCarrierSkillService.selectUser(user.userCd);
				if (skils != null && skils.size() > 0) {
					if(skils.get(0).updateDate == null) {
						skils.get(0).updateDate = skils.get(0).createDate;
					}
					map.put("skilYmd", skils.get(0).updateDate.toLocalDate());
				} else {
					map.put("skilYmd", "");
				}

				// 個人情報教育実施状況
				List<S10TEmpQuestion> qualifications = this.empQuestionService.selectDetailAll(user.userCd, "5");
				if (qualifications != null && qualifications.size() > 0) {
					if(qualifications.get(0).updateDate == null) {
						qualifications.get(0).updateDate = qualifications.get(0).createDate;
					}
					map.put("securityYmd", qualifications.get(0).updateDate.toLocalDate());
				} else {
					map.put("securityYmd", "");
				}

				result.add(map);
			}
		}


		applyObj.put("tbl_user_list", result);

		return JSON.encode(applyObj);
	}

}
