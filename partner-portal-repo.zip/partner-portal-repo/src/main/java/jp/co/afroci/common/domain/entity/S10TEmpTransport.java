package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 交通費申請
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_transport")
public class S10TEmpTransport {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 対象年月 */
    @Id
    @Column(name = "trans_ym")
    public String transYm;

    /** 申請番号 */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 対象日 */
    @Column(name = "trans_date")
    public String transDate;

    /** 対象ルート出発地 */
    @Column(name = "trans_root_start")
    public String transRootStart;

    /** 対象ルート到着地 */
    @Column(name = "trans_root_end")
    public String transRootEnd;

    /** 交通機関 */
    @Column(name = "trans_facilities")
    public String transFacilities;

    /** 対象金額 */
    @Column(name = "trans_amount")
    public BigDecimal transAmount;

    /** 往復 */
    @Column(name = "round_trip")
    public String roundTrip;

    /** 備考 */
    @Column(name = "note")
    public String note;

    /** 承認者コード */
    @Column(name = "approval_user_cd")
    public String approvalUserCd;

    /** 承認日 */
    @Column(name = "approval_date")
    public LocalDate approvalDate;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}