package jp.co.afroci.common.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;

/**
 * アプリケーション画面DTO
 */
@Data
public class AbstractDto {

    /** 削除フラグ */
	public String deleteFlg;

    /** 作成者 */
    public String createUser;

    /** 作成日時 */
    public LocalDateTime createDate;

    /** 更新カウンタ */
    public BigDecimal updateCnt;

    /** 更新者 */
    public String updateUser;

    /** 更新日時 */
    public LocalDateTime updateDate;


	/**
	 * @return deleteFlg
	 */
	public String getDeleteFlg() {
		return deleteFlg;
	}

	/**
	 * @param deleteFlg セットする deleteFlg
	 */
	public void setDeleteFlg(String deleteFlg) {
		this.deleteFlg = deleteFlg;
	}

	/**
	 * @return createUser
	 */
	public String getCreateUser() {
		return createUser;
	}

	/**
	 * @param createUser セットする createUser
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	/**
	 * @return createDate
	 */
	public LocalDateTime getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate セットする createDate
	 */
	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return updateCnt
	 */
	public BigDecimal getUpdateCnt() {
		return updateCnt;
	}

	/**
	 * @param updateCnt セットする updateCnt
	 */
	public void setUpdateCnt(BigDecimal updateCnt) {
		this.updateCnt = updateCnt;
	}

	/**
	 * @return updateUser
	 */
	public String getUpdateUser() {
		return updateUser;
	}

	/**
	 * @param updateUser セットする updateUser
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	/**
	 * @return updateDate
	 */
	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate セットする updateDate
	 */
	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}
}
