package jp.co.afroci.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS00MMenuDao;
import jp.co.afroci.common.domain.entity.S00MMenu;

/**
 * メニュー取り扱うService
 */
@Service
public class MenuService extends AbstractService {

    @Autowired
    private CustomS00MMenuDao customDao;

	public List<S00MMenu> getMenuList(String menuType, String userCd) {
        return customDao.selectAll(userCd, menuType);
    }

	public List<Map<String, String>> getMenuListMap(String menuType, String userCd) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        for (S00MMenu s00MMenu : customDao.selectAll(userCd, menuType)) {
            Map<String, String> map = new HashMap<String, String>();
            map.put("menuNm", s00MMenu.menuNm);
            map.put("applyId", s00MMenu.applyId);
            map.put("menuId", s00MMenu.menuId);
            list.add(map);
        }
        return list;
	}

}