package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TScheduleDetail;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10TScheduleDetailDao {

    /**
     * @param sequence
     * @param rowNo
     * @return the S10TScheduleDetail entity
     */
    @Select
    S10TScheduleDetail selectById(Integer sequence, Integer rowNo);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TScheduleDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TScheduleDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TScheduleDetail entity);
}