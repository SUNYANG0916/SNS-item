package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * 項目マスタ情報DTO
 */
@Data
@Entity
public class ItemInfoDto {

	/** 項目区分コード. */
	public String itemType;
	/** 項目コード. */
	public String itemCd;
	/** 項目値. */
	public String itemVal;
	/** 項目テキスト. */
	public String itemTxt;
}
