package jp.co.afroci.portal.web.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import jp.co.afroci.portal.web.config.SettingsConfig;

/**
 * 認証成功時のハンドラ
 */
@Component
public class UserLoginSuccessHandler implements AuthenticationSuccessHandler {
	@Autowired
	SettingsConfig settingsConfig;

    /**
     * 認証成功時
     */
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
            Authentication authentication) throws IOException, ServletException {

    	// セッションタイムアウト設定
    	request.getSession().setMaxInactiveInterval(settingsConfig.getSessionTimeout());

        // ログイン成功時トップ画面遷移
        response.sendRedirect(request.getContextPath() + "/user/apply?applyId=s00f001");

    }

}