package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 見積書
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s20_t_estimate")
public class S20TEstimate {

    /** 請求書番号 */
    @Id
    @Column(name = "estimate_no")
    public String estimateNo;

    /** 請求先取引先コード */
    @Column(name = "suppliers_to_no")
    public String suppliersToNo;

    /** 請求先取引先名称 */
    @Column(name = "suppliers_to_name")
    public String suppliersToName;

    /** 代表者 */
    @Column(name = "suppliers_to_pepresentative")
    public String suppliersToPepresentative;

    /** 郵便番号 */
    @Column(name = "suppliers_to_postal_code")
    public String suppliersToPostalCode;

    /** 住所（都道府県） */
    @Column(name = "suppliers_to_address_1")
    public String suppliersToAddress1;

    /** 住所（市区町村） */
    @Column(name = "suppliers_to_address_2")
    public String suppliersToAddress2;

    /** 住所（番地以降） */
    @Column(name = "suppliers_to_address_3")
    public String suppliersToAddress3;

    /** ビル名／部屋 */
    @Column(name = "suppliers_to_address_4")
    public String suppliersToAddress4;

    /** 電話 */
    @Column(name = "suppliers_to_tel")
    public String suppliersToTel;

    /** 代表Fax */
    @Column(name = "suppliers_to_fax")
    public String suppliersToFax;

    /** 請求元取引先コード */
    @Column(name = "suppliers_from_no")
    public String suppliersFromNo;

    /** 請求元取引先名称 */
    @Column(name = "suppliers_from_name")
    public String suppliersFromName;

    /** 代表者 */
    @Column(name = "suppliers_from_pepresentative")
    public String suppliersFromPepresentative;

    /** 郵便番号 */
    @Column(name = "suppliers_from_postal_code")
    public String suppliersFromPostalCode;

    /** 住所（都道府県） */
    @Column(name = "suppliers_from_address_1")
    public String suppliersFromAddress1;

    /** 住所（市区町村） */
    @Column(name = "suppliers_from_address_2")
    public String suppliersFromAddress2;

    /** 住所（番地以降） */
    @Column(name = "suppliers_from_address_3")
    public String suppliersFromAddress3;

    /** ビル名／部屋 */
    @Column(name = "suppliers_from_address_4")
    public String suppliersFromAddress4;

    /** 電話 */
    @Column(name = "suppliers_from_tel")
    public String suppliersFromTel;

    /** 代表Fax */
    @Column(name = "suppliers_from_fax")
    public String suppliersFromFax;

    /** 件名 */
    @Column(name = "matter_name")
    public String matterName;

    /** 内容 */
    @Column(name = "matter_info")
    public String matterInfo;

    /** 期間_開始日 */
    @Column(name = "period_s")
    public LocalDate periodS;

    /** 期間_終了日 */
    @Column(name = "period_e")
    public LocalDate periodE;

    /** 金額合計 */
    @Column(name = "amount_total")
    public BigDecimal amountTotal;

    /** 契約形態 */
    @Column(name = "agreement_type")
    public String agreementType;

    /** 納品日 */
    @Column(name = "release_date")
    public String releaseDate;

    /** 納品場所 */
    @Column(name = "release_lot")
    public String releaseLot;

    /** 支払条件 */
    @Column(name = "payment_time")
    public String paymentTime;

    /** 支払手数料 */
    @Column(name = "commission_type")
    public String commissionType;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}