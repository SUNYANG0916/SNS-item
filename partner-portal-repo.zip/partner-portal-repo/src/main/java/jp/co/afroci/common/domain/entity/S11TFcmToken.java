package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s11_t_fcm_token")
public class S11TFcmToken {

    /** */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** */
    @Column(name = "token")
    public String token;

    /** */
    @Column(name = "last_time")
    public LocalDateTime lastTime;

    /** */
    @Column(name = "insert_time")
    public LocalDateTime insertTime;
}