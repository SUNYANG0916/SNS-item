package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MPostal;
import jp.co.afroci.common.domain.entity.S10MSuppliers;
import jp.co.afroci.common.service.SuppliersService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * 取引先マスタコントローラ.
 */
@RestController
public class TorihikiApiController extends AbstractApiController {

	@Autowired
	private SuppliersService service;

	public TorihikiApiController() {
		super();
	}
	/**
	 * 画面初期ロードリクエスト.
	 */
    @RequestMapping(value="/user/s10f002_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S10F002, null);
		// 項目マスタリスト取得対象
		String[][] items = {
				{Constants.ITEMS.ITEM_30030,"selKouzaType", "" ,""},
				{Constants.ITEMS.ITEM_30028,"selSuppliersStatus", "" ,""},
				{Constants.ITEMS.ITEM_30027,"zyuhacchu_souh_list_val", "zyuhacchuSouhusaki", "zyuhacchuSouhName"},
				{Constants.ITEMS.ITEM_30031,"selDelete", "", ""}
		};
		this.service.setSelectItems(applyObj, items);

		return JSON.encode(applyObj);
	}
	/**
	 * 取引先マスタ検索.
	 */
	@RequestMapping(value="/user/s10f002_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();

        // キーワード検索条件
        String conditions = "%" + request.getParameter("cond") + "%";
        String selDelete = request.getParameter("selDelete");
        String deleteFlag = null;
        if (selDelete.equals("30031-001")) {
        	// 有効のみ
        	deleteFlag = Constants.DELETE_FLAG.OFF;
        } else if (selDelete.equals("30031-002")) {
        	// 失効のみ
        	deleteFlag = Constants.DELETE_FLAG.ON;
        }

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (S10MSuppliers entity : service.selectAll(conditions, deleteFlag)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("suppliersNo", entity.suppliersNo);
			map.put("suppliersName", entity.suppliersName);
			map.put("zyuhacchuSouhusaki", this.service.getItemName(entity.zyuhacchuSouhusaki));
			map.put("pepresentative", entity.pepresentative);
			map.put("tel", entity.tel);
			list.add(map);
		}
        applyObj.put("tbl_suppliers_list", list);
		return JSON.encode(applyObj);
	}

	/**
	 * 取引先マスタ詳細検索.
	 */
	@RequestMapping(value="/user/s10f002_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String suppliersNo = request.getParameter("suppliersNo");
        applyObj.put("tbl_suppliers_list", service.selectId(suppliersNo));

		return JSON.encode(applyObj);
	}

	/**
	 * 取引先マスタ登録.
	 */
	@RequestMapping(value="/user/s10f002_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10MSuppliers inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		S10MSuppliers entity = service.selectId(inEntity.suppliersNo);
		inEntity.sort = 1;
		try {
			if (entity == null) {
				// 新規
				String suppliersNo = "000" + String.valueOf(service.selectSeq());
				inEntity.suppliersNo = "T" + suppliersNo.substring(suppliersNo.length() - 4);

				service.insert(inEntity);
				resutlObj.put("msg", "登録処理が完了しました。");
			} else {
				// 更新
				inEntity.createUser = entity.createUser;
				inEntity.createDate = entity.createDate;

				service.update(inEntity);
				resutlObj.put("msg", "更新処理が完了しました。");
			}
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 取引先マスタ削除.
	 */
	@RequestMapping(value="/user/s10f002_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10MSuppliers inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			S10MSuppliers entity = service.selectId(inEntity.suppliersNo);
			entity.deleteFlg = Constants.DELETE_FLAG.ON;
			service.update(entity);
			resutlObj.put("msg", "廃止処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 住所検索.
	 */
	@RequestMapping(value="/user/s10f002_address", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getZipInfo(HttpServletRequest request, Model model) {

    	Map<String, Object> applyObj = new HashMap<String, Object>();

	    String zipCd = request.getParameter("zipCd");

	    List<S00MPostal> dto = this.service.selectZip(zipCd);
        if (dto != null) {
        	applyObj.put("zipInfo", dto);
        }

		return JSON.encode(dto);
	}

}
