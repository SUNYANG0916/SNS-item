package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * メニュー
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s00_m_menu")
public class S00MMenu {

    /** メニューID */
    @Id
    @Column(name = "menu_id")
    public String menuId;

    /** メニュー名 */
    @Column(name = "menu_nm")
    public String menuNm;

    /** メニュー区分 */
    @Column(name = "menu_type")
    public String menuType;

    /** アプリケーションID */
    @Column(name = "apply_id")
    public String applyId;

    /** メニューURL */
    @Column(name = "menu_url")
    public String menuUrl;

    /** メニューパラメタ */
    @Column(name = "menu_param")
    public String menuParam;

    /** ロールID */
    @Column(name = "role_id")
    public String roleId;

    /** ソート順 */
    @Column(name = "sort")
    public Integer sort;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}