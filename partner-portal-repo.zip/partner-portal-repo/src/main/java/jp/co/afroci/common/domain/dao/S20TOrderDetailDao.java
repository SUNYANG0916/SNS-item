package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S20TOrderDetail;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S20TOrderDetailDao {

    /**
     * @param orderNo
     * @param rowNumber
     * @return the S20TOrderDetail entity
     */
    @Select
    S20TOrderDetail selectById(String orderNo, Integer rowNumber);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S20TOrderDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S20TOrderDetail entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S20TOrderDetail entity);
}