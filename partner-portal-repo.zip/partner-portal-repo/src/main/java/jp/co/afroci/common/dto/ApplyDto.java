package jp.co.afroci.common.dto;

import lombok.Data;

/**
 * アプリケーション画面DTO
 */
@Data
public class ApplyDto {

	/** Keys ApplyId. */
	public static final String KEY_APPLY_ID = "applyId";

	/** Keys Context. */
	public static final String KEY_CONTEXT = "context";

	/** Keys JavaScript Path. */
	public static final String KEY_CSJS = "applyJs";

	/** Keys Params. */
	public static final String KEY_PARAMS = "params";

	/** Keys Json. */
	public static final String KEY_JSON = "jsonObj";

	/** Json Object. */
	public String jsonObj;

	/** Keys Json. */
	public static final String KEY_VERSION = "jsVersion";
}
