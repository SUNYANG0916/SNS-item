package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * 社員スキル情報DTO
 */
@Data
@Entity
public class EmpSkillDto {

	/** 社員コード. */
	public String userCd;
	/** 項目値. */
	public String itemVal;
	/** 項目名. */
	public String itemText;
	/** 項目選択. */
	public String selItemVal;

}
