package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS00MItemDao;
import jp.co.afroci.common.domain.custom.CustomS00MItemTypeDao;
import jp.co.afroci.common.domain.dao.S00MItemDao;
import jp.co.afroci.common.domain.dao.S00MItemTypeDao;
import jp.co.afroci.common.domain.entity.S00MItem;
import jp.co.afroci.common.domain.entity.S00MItemType;

/**
 * 資格情報を取り扱うService
 */
@Service
public class ItemMasterService extends AbstractService {

	@Autowired
	private S00MItemDao dao;
	@Autowired
	private CustomS00MItemDao customDao;

	@Autowired
	private S00MItemTypeDao typeDao;
	@Autowired
	private CustomS00MItemTypeDao customTypeDao;

	/**
	 * 新規登録.
	 */
	public int insert(S00MItem entity) {
		return dao.insert((S00MItem) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S00MItem entity) {
		return dao.update((S00MItem) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S00MItem entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S00MItem selectId(String itemType, String itemCd) {
		return dao.selectById(itemType, itemCd);
	}

	/**
	 * 主キー検索.
	 */
	public S00MItemType selectItemTypeId(String itemType) {
		return typeDao.selectById(itemType);
	}

	/**
	 * 主キー検索.
	 */
	public List<S00MItemType> selectItemTypeAll() {
		return customTypeDao.selectAll();
	}

	/**
	 * 項目分類検索.
	 */
	public List<S00MItem> selectByItemType(String itemType, String deleteFlg) {
		return customDao.selectByItemType(itemType, deleteFlg);
	}

	/**
	 * 項目値検索.
	 */
	public S00MItem selectVal(String itemVal) {
		return customDao.selectByItemVal(itemVal);
	}

	/**
	 * 全件検索.
	 */
	public List<S00MItem> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * 項目コード採番.
	 */
	public S00MItem selectItemNumbering(String itemType) {
		return customDao.selectItemNumbering(itemType);
	}
}