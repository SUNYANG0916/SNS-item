package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TEmpQua;
import jp.co.afroci.common.service.EmpQualificationService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * 資格情報コントローラ.
 */
@RestController
public class EmpQualificationApiController extends AbstractApiController {

	@Autowired
	private EmpQualificationService service;

	/**
	 * 資格情報初期化.
	 */
	@RequestMapping(value="/user/s20f003_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F003, request.getParameter("userRow"));
		// 項目マスタリスト取得対象
		String[][] items = {{Constants.ITEMS.ITEM_10001,"selItSkilKbn", "" ,""}};
		this.service.setSelectItems(applyObj, items);

		return JSON.encode(applyObj);
	}

	/**
	 * 資格情報検索.
	 */
	@RequestMapping(value="/user/s20f003_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		// 一覧表示の詰め替え
		for (S10TEmpQua s10TEmpQua : this.service.selectUser(super.getTargetUserCd())) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("sequence", s10TEmpQua.sequence);
			map.put("sikakuMei", s10TEmpQua.sikakuMei);
			map.put("syutokuKaisiYm", s10TEmpQua.syutokuKaisiYm);
			map.put("syutokuYm", s10TEmpQua.syutokuYm);
			map.put("itSkilKbn", this.service.getItemName(s10TEmpQua.itSkilKbn));
			list.add(map);
		}
        applyObj.put("tbl_qua_list", list);

		return JSON.encode(applyObj);
	}

	/**
	 * 学歴情報検索.
	 */
	@RequestMapping(value="/user/s20f003_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_qua_list", this.service.selectId(super.getTargetUserCd(),
        		super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}

	/**
	 * 学歴情報登録.
	 */
	@RequestMapping(value="/user/s20f003_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@Validated @RequestBody S10TEmpQua inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		inEntity.userCd = super.getTargetUserCd();

		if (inEntity.sequence == null) {
			// 新規
			inEntity.sequence = this.service.selectSeq();
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			S10TEmpQua entity = this.service.selectId(inEntity.userCd, inEntity.sequence);
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;

			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 資格情報削除.
	 */
	@RequestMapping(value="/user/s20f003_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TEmpQua dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getTargetUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}
}
