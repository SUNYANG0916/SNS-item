package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * 作業報告書
 */
@Data
@Entity
@Table(name = "s10_t_working_report")
public class S10TWorkingReport {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 作業日 */
    @Id
    @Column(name = "working_date")
    public String workingDate;

    /** TITLE */
    @Column(name = "working_title")
    public String workingTitle;

    /** 作業内容 */
    @Column(name = "working_info")
    public String workingInfo;

    /** 作業時間（開始） */
    @Column(name = "working_time_start")
    public String workingTimeStart;

    /** 作業時間（終了） */
    @Column(name = "working_time_end")
    public String workingTimeEnd;

    /** 課題問題 */
    @Column(name = "working_problem")
    public String workingProblem;

    /** 備考 */
    @Column(name = "contact_info")
    public String contactInfo;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}