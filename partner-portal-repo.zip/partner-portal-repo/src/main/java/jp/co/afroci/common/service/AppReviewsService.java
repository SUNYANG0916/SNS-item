package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TReviewsSentDao;
import jp.co.afroci.common.domain.dao.S11TReviewsSentSequDao;
import jp.co.afroci.common.domain.entity.S11TReviewsSent;

@Service
public class AppReviewsService extends AbstractService {
	@Autowired
	private S11TReviewsSentDao dao;
	@Autowired
	private S11TReviewsSentSequDao sequDao;

	public void insertReviews(S11TReviewsSent entity) {
		dao.insert(entity);
	}

	public void updateReviews(S11TReviewsSent entity) {
		dao.update(entity);
	}

	public void deleteReviews(S11TReviewsSent entity) {
		dao.delete(entity);
	}

	public S11TReviewsSent selectId(Long msgId) {
		return dao.selectById(msgId);
	}
	
	public List<S11TReviewsSent> getReivewsBest(int num) {
		return dao.selectBest(num);
	}
	
	public List<S11TReviewsSent> getReivewsTop(long msgId,int num) {
		return dao.selectTop(msgId,num);
	}
	
	public List<S11TReviewsSent> getReivewsBottom(long msgId,int num) {
		return dao.selectBottom(msgId,num);
	}
	
	public long selectSeq() {
		return sequDao.selectSeq();
	}
}
