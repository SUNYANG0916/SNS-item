package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * プロジェクト稼働実績マスタ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_m_pj_results")
public class S10MPjResults {

    /** PJコード */
    @Id
    @Column(name = "pj_cd")
    public String pjCd;

    /** 行番号 */
    @Id
    @Column(name = "row_number")
    public Integer rowNumber;

    /** 実績年月 */
    @Column(name = "period_e")
    public String periodE;

    /** 稼働実績名 */
    @Column(name = "pj_nm")
    public String pjNm;

    /** 単価 */
    @Column(name = "pj_abbr")
    public BigDecimal pjAbbr;

    /** 時間 */
    @Column(name = "pj_pm")
    public Integer pjPm;

    /** 数量 */
    @Column(name = "pj_pl")
    public BigDecimal pjPl;

    /** 金額 */
    @Column(name = "agree_type")
    public BigDecimal agreeType;

    /** 備考 */
    @Column(name = "pj_ctgr")
    public String pjCtgr;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}