package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TEmpTransport;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10TEmpTransportDao {

    /**
     * @param userCd
     * @param transYm
     * @param sequence
     * @return the S10TEmpTransport entity
     */
    @Select
    S10TEmpTransport selectById(String userCd, String transYm, Integer sequence);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TEmpTransport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TEmpTransport entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TEmpTransport entity);
}