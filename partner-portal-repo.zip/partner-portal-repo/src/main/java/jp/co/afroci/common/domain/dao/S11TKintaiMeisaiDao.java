package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S11TKintaiMeisai;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S11TKintaiMeisaiDao {

    /**
     * @param userCd
     * @param kintaiDate
     * @return the S11TKintaiMeisai entity
     */
    @Select
    List<S11TKintaiMeisai> selectKinmuMeisaiMon(String userCd, String kintaiDate);
    
    /**
     * @param userCd
     * @param kintaiDate
     * @return the S11TKintaiMeisai entity
     */
    @Select
    S11TKintaiMeisai selectById(String userCd, String kintaiDate);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S11TKintaiMeisai entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S11TKintaiMeisai entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S11TKintaiMeisai entity);
}