package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS30TTravelEstimateDao;
import jp.co.afroci.common.domain.custom.CustomS30TTravelExpensesDao;
import jp.co.afroci.common.domain.custom.CustomS30TTravelItineraryDao;
import jp.co.afroci.common.domain.custom.CustomS30TTravelLodgingDao;
import jp.co.afroci.common.domain.dao.S30TTravelEstimateDao;
import jp.co.afroci.common.domain.dao.S30TTravelExpensesDao;
import jp.co.afroci.common.domain.dao.S30TTravelItineraryDao;
import jp.co.afroci.common.domain.dao.S30TTravelLodgingDao;
import jp.co.afroci.common.domain.entity.S30TTravelEstimate;
import jp.co.afroci.common.domain.entity.S30TTravelExpenses;
import jp.co.afroci.common.domain.entity.S30TTravelItinerary;
import jp.co.afroci.common.domain.entity.S30TTravelLodging;

/**
 * 旅行見積情報を取り扱うService
 */
@Service
public class TravelEstimateService extends AbstractService {

    @Autowired
    private S30TTravelEstimateDao dao;

    @Autowired
    private CustomS30TTravelEstimateDao customDao;

    @Autowired
    private S30TTravelItineraryDao itineraryDao;

    @Autowired
    private CustomS30TTravelItineraryDao customItineraryDao;

    @Autowired
    private S30TTravelLodgingDao lodgingDao;

    @Autowired
    private CustomS30TTravelLodgingDao customLodgingDao;

    @Autowired
    private S30TTravelExpensesDao expensesDao;

    @Autowired
    private CustomS30TTravelExpensesDao customExpensesDao;

    /**
     * 新規登録.
     */
    public int insert(S30TTravelEstimate entity) {
        return dao.insert((S30TTravelEstimate) super.getEntity(entity));
    }

    /**
     * 更新登録.
     */
    public int update(S30TTravelEstimate entity) {
        return dao.update((S30TTravelEstimate) super.getEntity(entity));
    }


    /**
     * 削除登録.
     */
    public int delete(S30TTravelEstimate entity) {
        return dao.delete(entity);
    }

    /**
     * 主キー検索.
     */
    public S30TTravelEstimate selectId(String estimateNo) {
        return dao.selectById(estimateNo);
    }

    /**
     * 全件検索.
     */
    public List<S30TTravelEstimate> selectAll(String conditions, String deleteFlag) {
        return customDao.selectAll(conditions, deleteFlag);
    }

    /**
     * シーケンス取得.
     */
    public Integer selectSeq() {
        return customDao.selectSeq();
    }

    /**
     * 新規登録.
     */
    public int insert(S30TTravelItinerary entity) {
        return itineraryDao.insert((S30TTravelItinerary) super.getEntity(entity));
    }

    /**
     * 更新登録.
     */
    public int update(S30TTravelItinerary entity) {
        return itineraryDao.update((S30TTravelItinerary) super.getEntity(entity));
    }

    /**
     * 削除登録.
     */
    public int delete(S30TTravelItinerary entity) {
        return itineraryDao.delete(entity);
    }

    /**
     * 全件検索.
     */
    public List<S30TTravelItinerary> selectItineraryAll(String travelNo, String deleteFlag) {
        return customItineraryDao.selectAll(travelNo, deleteFlag);
    }


    /**
     * 新規登録.
     */
    public int insert(S30TTravelLodging entity) {
        return lodgingDao.insert((S30TTravelLodging) super.getEntity(entity));
    }

    /**
     * 更新登録.
     */
    public int update(S30TTravelLodging entity) {
        return lodgingDao.update((S30TTravelLodging) super.getEntity(entity));
    }

    /**
     * 削除登録.
     */
    public int delete(S30TTravelLodging entity) {
        return lodgingDao.delete(entity);
    }

    /**
     * 全件検索.
     */
    public List<S30TTravelLodging> selectLodgingAll(String travelNo, String deleteFlag) {
        return customLodgingDao.selectAll(travelNo, deleteFlag);
    }

    /**
     * 新規登録.
     */
    public int insert(S30TTravelExpenses entity) {
        return expensesDao.insert((S30TTravelExpenses) super.getEntity(entity));
    }

    /**
     * 更新登録.
     */
    public int update(S30TTravelExpenses entity) {
        return expensesDao.update((S30TTravelExpenses) super.getEntity(entity));
    }

    /**
     * 削除登録.
     */
    public int delete(S30TTravelExpenses entity) {
        return expensesDao.delete(entity);
    }

    /**
     * 全件検索.
     */
    public List<S30TTravelExpenses> selectExpensesAll(String travelNo, String deleteFlag) {
        return customExpensesDao.selectAll(travelNo, deleteFlag);
    }

}
