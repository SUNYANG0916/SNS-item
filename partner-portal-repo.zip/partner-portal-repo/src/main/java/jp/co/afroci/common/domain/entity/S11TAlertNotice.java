package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 通知管理
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s11_t_alert_notice")
public class S11TAlertNotice {

    /** メッセージＩＤ */
    @Id
    @Column(name = "notice_id")
    public Integer noticeId;

    /** タイトル */
    @Column(name = "title")
    public String title;

    /** 内容 */
    @Column(name = "content")
    public String content;

    /** 作成日時 */
    @Column(name = "insert_date")
    public LocalDateTime insertDate;

    /** 更新日時 */
    @Column(name = "last_update")
    public LocalDateTime lastUpdate;
}