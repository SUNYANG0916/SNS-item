package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10MPj;

@Dao
@ConfigAutowireable
public interface CustomS10MPjDao {

	/**
     * @return the S10MPj entity
     */
    @Select
    List<S10MPj> selectAll(String conditions, String deleteFlag);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();
}
