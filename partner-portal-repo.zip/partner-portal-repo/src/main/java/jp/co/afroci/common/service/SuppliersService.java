package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10MSuppliersDao;
import jp.co.afroci.common.domain.dao.S10MSuppliersDao;
import jp.co.afroci.common.domain.entity.S10MSuppliers;

/**
 * 取引先情報を取り扱うService
 */
@Service
public class SuppliersService extends AbstractService {

	@Autowired
	private S10MSuppliersDao dao;

	@Autowired
	private CustomS10MSuppliersDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10MSuppliers entity) {
		return dao.insert((S10MSuppliers) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S10MSuppliers entity) {
		return dao.update((S10MSuppliers) super.getEntity(entity));
	}


	/**
	 * 削除登録.
	 */
	public int delete(S10MSuppliers entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S10MSuppliers selectId(String suppliersNo) {
		return dao.selectById(suppliersNo);
	}

	/**
	 * 全件検索.
	 */
	public List<S10MSuppliers> selectAll(String conditions, String deleteFlag) {
		return customDao.selectAll(conditions, deleteFlag);
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}
