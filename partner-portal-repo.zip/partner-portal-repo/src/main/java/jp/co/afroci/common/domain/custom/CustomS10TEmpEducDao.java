package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TEmpEduc;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TEmpEducDao {

    /**
     * @param userCd
     * @param sequence
     * @return the S10TEmpEduc entity
     */
    @Select
    List<S10TEmpEduc> selectAll();

    /**
     * @param userCd
     * @return the S10TEmpEduc entity
     */
    @Select
    List<S10TEmpEduc> selectByUserCd(String userCd);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();

}