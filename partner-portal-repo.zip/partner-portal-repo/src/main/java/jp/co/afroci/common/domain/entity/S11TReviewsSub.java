package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.GeneratedValue;
import org.seasar.doma.GenerationType;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * メッセージ返信管理
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s11_t_reviews_sub")
public class S11TReviewsSub {

    /** メッセージＩＤ */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long id;

    /** ユーザコード */
    @Column(name = "user_cd")
    public String userCd;

    /** メッセージＩＤ */
    @Column(name = "msg_id")
    public Long msgId;

    /** 内容 */
    @Column(name = "content")
    public String content;

    /** 作成日時 */
    @Column(name = "insert_date")
    public LocalDateTime insertDate;

    /** 更新日時 */
    @Column(name = "last_update")
    public LocalDateTime lastUpdate;

    /** 表示する */
    @Column(name = "show")
    public Integer show;
}