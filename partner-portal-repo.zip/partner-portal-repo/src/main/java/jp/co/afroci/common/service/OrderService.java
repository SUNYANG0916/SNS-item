package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS20TOrderDao;
import jp.co.afroci.common.domain.dao.S20TOrderDao;
import jp.co.afroci.common.domain.entity.S20TOrder;
import jp.co.afroci.common.dto.MasterEstimateDto;

/**
 * 見積情報を取り扱うService
 */
@Service
public class OrderService extends AbstractService {

    @Autowired
    private S20TOrderDao dao;

    @Autowired
    private CustomS20TOrderDao customDao;


    /**
     * 新規登録.
     */
    public int insert(S20TOrder entity) {
        return dao.insert((S20TOrder) super.getEntity(entity));
    }

    /**
     * 更新登録.
     */
    public int update(S20TOrder entity) {
        return dao.update((S20TOrder) super.getEntity(entity));
    }


    /**
     * 削除登録.
     */
    public int delete(S20TOrder entity) {
        return dao.delete(entity);
    }

    /**
     * 主キー検索.
     */
    public S20TOrder selectId(String orderNo) {
        return dao.selectById(orderNo);
    }

    /**
     * 全件検索.
     */
    public List<S20TOrder> selectAll(String conditions, String deleteFlag) {
        return customDao.selectAll(conditions, deleteFlag);
    }

    /**
     * 全件検索.
     */
    public List<MasterEstimateDto> selectMasterAll(String conditions, String deleteFlag) {
        return customDao.selectMasterAll(conditions, deleteFlag);
    }

    /**
     * シーケンス取得.
     */
    public Integer selectSeq() {
        return customDao.selectSeq();
    }
}
