package jp.co.afroci.portal.web.controller.api;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TEmpCarrier;
import jp.co.afroci.common.service.EmpCarrierService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * S20F004-職務情報コントローラ.
 */
@RestController
public class EmpCarrierApiController extends AbstractApiController {

	@Autowired
	private EmpCarrierService service;

	/**
	 * 職務情報初期化.
	 */
	@RequestMapping(value="/user/s20f004_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S20F004, request.getParameter("userRow"));
		// 項目マスタリスト取得対象
		String[][] items = {{Constants.ITEMS.ITEM_30018,"koyokeitai_list_val", "koyokeitaiKbn", "koyokeitaiName"}
		                    ,{Constants.ITEMS.ITEM_30019,"taisyoku_riyu_list_val", "taisyokuRiyu", "taisyokuRiyuName"}
		                    };
		this.service.setSelectItems(applyObj, items);

		return JSON.encode(applyObj);
	}

	/**
	 * 職務情報検索.
	 */
	@RequestMapping(value="/user/s20f004_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_dut_list", service.selectUser(super.getTargetUserCd()));

		return JSON.encode(applyObj);
	}

	/**
	 * 職務情報詳細検索.
	 */
	@RequestMapping(value="/user/s20f004_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        applyObj.put("tbl_dut_list", service.selectId(super.getTargetUserCd(),
        		super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}

	/**
	 * 職務情報登録.
	 */
	@RequestMapping(value="/user/s20f004_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TEmpCarrier inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		inEntity.userCd = super.getTargetUserCd();

		if (inEntity.sequence == null) {
			// 新規
			inEntity.sequence = this.service.selectSeq();
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			// 更新
			S10TEmpCarrier entity = service.selectId(inEntity.userCd, inEntity.sequence);
			// 引継ぎ項目
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;
			// 更新実施
			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * 職務情報削除.
	 */
	@RequestMapping(value="/user/s20f004_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TEmpCarrier dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getTargetUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}
}
