package jp.co.afroci.common.dto;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jp.co.afroci.common.domain.entity.S00MRoles;
import jp.co.afroci.common.util.CipherUtil;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

/**
 * ログイン認証
 */
@Data
public class LoginUserDto implements UserDetails {
    /**
	 * シリアライズ生成
	 */
	private static final long serialVersionUID = -5241462986776472771L;
	private String userCd;
	private String loginId;
	private String loginUserName;

	private String busyoCd;
	private String password;
	private String accessKey;
	private LocalDateTime accessKeyExpirDate;
	private String acountLocked;
	@Setter(AccessLevel.NONE)
	private Collection<? extends GrantedAuthority> authorities = null;

	public void setUserRoles(List<S00MRoles> userRoles) {
		if (userRoles == null) {
			this.authorities = null;
		}
		this.authorities = userRoles.stream().map(r -> {
			return new SimpleGrantedAuthority(r.roleId);
		}).collect(Collectors.toSet());
	}

	public String getLoginUserName() {
		return loginUserName;
	}


	public String getUsername() {
		return loginId;
	}

	public boolean isAccountNonExpired() {
		LocalDateTime date = LocalDateTime.now();
		return accessKeyExpirDate == null || (accessKeyExpirDate != null && date.compareTo(accessKeyExpirDate) <= 0);
	}

	public boolean isAccountNonLocked() {
		return acountLocked == null || acountLocked.isEmpty();
	}

	public boolean isCredentialsNonExpired() {
		return true;
	}

	public boolean isEnabled() {
		return true;
	}

	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.authorities;
	}

	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}
	public String getUserCd() {
		return this.userCd;
	}

	/**
	 * @return loginId
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * @param loginId セットする loginId
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getBusyoCd() {
		return busyoCd;
	}
	/**
	 * @param busyoCd セットする busyoCd
	 */
	public void setBusyoCd(String busyoCd) {
		this.busyoCd = busyoCd;
	}


	@Override
	public String getPassword() {
		if (this.password != null) {
			try {
				this.password = CipherUtil.decrypt(this.password, CipherUtil.key, CipherUtil.ALGORITHM_AES);
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
					| BadPaddingException e) {
			}
		}

		return this.password;
	}
}
