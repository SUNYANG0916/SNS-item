package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.dto.EmpInfoDto;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomLoginUserDao {
    /**
     * @param loginId
     * @return the S00MUser entity
     */
    @Select
    S00MUser selectByLoginId(String loginId);

    /**
     * @param userCd
     * @return the S00MUser entity
     */
    @Select
    S00MUser selectByUserCd(String userCd);

    /**
     * @return the S00MUsers entity
     */
    @Select
    List<S00MUser> selectAll(String conditions);

    /**
     * @return the EmpInfoDto dto
     */
    @Select
    List<EmpInfoDto> selectEmpInfoAll(String conditions);
}