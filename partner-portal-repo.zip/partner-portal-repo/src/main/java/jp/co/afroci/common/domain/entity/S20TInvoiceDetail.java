package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 請求書明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s20_t_invoice_detail")
public class S20TInvoiceDetail {

    /** 請求書番号 */
    @Id
    @Column(name = "invoice_no")
    public String invoiceNo;

    /** 行番号 */
    @Id
    @Column(name = "row_number")
    public Integer rowNumber;

    /** プロジェクトCD */
    @Column(name = "pj_cd")
    public String pjCd;

    /** プロジェクト名 */
    @Column(name = "pj_nm")
    public String pjNm;

    /** 内容 */
    @Column(name = "working_info")
    public String workingInfo;

    /** 納品日 */
    @Column(name = "delivery_date")
    public LocalDate deliveryDate;

    /** 支払日 */
    @Column(name = "due_date")
    public LocalDate dueDate;

    /** 稼働日 */
    @Column(name = "working_days")
    public LocalDate workingDays;

    /** 数量(人月) */
    @Column(name = "quantity")
    public BigDecimal quantity;

    /** 単位 */
    @Column(name = "unit_price")
    public String unitPrice;

    /** 金額 */
    @Column(name = "amount")
    public BigDecimal amount;

    /** 備考 */
    @Column(name = "note")
    public String note;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}