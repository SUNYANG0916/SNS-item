package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10MPj;
import jp.co.afroci.common.domain.entity.S10TWorkingDetail;
import jp.co.afroci.common.service.EmpProjectService;
import jp.co.afroci.common.service.WorkingService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import jp.co.afroci.portal.web.util.Constants.DELETE_FLAG;
import net.arnx.jsonic.JSON;


/**
 * 稼働情報コントローラ.
 */
@RestController
public class WorkingApiController extends AbstractApiController {

	@Autowired
	private WorkingService service;

    @Autowired
    private EmpProjectService pjService;


	/**
	 * 稼働情報初期化.
	 */
	@RequestMapping(value="/user/s10f003_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S10F003, request.getParameter("userRow"));

		// リスト初期表示
        applyObj.put("tbl_working_list", this.service.selectByUserCd(super.getTargetUserCd()));

		return JSON.encode(applyObj);
	}

	/**
	 * 稼働情報検索.
	 */
	@RequestMapping(value="/user/s10f003_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String search(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_working_list", this.service.selectByYM(super.getTargetUserCd(), request.getParameter("workingMonth")));
		return JSON.encode(applyObj);
	}


	/**
	 * 稼働情報詳細検索.
	 */
	@RequestMapping(value="/user/s10f003_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
		S10TWorkingDetail detail = this.service.selectId(super.getTargetUserCd(), request.getParameter("pjCd"), request.getParameter("workingMonth"));
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("pjCd", detail.pjCd);
		map.put("pjNm", pjService.selectId(detail.pjCd).pjNm);
		map.put("workingMonth", detail.workingMonth);
		map.put("workingTimes", detail.workingTimes);
		map.put("costAmount", detail.costAmount);
		map.put("unitAmount", detail.unitAmount);
		map.put("note", detail.note);

		applyObj.put("tbl_working_list", map);

		return JSON.encode(applyObj);
	}

	/**
	 * 稼働情報登録.
	 */
	@RequestMapping(value="/user/s10f003_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10TWorkingDetail inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		inEntity.userCd = super.getTargetUserCd();

		// 更新
		S10TWorkingDetail entity = this.service.selectId(inEntity.userCd, inEntity.pjCd, inEntity.workingMonth);
		if (entity == null) {
			// 新規
			this.service.insert(inEntity);
			resutlObj.put("msg", "登録処理が完了しました。");
		} else {
			inEntity.createUser = entity.createUser;
			inEntity.createDate = entity.createDate;

			this.service.update(inEntity);
			resutlObj.put("msg", "更新処理が完了しました。");
		}
		return JSON.encode(resutlObj);
	}


	/**
	 * 稼働情報削除.
	 */
	@RequestMapping(value="/user/s10f003_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10TWorkingDetail dto) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			dto.userCd = super.getTargetUserCd();
			this.service.delete(dto);
			resutlObj.put("msg", "削除処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}


    /**
     * プロジェクト検索.
     */
    @RequestMapping(value="/user/s10f003_master_project", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterProjects(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        String cond = "%" + request.getParameter("cond") + "%";

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (S10MPj s10MPj : pjService.selectAll(cond, DELETE_FLAG.OFF)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("pjCd", s10MPj.pjCd);
			map.put("pjNm", s10MPj.pjNm);
			map.put("unitPriceNm", this.service.getItemName(s10MPj.unitPrice));
			map.put("unitPrice", s10MPj.unitPrice);
			map.put("quantity", s10MPj.quantity);
			map.put("amount", s10MPj.amount);
			map.put("pjNote", s10MPj.pjNote);
			list.add(map);
		}
        applyObj.put("tbl_project_list", list);

        return JSON.encode(applyObj);
    }
}
