package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MMenu;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS00MMenuDao {

    /**
     * @return the S00MMenu entity
     */
    @Select
    List<S00MMenu> selectAll(String userCd, String menuType);
}