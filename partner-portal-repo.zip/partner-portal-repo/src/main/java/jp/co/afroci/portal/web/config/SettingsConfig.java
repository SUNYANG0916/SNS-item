package jp.co.afroci.portal.web.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SettingsConfig {

	@Value("${settings.apply.jsmode.version}")
	private String version;
	@Value("${settings.apply.jsmode.isdebug}")
	private boolean isDebug;
	@Value("${settings.report.template.skill}")
	private String templateSkill;
	@Value("${settings.apply.fileDir}")
	private String applyFileDir;
	@Value("${settings.session.timeout}")
	private int sessionTimeout;

	@Value("${settings.system.mail.host}")
	private String hostName;

	@Value("${settings.system.mail.port}")
	private int port;

	@Value("${settings.system.mail.smtp.auth}")
	private boolean smtpAuth;

	@Value("${settings.system.mail.smtp.starttls.enable}")
	private boolean smtpStarttlsEnable;

	@Value("${settings.system.mail.sent.from}")
	private String sentFrom;

	@Value("${settings.system.mail.sent.to}")
	private String sentTo;

	@Value("${settings.system.mail.username}")
	private String userName;

	@Value("${settings.system.mail.password}")
	private String password;

	public String getVersion() {
		return version;
	}
	public boolean isDebug() {
		return isDebug;
	}

	public String getApplyFileDir() {
		return applyFileDir;
	}

	public String getTemplateSkill() {
		return templateSkill;
	}
	public int getSessionTimeout() {
		return sessionTimeout;
	}

	public String getHostName() {
		return hostName;
	}


	public int getPort() {
		return port;
	}


	public boolean isSmtpAuth() {
		return smtpAuth;
	}


	public boolean isSmtpStarttlsEnable() {
		return smtpStarttlsEnable;
	}


	public String getSentFrom() {
		return sentFrom;
	}


	public String getSentTo() {
		return sentTo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
