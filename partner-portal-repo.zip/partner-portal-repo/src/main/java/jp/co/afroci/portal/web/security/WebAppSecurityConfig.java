package jp.co.afroci.portal.web.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.csrf.MissingCsrfTokenException;

import jp.co.afroci.common.service.UserLoginAuthService;

/**
 * セキュリティ設定
 */
@Configuration
@EnableWebSecurity
public class WebAppSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserLoginAuthService service;
	@Autowired
	private UserLoginFailureHandler failureHandler;
	@Autowired
	private UserLoginSuccessHandler successHandler;
	@Autowired
	private UserLogoutHandler logoutHandler;

	/**
	 * WebSecurityの設定
	 */
	@Override
	public void configure(WebSecurity web) throws Exception {

		// 静的リソース(images、css、javascript)とH2DBのコンソールに対するアクセスはセキュリティ設定を無視する
		web.ignoring().antMatchers("/css/**", "/fonts/**", "/images/**", "/js/**", "/h2-console/**");

	}

	/**
	 * HttpSecurityの設定
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		// 認可の設定
		http.authorizeRequests()
				// 認証無しでアクセスできるURLを設定
				.antMatchers("/", "/contact-mail", "/error", "timeout", "/user/login", "/passwordReset", "/passwordReset_mail").permitAll()
				 .mvcMatchers("/web/user/**")
				 .hasRole("USER")
				 .mvcMatchers("/web/admin/**","/web/user/**")
				 .hasRole("ADMIN")
				// 上記以外は認証が必要にする設定
				.anyRequest().authenticated().and().exceptionHandling()
				// 通常のRequestとAjaxを両方対応するSessionTimeout用
				.authenticationEntryPoint(authenticationEntryPoint())
				// csrfはsessionがないと動かない。SessionTimeout時にPOSTすると403 Forbiddenを必ず返してしまうため、
				// MissingCsrfTokenExceptionの時はリダイレクトを、それ以外の時は通常の扱いとする。
				.accessDeniedHandler(accessDeniedHandler());

		// ログイン設定
		http.formLogin()
				// 認証処理のパスを設定
				.loginProcessingUrl("/user/login")
				// ログインフォームのパスを設定
				.loginPage("/user/login")
				// 認証成功時にリダイレクトするURLを設定
				.defaultSuccessUrl("/user/apply")
				// 認証成功時に呼ばれるハンドラクラスを設定
				.successHandler(successHandler)
				// 認証失敗時に呼ばれるハンドラクラスを設定
				.failureHandler(authenticationFailureHandler("/user/login","userId"))
				// ユーザー名、パスワードのパラメータ名を設定
				.usernameParameter("userId").passwordParameter("password")
				// ログアウト設定
				.and().logout().logoutUrl("/user/logout").logoutSuccessUrl("/user/login")
				.addLogoutHandler(logoutHandler).deleteCookies("JSESSIONID", "SESSION").clearAuthentication(true)
				.invalidateHttpSession(true);

		// CSRF設定
		http.csrf().ignoringAntMatchers("/", "/contact-mail", "/error", "timeout", "/passwordReset", "/passwordReset_mail");
	}

	@Bean
	AuthenticationEntryPoint authenticationEntryPoint() {
		return new SessionExpiredLoginUrlAuthenticationEntryPoint("/");
	}

	@Bean
	AccessDeniedHandler accessDeniedHandler() {
		return new AccessDeniedHandler() {
			@Override
			public void handle(HttpServletRequest request, HttpServletResponse response,
					AccessDeniedException accessDeniedException) throws IOException, ServletException {
				if (accessDeniedException instanceof MissingCsrfTokenException) {
					authenticationEntryPoint().commence(request, response, null);
				} else {
					new AccessDeniedHandlerImpl().handle(request, response, accessDeniedException);
				}
			}
		};
	}

	/**
	 * 設定
	 */
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// パスワードは平文でDBに登録する為、「NoOpPasswordEncoder」を設定する
		// auth.userDetailsService(service).passwordEncoder(new AesBytesEncryptor());
		auth.userDetailsService(service).passwordEncoder(NoOpPasswordEncoder.getInstance());
	}
	public AuthenticationFailureHandler authenticationFailureHandler(
			String failureUrl, String usernameParameterName) {

		UserLoginFailureHandler ukafh = new UserLoginFailureHandler(failureUrl);
			ukafh.setUsernameParameterName(usernameParameterName);
			return ukafh;
		}
}