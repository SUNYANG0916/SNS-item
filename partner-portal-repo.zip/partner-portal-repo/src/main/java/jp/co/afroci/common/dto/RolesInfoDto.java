package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * ロール情報DTO
 */
@Data
@Entity
public class RolesInfoDto {

	/** ロールID. */
	public String roleId;

	/** ロール名. */
	public String roleNm;

	/** ロールグループID. */
	public String roleGrpId;

	/** ロールグループ名. */
	public String roleGrpNm;
}
