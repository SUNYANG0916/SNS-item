package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import lombok.Data;

/**
 * 資格情報
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_emp_qua")
public class S10TEmpQua {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 資格名 */
    @Column(name = "sikaku_mei")
    @Size(max = 1000)
    @NotNull
    public String sikakuMei;

    /** 習得開始年月 */
    @Column(name = "syutoku_kaisi_ym")
    @NotNull
    public String syutokuKaisiYm;

    /** 取得年月 */
    @Column(name = "syutoku_ym")
    @NotNull
    public String syutokuYm;

    /** ITスキル区分 */
    @Column(name = "it_skil_kbn")
    @NotNull
    public String itSkilKbn;

    /** 備考 */
    @Column(name = "note")
    @Size(max = 1000)
    public String note;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}