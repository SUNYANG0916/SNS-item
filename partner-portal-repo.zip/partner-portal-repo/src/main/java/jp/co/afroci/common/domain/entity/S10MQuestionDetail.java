package jp.co.afroci.common.domain.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 質問マスタ明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_m_question_detail")
public class S10MQuestionDetail {

    /** 質問ID */
    @Id
    @Column(name = "question_id")
    public String questionId;

    /** 質問明細番号 */
    @Id
    @Column(name = "details_no")
    public Integer detailsNo;

    /** 質問内容 */
    @Column(name = "question_info")
    public String questionInfo;

    /** 点数 */
    @Column(name = "point")
    public Integer point;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public BigDecimal updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}