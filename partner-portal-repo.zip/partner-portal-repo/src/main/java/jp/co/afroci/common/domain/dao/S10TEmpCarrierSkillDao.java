package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10TEmpCarrierSkillDao {

    /**
     * @param userCd
     * @param sequence
     * @return the S10TEmpCarrierSkill entity
     */
    @Select
    S10TEmpCarrierSkill selectById(String userCd, Integer sequence);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TEmpCarrierSkill entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TEmpCarrierSkill entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TEmpCarrierSkill entity);
}