package jp.co.afroci.common.dto;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
@Data
public class ContactDto implements Serializable {
	private static final long serialVersionUID = 1L;

	public String contactSeq;

	@NotBlank(message = "入力してください")
	public String name;

	@NotBlank(message = "入力してください")
	public String tel;

	@NotBlank(message = "入力してください")
	@Size(min = 1, max = 50)
	@Email
	public String mail;

	@NotBlank(message = "入力してください")
	@Size(min = 1, max = 1000)
	public String contactDetail;

	public String getContactSeq() {
		return contactSeq;
	}

	public void setContactSeq(String contactSeq) {
		this.contactSeq = contactSeq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getContactDetail() {
		return contactDetail;
	}

	public void setContactDetail(String contactDetail) {
		this.contactDetail = contactDetail;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
