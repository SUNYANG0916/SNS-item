package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S20TOrder;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S20TOrderDao {

    /**
     * @param orderNo
     * @return the S20TOrder entity
     */
    @Select
    S20TOrder selectById(String orderNo);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S20TOrder entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S20TOrder entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S20TOrder entity);
}