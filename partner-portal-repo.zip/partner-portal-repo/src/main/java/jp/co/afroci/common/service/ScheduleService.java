package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TScheduleDao;
import jp.co.afroci.common.domain.custom.CustomS10TScheduleDetailDao;
import jp.co.afroci.common.domain.dao.S10TScheduleDao;
import jp.co.afroci.common.domain.dao.S10TScheduleDetailDao;
import jp.co.afroci.common.domain.entity.S10TSchedule;
import jp.co.afroci.common.domain.entity.S10TScheduleDetail;
import jp.co.afroci.common.dto.ScheduleDto;

/**
 * スケジュール情報を取り扱うService
 */
@Service
public class ScheduleService extends AbstractService {

	@Autowired
	private S10TScheduleDao dao;

	@Autowired
	private S10TScheduleDetailDao detailDao;

	@Autowired
	private CustomS10TScheduleDao customDao;

	@Autowired
	private CustomS10TScheduleDetailDao customDetailDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TSchedule entity) {
		return dao.insert((S10TSchedule) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S10TSchedule entity) {
		return dao.update((S10TSchedule) super.getEntity(entity));
	}


	/**
	 * 削除登録.
	 */
	public int delete(S10TSchedule entity) {
		return dao.delete(entity);
	}

	/**
	 * 新規登録.
	 */
	public int insert(S10TScheduleDetail entity) {
		return detailDao.insert((S10TScheduleDetail) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S10TScheduleDetail entity) {
		return detailDao.update((S10TScheduleDetail) super.getEntity(entity));
	}

	/**
	 * 削除登録.
	 */
	public int delete(S10TScheduleDetail entity) {
		return detailDao.delete(entity);
	}


	/**
	 * 主キー検索.
	 */
	public S10TSchedule selectId(Integer sequence, String userCd) {
		return dao.selectById(sequence, userCd);
	}

	/**
	 * 月単位検索.
	 */
	public List<ScheduleDto> selectByYm(String scheduleYm, String searchConditions) {
		return customDao.selectByYm(scheduleYm, "%" + searchConditions + "%");
	}

	/**
	 * 月単位検索.
	 */
	public List<ScheduleDto> selectByYmUser(String scheduleYm, String userCd) {
		return customDao.selectByYm(scheduleYm, userCd);
	}

	/**
	 * ユーザ単位検索.
	 */
	public List<ScheduleDto> selectByUser(int sequence) {
		return customDao.selectByUser(sequence);
	}

	/**
	 * ユーザ明細検索.
	 */
	public List<S10TScheduleDetail> selectByDetailUser(int sequence) {
		return customDetailDao.selectByUser(sequence);
	}


	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}
