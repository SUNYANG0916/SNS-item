package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 企業案件基本情報
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s11_t_company_anken")
public class S11TCompanyAnken {

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** 会社番号 */
    @Id
    @Column(name = "company_id")
    public Integer companyId;

    /** 案件ID */
    @Id
    @Column(name = "business_id")
    public Integer businessId;

    /** 案件名 */
    @Column(name = "business_name")
    public String businessName;

    /** 作業開始時間 */
    @Column(name = "work_str_time")
    public String workStrTime;

    /** 作業終了時間 */
    @Column(name = "work_end_time")
    public String workEndTime;

    /** 休憩終了時間 */
    @Column(name = "noon_str_time")
    public String noonStrTime;

    /** 休憩終了時間 */
    @Column(name = "noon_end_time")
    public String noonEndTime;

    /** 最寄駅 */
    @Column(name = "station")
    public String station;

    /** 精算単位 */
    @Column(name = "kintai_unit")
    public Integer kintaiUnit;

    /** 作成日時 */
    @Column(name = "insert_date")
    public LocalDateTime insertDate;

    /** 更新日時 */
    @Column(name = "last_update")
    public LocalDateTime lastUpdate;
}