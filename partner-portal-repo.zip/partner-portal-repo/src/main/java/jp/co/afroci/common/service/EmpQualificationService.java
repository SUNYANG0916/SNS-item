package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpQuaDao;
import jp.co.afroci.common.domain.dao.S10TEmpQuaDao;
import jp.co.afroci.common.domain.entity.S10TEmpQua;

/**
 * 資格情報を取り扱うService
 */
@Service
public class EmpQualificationService extends AbstractService {

	@Autowired
	private S10TEmpQuaDao dao;
	@Autowired
	private CustomS10TEmpQuaDao customDao;
	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpQua entity) {
		return dao.insert((S10TEmpQua) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpQua entity) {
		return dao.update((S10TEmpQua) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpQua entity) {
		return dao.delete(entity);
	}


	/**
	 * 主キー検索.
	 */
	public S10TEmpQua selectId(String userCd, int sequence) {
		return dao.selectById(userCd, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpQua> selectUser(String userCd) {
		return customDao.selectByUserCd(userCd);
	}

	/**
	 * 全件検索.
	 */
	public List<S10TEmpQua> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}