package jp.co.afroci.portal.web.report;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;
import jp.co.afroci.common.domain.entity.S10TEmpQua;
import jp.co.afroci.common.dto.EmpSkillDto;
import jp.co.afroci.common.service.AbstractService;

public class TemplateCarrierSkill extends WebExcelreader {
	/** シート名. */
	public static final String SHEET_NAME = "skill";

    /**
     * コンストラクタ.
     *
     * @author Gao Jiayi
     * @throws Exception
     */
	public TemplateCarrierSkill(String template, AbstractService service) throws Exception {
		// ブック初期化
		super(template);
		super.service = service;
	}


	public void makeCarrierSkill(S10TEmpProfile s10TEmpProfile, List<S10TEmpQua> s10TEmpQuas, List<S10TEmpCarrierSkill> s10TEmpCarrierSkills,
			List<EmpSkillDto> empOsList, List<EmpSkillDto> empDbList, List<EmpSkillDto> empProgramList) throws Exception {

		// 氏名（英字略）
		super.cells.add(new ExcelCellConst(2, 0, this.getName(s10TEmpProfile)));
		// 性別
		super.cells.add(new ExcelCellConst(2, 2, this.getSex(s10TEmpProfile.seibetuKbn)));
		// 年齢
		super.cells.add(new ExcelCellConst(2, 4, this.getAge(s10TEmpProfile.seinentukihiYmd)));
		// 国籍
		super.cells.add(new ExcelCellConst(2, 8, this.getCuntry(s10TEmpProfile.kokusekiKbn)));
		// 線路・駅
		super.cells.add(new ExcelCellConst(2, 12, s10TEmpProfile.ensenCd + " " + s10TEmpProfile.eki));
		// 得意工程
		super.cells.add(new ExcelCellConst(3, 4, this.service.getItemName(s10TEmpProfile.tokuiKoteiCd)));
		// 得意技術
		super.cells.add(new ExcelCellConst(4, 4, this.service.getItemName(s10TEmpProfile.tokuiGijutuCd)));
		// 資格情報
		String sikakuMeis = "";
		for (int i = 0; i < s10TEmpQuas.size(); i++) {
			if (i > 0) {
				sikakuMeis += ",";
			}
			sikakuMeis += s10TEmpQuas.get(i).sikakuMei;
		}
		super.cells.add(new ExcelCellConst(5, 4, sikakuMeis));

		// 自己アピール
		super.cells.add(new ExcelCellConst(6, 4, s10TEmpProfile.jikoPr));
		// 通勤時間
		super.cells.add(new ExcelCellConst(7, 7, s10TEmpProfile.tukinJikan));

		for (int i = 0; i < empOsList.size(); i++) {
			// OS
			super.cells.add(new ExcelCellConst(10 + (i / 6), (i % 6) * 5 + 4, empOsList.get(i).itemText));
			super.cells.add(new ExcelCellConst(10 + (i / 6), (i % 6) * 5 + 8, empOsList.get(i).selItemVal));
		}

		for (int i = 0; i < empProgramList.size(); i++) {
			// 言語
			super.cells.add(new ExcelCellConst(12 + (i / 6), (i % 6) * 5 + 4, empProgramList.get(i).itemText));
			super.cells.add(new ExcelCellConst(12 + (i / 6), (i % 6) * 5 + 8, empProgramList.get(i).selItemVal));
		}

		for (int i = 0; i < empDbList.size(); i++) {
			// DB
			super.cells.add(new ExcelCellConst(19 + (i / 6), (i % 6) * 5 + 4, empDbList.get(i).itemText));
			super.cells.add(new ExcelCellConst(19 + (i / 6), (i % 6) * 5 + 8, empDbList.get(i).selItemVal));
		}

		int startRow = 25;

		if (s10TEmpCarrierSkills.size() > 0) {
			for (int i = 0; i < s10TEmpCarrierSkills.size(); i++) {
				S10TEmpCarrierSkill s10TEmpCarrierSkill = s10TEmpCarrierSkills.get(i);
				int row_no = startRow + 10 * i;
				if (i > 0) {
					// 書式コピー
					this.copyStyle(SHEET_NAME, 25, 0, 34, 34, row_no, 0);
				}
				super.cells.add(new ExcelCellConst(row_no, 0, String.valueOf(i + 1)));
				// 開始
				super.cells.add(new ExcelCellConst(row_no, 1,
						s10TEmpCarrierSkill.kaisiYm.replaceAll("-", "/")));
				// -
				super.cells.add(new ExcelCellConst(row_no, 6, "-"));
				// 終了
				super.cells.add(new ExcelCellConst(row_no, 7,
						s10TEmpCarrierSkill.syuryoYm.replaceAll("-", "/")));
				// 作業場所
				super.cells.add(new ExcelCellConst(row_no, 12,
						this.getSagyoBasyo(s10TEmpCarrierSkill.sagyoBasyo)));
				// 規模
				super.cells.add(new ExcelCellConst(row_no, 15,
						this.service.getItemName(s10TEmpCarrierSkill.kibo)));
				// 役割
				super.cells.add(new ExcelCellConst(row_no, 21,
						this.service.getItemName(s10TEmpCarrierSkill.yakuwariKbn)));
				// 業界
				super.cells.add(new ExcelCellConst(row_no + 1, 1, "業界"));
				super.cells.add(new ExcelCellConst(row_no + 1, 4,
						this.service.getItemName(s10TEmpCarrierSkill.gyokaiCd)));
				// 案件名
				super.cells.add(new ExcelCellConst(row_no + 1, 15, s10TEmpCarrierSkill.ankenMei));
				// 工程
				super.cells.add(new ExcelCellConst(row_no + 2, 1, "工程"));
				super.cells.add(new ExcelCellConst(row_no + 2, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.koteiCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// OS
				super.cells.add(new ExcelCellConst(row_no + 3, 1, "OS"));
				super.cells.add(new ExcelCellConst(row_no + 3, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.osCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// DB
				super.cells.add(new ExcelCellConst(row_no + 4, 1, "DB"));
				super.cells.add(new ExcelCellConst(row_no + 4, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.dbCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// ミドルウェア
				super.cells.add(new ExcelCellConst(row_no + 5, 1, "ミドルウェア"));
				super.cells.add(new ExcelCellConst(row_no + 5, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.midoruweaCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// 言語
				super.cells.add(new ExcelCellConst(row_no + 6, 1, "言語"));
				super.cells.add(new ExcelCellConst(row_no + 6, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.programGengoCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")
						+ ", " +
						this.service.getItemNames(s10TEmpCarrierSkill.javaLibCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// フレームワーク
				super.cells.add(new ExcelCellConst(row_no + 7, 1, "フレームワーク"));
				super.cells.add(new ExcelCellConst(row_no + 7, 4,
						this.service.getItemNames(s10TEmpCarrierSkill.frameworkCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")));
				// ツール
				super.cells.add(new ExcelCellConst(row_no + 8, 1, "ツール"));
				super.cells.add(new ExcelCellConst(row_no + 8, 4
						, this.service.getItemNames(s10TEmpCarrierSkill.toolKaihatuCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")
						+ ", " + this.service.getItemNames(s10TEmpCarrierSkill.toolCloudCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")
						+ ", " + this.service.getItemNames(s10TEmpCarrierSkill.toolUtilityCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")
						+ ", " + this.service.getItemNames(s10TEmpCarrierSkill.toolBisinesuCd).replaceAll("該当なし,", "").replaceAll("該当なし", "")
						));
				// 作業内容
				super.cells.add(new ExcelCellConst(row_no + 9, 1, "作業内容"));
				super.cells.add(new ExcelCellConst(row_no + 9, 4, s10TEmpCarrierSkill.annkenSagyoSyosai));
			}
		}
		// シート書き込み
		super.write(SHEET_NAME);

		for (int i = 0; i < s10TEmpCarrierSkills.size(); i++) {
			int row_no = startRow + 10 * i;
			if (i > 0) {
				// 書式コピー
				this.copyStyle(SHEET_NAME, 25, 0, 34, 34, row_no, 0);
			}
		}
		// 印刷範囲設定
		this.printArea(s10TEmpCarrierSkills.size());
	}


	private String getName(S10TEmpProfile s10TEmpProfile) {
		String result = ".";
		if (s10TEmpProfile.eijiSei.length() > 0) {
			result = s10TEmpProfile.eijiSei.substring(0,  1) + result;
		}
		if (s10TEmpProfile.eijiMei.length() > 0) {
			result += s10TEmpProfile.eijiMei.substring(0,  1);
		}
		return result;
	}

	private String getAge(LocalDate val) {
		if (val == null) {
			return "";
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int yyyy = cal.get(Calendar.YEAR);
		int mm = cal.get(Calendar.MONTH);
		int dd = cal.get(Calendar.DATE);

		int age = yyyy - val.getYear();
		if (mm <= val.getMonthValue()) {
			if (dd < val.getDayOfMonth()) {
				age -= 1;
			}
		}

		return String.valueOf(age);
	}

	private String getCuntry(String val) {
		return val.equals("1") ? "日本": "外国";
	}

	private String getSex(String val) {
		return val.equals("1") ? "男": "女";
	}

	private String getSagyoBasyo(String val) {
		return val.equals("1") ? "日本": "外国";
	}
}
