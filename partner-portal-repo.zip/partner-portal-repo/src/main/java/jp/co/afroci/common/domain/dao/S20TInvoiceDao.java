package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S20TInvoice;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S20TInvoiceDao {

    /**
     * @param invoiceNo
     * @return the S20TInvoice entity
     */
    @Select
    S20TInvoice selectById(String invoiceNo);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S20TInvoice entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S20TInvoice entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S20TInvoice entity);
}