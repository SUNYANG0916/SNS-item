package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TReviewsSubDao;
import jp.co.afroci.common.domain.dao.S11TReviewsSubSequDao;
import jp.co.afroci.common.domain.entity.S11TReviewsSub;

@Service
public class AppSubReviewsService extends AbstractService {
	@Autowired
	private S11TReviewsSubDao dao;
	@Autowired
	private S11TReviewsSubSequDao sequDao;

	public void insertSubReviews(S11TReviewsSub entity) {
		dao.insert(entity);
	}

	public void updateSubReviews(S11TReviewsSub entity) {
		dao.update(entity);
	}

	public void deleteSubReviews(S11TReviewsSub entity) {
		dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S11TReviewsSub selectId(Long msgId, String userCd) {
		return dao.selectById(msgId);
	}

	public List<S11TReviewsSub> getSubReviews(long msgId) {
		return dao.selectByMsgId(msgId);
	}

	public List<S11TReviewsSub> getSubReviewsUsers(long msgId) {
		return dao.selectUserByMsgId(msgId);
	}

	public long selectSeq() {
		return sequDao.selectSeq();
	}
}
