package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * ロールグループ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s00_m_role_grp")
public class S00MRoleGrp {

    /** ロールグループID */
    @Id
    @Column(name = "role_grp_id")
    public String roleGrpId;

    /** ロールID */
    @Id
    @Column(name = "role_id")
    public String roleId;

    /** ソートキー */
    @Column(name = "sort")
    public Integer sort;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}