package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * スケジュール
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_schedule")
public class S10TSchedule {

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** ユーザコード */
    @Id
    @Column(name = "user_cd")
    public String userCd;

    /** ユーザ名 */
    @Column(name = "user_name")
    public String userName;

    /** 日付 */
    @Column(name = "schedule_date")
    public String scheduleDate;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}