package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S20TInvoice;

/**
 * CustomS20TInvoiceDao
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS20TInvoiceDao {

    /**
     * @return the S20TInvoice entity
     */
    @Select
    List<S20TInvoice> selectAll(String conditions, String deleteFlag);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();
}