package jp.co.afroci.portal.web.controller.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10MSuppliers;
import jp.co.afroci.common.domain.entity.S20TEstimateDetail;
import jp.co.afroci.common.domain.entity.S30TTravelEstimate;
import jp.co.afroci.common.domain.entity.S30TTravelExpenses;
import jp.co.afroci.common.domain.entity.S30TTravelItinerary;
import jp.co.afroci.common.domain.entity.S30TTravelLodging;
import jp.co.afroci.common.service.SuppliersService;
import jp.co.afroci.common.service.TravelEstimateService;
import jp.co.afroci.common.util.DataCopyUtil;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import jp.co.afroci.portal.web.util.Constants.DELETE_FLAG;
import net.arnx.jsonic.JSON;


/**
 * 旅行見積書マスタコントローラ.
 */
@RestController
public class TravelEstimateApiController extends AbstractApiController {

    @Autowired
    private TravelEstimateService service;

    @Autowired
    private SuppliersService suppliersService;

    /** コンストラクタ. */
    public TravelEstimateApiController() {
        super();
    }

    /**
     * 画面初期ロードリクエスト.
     */
    @RequestMapping(value="/user/s40f001_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S40F001, null);
        // 項目マスタリスト取得対象
        String[][] items = {
                { Constants.ITEMS.ITEM_30031, "selDelete", "", ""},
        		{ Constants.ITEMS.ITEM_30037, "selTravelType", "" ,"", "true"},
                { Constants.ITEMS.ITEM_30038, "selTravelMeal", "", "", "true"},
                { Constants.ITEMS.ITEM_30039, "selTaxType", "", ""},
                { Constants.ITEMS.ITEM_30040, "selExpensesType", "", "", "true"}
        };
        this.service.setSelectItems(applyObj, items);

        return JSON.encode(applyObj);
    }

    /**
     * 見積書マスタ検索.
     */
    @RequestMapping(value="/user/s40f001_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();

        // キーワード検索条件
        String conditions = "%" + request.getParameter("cond") + "%";
        // 有効／失効（削除フラグ）
        String selDelete = request.getParameter("selDelete");
        String deleteFlag = null;
        if (selDelete.equals("30031-001")) {
            // 有効のみ
            deleteFlag = DELETE_FLAG.OFF;
        } else if (selDelete.equals("30031-002")) {
            // 失効のみ
            deleteFlag = DELETE_FLAG.ON;
        }

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (S30TTravelEstimate entity : service.selectAll(conditions, deleteFlag)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("travelNo", entity.travelNo);
            map.put("courseName", entity.courseName);
            map.put("suppliersToName", entity.suppliersToName);
            map.put("periodS", entity.periodS);
            map.put("periodE", entity.periodE);
            map.put("amountTotal", entity.amountTotal);
            list.add(map);
        }
        applyObj.put("tbl_travel_estimate_list", list);

        return JSON.encode(applyObj);
    }

    /**
     * 見積書明細検索.
     */
    @RequestMapping(value="/user/s40f001_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        String travelNo = request.getParameter("travelNo");
        // 請求データ
        S30TTravelEstimate entitys = service.selectId(travelNo);

        applyObj.put("tbl_travel_estimate_info", entitys);

        // 旅程明細データ
        List<Map<String, Object>> tbl_itinerary_list = new ArrayList<Map<String, Object>>();
        for (S30TTravelItinerary entity : service.selectItineraryAll(travelNo, null)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("travelNo", entity.travelNo);
            map.put("travelDay", entity.travelDay);
            map.put("travelInfo", entity.travelInfo);
            map.put("travelTimeS", entity.travelTimeS);
            map.put("travelTimeE", entity.travelTimeE);
            if (entity.travelTimeE != null && !entity.travelTimeE.equals("")) {
            	map.put("travelTimeMark", " - ");
            } else {
            	map.put("travelTimeMark", " ");
            }
            map.put("travelType", entity.travelType);
            map.put("travelTypeView", service.getItemName(entity.travelType));
            map.put("travelMeal", entity.travelType);
            map.put("travelMealView", service.getItemName(entity.travelMeal));

            tbl_itinerary_list.add(map);
        }
        applyObj.put("tbl_itinerary_list", tbl_itinerary_list);

        // 宿泊明細データ
        List<Map<String, Object>> tbl_lodging_list = new ArrayList<Map<String, Object>>();
        BigDecimal amountLodgingSum = BigDecimal.ZERO;
        for (S30TTravelLodging entity : service.selectLodgingAll(travelNo, null)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("travelNo", entity.travelNo);
            map.put("lodgingItem", entity.lodgingItem);
            map.put("lodgingLocation", entity.lodgingLocation);
            map.put("option", entity.option);
            map.put("amount", entity.amount);
            map.put("discount", entity.discount);
            if (entity.amount == null) {
            	entity.amount = BigDecimal.ZERO;
            } else {
            	map.put("amountCost", entity.amount.add(entity.discount));
            }
            amountLodgingSum = amountLodgingSum.add(entity.amount);

            tbl_lodging_list.add(map);
        }
        applyObj.put("amountSum1", amountLodgingSum);
        applyObj.put("amountSumTotal1", amountLodgingSum.multiply(entitys.quantity));
        applyObj.put("tbl_lodging_list", tbl_lodging_list);

        // 交通費明細リスト
        List<Map<String, Object>> tbl_expenses_list = new ArrayList<Map<String, Object>>();
        BigDecimal amountExpensesSum = BigDecimal.ZERO;
        for (S30TTravelExpenses entity : service.selectExpensesAll(travelNo, null)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("travelNo", entity.travelNo);
            map.put("expensesType", entity.expensesType);
            map.put("expensesTypeView", service.getItemName(entity.expensesType));
            map.put("expensesInfo", entity.expensesInfo);

            map.put("taxType", entity.taxType);
            map.put("taxTypeView", " (" + service.getItemName(entity.taxType) + "）");
            if (entity.unitAmount == null) {
            	entity.unitAmount = BigDecimal.ZERO;
            }
            map.put("unitAmount", entity.unitAmount);
            if (entity.amount == null) {
            	entity.amount = BigDecimal.ZERO;
            }
            map.put("amount", entity.amount);
            amountExpensesSum = amountExpensesSum.add(entity.amount);

            tbl_expenses_list.add(map);
        }
        applyObj.put("tbl_expenses_list", tbl_expenses_list);

        applyObj.put("amountSum2", amountExpensesSum);

        applyObj.put("amountTotal", amountLodgingSum.multiply(entitys.quantity).add(amountExpensesSum));

        return JSON.encode(applyObj);
    }

    /**
     * 旅行見積書登録更新.
     *     public String update(@RequestBody S30TTravelEstimate inEntity) {
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s40f001_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
	public String update(HttpServletRequest request, @RequestBody Map<String, Object> model)
			throws IllegalAccessException {
        Map<String, Object> resultObj = new HashMap<String, Object>();
        resultObj.put("result", "ok");
        try {
    		S30TTravelEstimate inEntity = DataCopyUtil.copyEntity(model, S30TTravelEstimate.class);
        	String travelNo = inEntity.travelNo;
            // 旅行情報
            S30TTravelEstimate entity = service.selectId(travelNo);
        	if (entity == null) {
                // 新規
                travelNo = "00000" + String.valueOf(service.selectSeq());
                travelNo = "TRV" + travelNo.substring(travelNo.length() - 6);
                inEntity.travelNo = travelNo;
                service.insert(inEntity);
            } else {
                // 更新
                inEntity.deleteFlg = entity.deleteFlg;
                service.update(inEntity);
            }
        	// 旅程詳細
        	// 一括削除
			for (S30TTravelItinerary itineraryEntity : this.service.selectItineraryAll(inEntity.travelNo, null)) {
				this.service.delete(itineraryEntity);
			}
			// 一括登録
			List<Map<String, Object>> tbl_itinerary_list = (List<Map<String, Object>>) model.get("tbl_itinerary_list");
			for (Map<String, Object> itinerary : tbl_itinerary_list) {
				S30TTravelItinerary itineraryEntity = DataCopyUtil.copyEntity(itinerary, S30TTravelItinerary.class);
				itineraryEntity.travelNo = travelNo;
                this.service.insert(itineraryEntity);
			}

        	// 宿泊費詳細
        	// 一括削除
			for (S30TTravelLodging lodgingEntity : this.service.selectLodgingAll(inEntity.travelNo, null)) {
				this.service.delete(lodgingEntity);
			}
			// 一括登録
			List<Map<String, Object>> tbl_lodging_list = (List<Map<String, Object>>) model.get("tbl_lodging_list");
			for (Map<String, Object>lodging : tbl_lodging_list) {
				S30TTravelLodging lodgingEntity = DataCopyUtil.copyEntity(lodging, S30TTravelLodging.class);
				lodgingEntity.travelNo = travelNo;
                this.service.insert(lodgingEntity);
        	}

        	// 交通費詳細
        	// 一括削除
			for (S30TTravelExpenses expensesEntity : this.service.selectExpensesAll(inEntity.travelNo, null)) {
				this.service.delete(expensesEntity);
			}
			// 一括登録
			List<Map<String, Object>> tbl_expenses_list = (List<Map<String, Object>>) model.get("tbl_expenses_list");
			for (Map<String, Object>expenses : tbl_expenses_list) {
				S30TTravelExpenses expensesEntity = DataCopyUtil.copyEntity(expenses, S30TTravelExpenses.class);
				expensesEntity.travelNo = travelNo;
                this.service.insert(expensesEntity);
        	}
            resultObj.put("msg", "登録処理が完了しました。");
        } catch (IllegalArgumentException | SecurityException e) {
        	resultObj.put("msg", "処理失敗しました。");
        	resultObj.put("result", "error");
        }

        return JSON.encode(resultObj);
    }


    /**
     * 見積書明細登録.
     */
    @RequestMapping(value="/user/s40f001_updateDetails", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    private String updateUserRole(HttpServletRequest request, @RequestBody List<S20TEstimateDetail> inEntitys) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");

//        // 一括削除
//        String estimateNo = inEntitys.get(0).travelNo;
//        for (S20TEstimateDetail estimateDetail : this.estimateDetailService.selectByEstimateDetail(estimateNo)) {
//            this.estimateDetailService.delete(estimateDetail);
//        }
//
//        // 一括登録
//        for (S20TEstimateDetail entity : inEntitys) {
//            this.estimateDetailService.insert(entity);
//            resutlObj.put("msg", "登録処理が完了しました。");
//        }
        return JSON.encode(resutlObj);
    }



    /**
     * 見積書マスタ論理削除.
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s40f001_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String delete(@RequestBody S30TTravelEstimate inEntity) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");
        try {
        	S30TTravelEstimate entity = service.selectId(inEntity.travelNo);
            entity.deleteFlg = DELETE_FLAG.ON;
            service.update(entity);
            resutlObj.put("msg", "廃止処理が完了しました。");
        } catch (IllegalArgumentException | SecurityException e) {
            resutlObj.put("msg", "処理失敗しました。");
            resutlObj.put("result", "error");
        }

        return JSON.encode(resutlObj);
    }

    /**
     * 取引先検索.
     */
    @RequestMapping(value="/user/s40f001_master_suppliers", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterSuppliers(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String cond = "%" + request.getParameter("cond") + "%";
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        for (S10MSuppliers s10MSuppliers : suppliersService.selectAll(cond, "0")) {
        	Map<String, String> map = new HashMap<String, String>();
        	map.put("suppliersNo", s10MSuppliers.suppliersNo);
        	map.put("suppliersName", s10MSuppliers.suppliersName);
        	map.put("suppliersJson", JSON.encode(s10MSuppliers));
        	list.add(map);
        }
        applyObj.put("tbl_suppliers_list", list);

        return JSON.encode(applyObj);
    }

}
