package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S30TTravelExpenses;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS30TTravelExpensesDao {

    /**
     * @return the S30TTravelExpenses entity
     */
    @Select
    List<S30TTravelExpenses> selectAll(String travelNo, String deleteFlag);

}