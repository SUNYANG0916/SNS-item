package jp.co.afroci.common.domain.dao;

import java.math.BigDecimal;
import jp.co.afroci.common.domain.entity.S00MPostal;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S00MPostalDao {

    /**
     * @param no
     * @return the S00MPostal entity
     */
    @Select
    S00MPostal selectById(BigDecimal no);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S00MPostal entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S00MPostal entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S00MPostal entity);
}