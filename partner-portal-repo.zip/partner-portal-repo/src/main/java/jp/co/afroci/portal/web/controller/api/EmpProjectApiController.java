package jp.co.afroci.portal.web.controller.api;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jp.co.afroci.common.domain.entity.S10MPj;
import jp.co.afroci.common.service.EmpProjectService;
import jp.co.afroci.common.service.SuppliersService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * プロジェクトマスタコントローラ.
 */
@RestController
public class EmpProjectApiController extends AbstractApiController {

	@Autowired
	private EmpProjectService service;

	@Autowired
	private SuppliersService suppliersService;

	public EmpProjectApiController() {
		super();
	}
	/**
	 * 画面初期ロードリクエスト.
	 */
    @RequestMapping(value="/user/s10f001_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S10F001, null);
		// 項目マスタリスト取得対象
		String[][] items = {
				{Constants.ITEMS.ITEM_30028,"selAgreeType", "" ,""},
				{Constants.ITEMS.ITEM_30029,"selPjType", "" ,""},
				{Constants.ITEMS.ITEM_30026,"selTaxType", "", ""},
				{Constants.ITEMS.ITEM_30032,"selUnitPrice", "", ""},
				{Constants.ITEMS.ITEM_30031,"selDelete", "", ""}
		};
		this.service.setSelectItems(applyObj, items);

		return JSON.encode(applyObj);
	}

	/**
	 * プロジェクトマスタ検索.
	 */
	@RequestMapping(value="/user/s10f001_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

        // キーワード検索条件
        String conditions = "%" + request.getParameter("cond") + "%";
        // 有効／失効（削除フラグ）
        String selDelete = request.getParameter("selDelete");
        String deleteFlag = null;
        if (selDelete.equals("30031-001")) {
        	// 有効のみ
        	deleteFlag = Constants.DELETE_FLAG.OFF;
        } else if (selDelete.equals("30031-002")) {
        	// 失効のみ
        	deleteFlag = Constants.DELETE_FLAG.ON;
        }

		for (S10MPj s10MPj : service.selectAll(conditions, deleteFlag)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("pjCd", s10MPj.pjCd);
			map.put("pjNm", s10MPj.pjNm);
			map.put("periodS", s10MPj.periodS);
			map.put("periodE", s10MPj.periodE);
			map.put("agreeType", this.service.getItemName(s10MPj.agreeType));
			map.put("pjType", this.service.getItemName(s10MPj.pjType));
			list.add(map);
		}
        applyObj.put("tbl_project_list", list);
		return JSON.encode(applyObj);
	}

	/**
	 * プロジェクトマスタ詳細検索.
	 */
	@RequestMapping(value="/user/s10f001_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String pjCd = request.getParameter("pjCd");
        applyObj.put("tbl_project_list", service.selectId(pjCd));

		return JSON.encode(applyObj);
	}

	/**
	 * プロジェクトマスタ登録.
	 */
	@RequestMapping(value="/user/s10f001_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody S10MPj inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		S10MPj entity = service.selectId(inEntity.pjCd);
		inEntity.sort = 1;
		try {
			if (entity == null) {
				// 新規
				String pjCd = "000" + String.valueOf(service.selectSeq());
				inEntity.pjCd = "P" + pjCd.substring(pjCd.length() - 4);

				service.insert(inEntity);
				resutlObj.put("msg", "登録処理が完了しました。");
			} else {
				// 更新
				inEntity.createUser = entity.createUser;
				inEntity.createDate = entity.createDate;

				service.update(inEntity);
				resutlObj.put("msg", "更新処理が完了しました。");
			}
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}

	/**
	 * プロジェクトマスタ削除.
	 */
	@RequestMapping(value="/user/s10f001_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String delete(@RequestBody S10MPj inEntity) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		try {
			S10MPj entity = service.selectId(inEntity.pjCd);
			entity.deleteFlg = Constants.DELETE_FLAG.ON;

			service.update(entity);
			resutlObj.put("msg", "廃止処理が完了しました。");
		} catch (IllegalArgumentException | SecurityException e) {
			resutlObj.put("msg", "処理失敗しました。");
			resutlObj.put("result", "error");
		}

		return JSON.encode(resutlObj);
	}


	@RequestMapping(value="/user/s10f001_master_suppliers", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getMasterSuppliers(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String cond = "%" + request.getParameter("cond") + "%";

        applyObj.put("tbl_suppliers_list", suppliersService.selectAll(cond, "0"));

		return JSON.encode(applyObj);
	}


	/**
	 * CSVアップロードを行う
	 *
	 * @param multipartFile
	 * @return 処理結果（JSON文字列）
	 */
	@RequestMapping(value = "/user/s10f001_upload", method = RequestMethod.POST)
	@ResponseBody
	public String upload(@RequestParam("csvfile") MultipartFile multipartFile) {
		Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		// ファイルが空の場合は異常終了
		if (multipartFile.isEmpty()) {
			// 異常終了時の処理
		}

		int row_number = 0;
		try {
		    String line = "";
		    InputStream is = multipartFile.getInputStream();
		    BufferedReader br = new BufferedReader(new InputStreamReader(is));
		    while ((line = br.readLine()) != null) {
		    	row_number++;
		        // 処理result.add(line);
		    	String[] items = line.split(",");
		    	if (items.length > 18) {
		    		S10MPj inEntity = new S10MPj();

					String pjCd = "000" + String.valueOf(service.selectSeq());
					inEntity.pjCd = "P" + pjCd.substring(pjCd.length() - 4);

		    	    // 有効期間（始）
		    	    inEntity.periodS = items[1];
		    	    // 有効期間（終）
		    	    inEntity.periodE = items[2];
		    	    // PJ名称
		    	    inEntity.pjNm = items[3];
		    	    // PJマネージャ
		    	    inEntity.pjPm = items[4];
		    	    // PJリーダー
		    	    inEntity.pjPl = items[5];
		    	    // PJ種別
		    	    inEntity.pjType = items[6];
		    	    // 契約種別
		    	    inEntity.agreeType = items[7];
		    	    // 備考
		    	    inEntity.pjNote = items[8];
		    	    // 取引先コード
		    	    inEntity.suppliersNo = items[9];
		    	    // 取引先名
		    	    inEntity.suppliersName = items[10];
		    	    // 作業場所
		    	    inEntity.pjWorkLot = items[11];
		    	    // 時間上限
		    	    inEntity.pjTimesMax = items[12];
		    	    // 時間下限
		    	    inEntity.pjTimesMin = items[13];
		    	    // 数量(人月)
		    	    inEntity.quantity = new BigDecimal(items[14]);
		    	    // 単位
		    	    inEntity.unitPrice = items[15];
		    	    // 金額
		    	    inEntity.amount = new BigDecimal(items[16]);
		    	    // 税区分
		    	    inEntity.taxType = items[17];
		    	    // ソート
		    	    inEntity.sort = Integer.valueOf(items[18]);

					service.insert(inEntity);
		    	}
		    }
		} catch (Exception e) {
			// 異常終了時の処理
			resutlObj.put("msg", "行（" + row_number + "）の登録処理が失敗しました。");
			resutlObj.put("result", "error");
		} catch (Throwable t) {
			// 異常終了時の処理
			resutlObj.put("msg", "行（" + row_number + "）の登録処理が失敗しました。");
			resutlObj.put("result", "error");
		}
		return JSON.encode(resutlObj);
	}

}
