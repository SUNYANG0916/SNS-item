package jp.co.afroci.common.domain.dao;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S11TReviewsSubSequDao {

    /**
     * @return the シーケンス
     */
    @Select
    long selectSeq();
}