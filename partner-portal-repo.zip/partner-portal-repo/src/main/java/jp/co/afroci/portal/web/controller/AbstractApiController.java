package jp.co.afroci.portal.web.controller;

import java.util.List;
import java.util.Locale;

import org.postgresql.util.PSQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

import jp.co.afroci.common.dto.ValidationErrorDTO;

public abstract class AbstractApiController extends AbstractController {

	public Logger log = LoggerFactory.getLogger(AbstractApiController.class);
    private static final String ERROR_CODE_TODO_ENTRY_NOT_FOUND = "error.todo.entry.not.found";

	@Autowired
    MessageSource messageSource;

    /**
	 * コンストラクタ.
	 * */
	protected AbstractApiController() {

	}

	@ExceptionHandler(PSQLException.class)
	public final ResponseEntity<String> handleAllExceptions(PSQLException ex, WebRequest request) {
		String html = "システムデータベースが混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		log.error(ex.getLocalizedMessage());
		return new ResponseEntity<>(html, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<String> handleAllExceptions(Exception ex, WebRequest request) {
		String html = "ただいま混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		log.error(ex.getLocalizedMessage());
		return new ResponseEntity<>(html, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Throwable.class)
	public final ResponseEntity<String> handleAllExceptions(Throwable ex, WebRequest request) {
		String html = "システムが混みあっております。しばらく経ってからアクセスするか管理者に連絡してください";
		log.error(ex.getLocalizedMessage());
		return new ResponseEntity<>(html, HttpStatus.CONFLICT);
	}

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrorDTO handleValidationErrors(MethodArgumentNotValidException ex, Locale currentLocale) {
        BindingResult result = ex.getBindingResult();
        List<FieldError> fieldErrors = result.getFieldErrors();
        log.error("Found {} validation errors", fieldErrors.size());

        return constructValidationErrors(fieldErrors, currentLocale);
    }

    private ValidationErrorDTO constructValidationErrors(List<FieldError> fieldErrors, Locale currentLocale) {
        ValidationErrorDTO dto = new ValidationErrorDTO();

        for (FieldError fieldError: fieldErrors) {
            String localizedErrorMessage = getValidationErrorMessage(fieldError, currentLocale);
            dto.addFieldError(fieldError.getField(), localizedErrorMessage);
        }

        return dto;
    }

    private String getValidationErrorMessage(FieldError fieldError, Locale currentLocale) {
        String localizedErrorMessage = messageSource.getMessage(fieldError, currentLocale);
        if (localizedErrorMessage.equals(fieldError.getDefaultMessage())) {
            String[] fieldErrorCodes = fieldError.getCodes();
            localizedErrorMessage = fieldErrorCodes[0];
        }

        return localizedErrorMessage;
    }
}
