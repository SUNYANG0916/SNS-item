package jp.co.afroci.portal.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppErrorController implements ErrorController {

	@RequestMapping(value = {"/error", "/web/error", "/web/user/error"})
	public String handleError(HttpServletRequest request, Model model) {
		Logger log = LoggerFactory.getLogger(AbstractApiController.class);

		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
		Exception ex = (Exception) request.getAttribute("javax.servlet.error.exception");
		String msg = "システム例外が発生しました";
		if(ex != null) {
			log.error(statusCode + ":" + ex.getMessage());
		} else {
			log.error(statusCode + ":" + msg);
		}
		model.addAttribute("errorMessage", msg);
		return "error";
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}
}