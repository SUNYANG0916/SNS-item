package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TScheduleDetail;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TScheduleDetailDao {

    /**
     * @param sequence
     * @return the Schedule dto
     */
    @Select
    List<S10TScheduleDetail> selectByUser(int sequence);
}