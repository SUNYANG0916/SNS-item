package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.S10TSchedule;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface S10TScheduleDao {

    /**
     * @param sequence
     * @param userCd
     * @return the S10TSchedule entity
     */
    @Select
    S10TSchedule selectById(Integer sequence, String userCd);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(S10TSchedule entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(S10TSchedule entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(S10TSchedule entity);
}