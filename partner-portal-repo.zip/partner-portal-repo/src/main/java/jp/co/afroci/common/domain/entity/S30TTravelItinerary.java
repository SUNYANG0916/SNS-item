package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 旅程詳細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s30_t_travel_itinerary")
public class S30TTravelItinerary {

    /** 請求書番号 */
    @Id
    @Column(name = "travel_no")
    public String travelNo;

    /** 行番号 */
    @Id
    @Column(name = "row_number")
    public Integer rowNumber;

    /** 月日 */
    @Column(name = "travel_day")
    public String travelDay;

    /** 時刻（開始） */
    @Column(name = "travel_time_s")
    public String travelTimeS;

    /** 時刻（終了） */
    @Column(name = "travel_time_e")
    public String travelTimeE;

    /** 内容 */
    @Column(name = "travel_info")
    public String travelInfo;

    /** 移動手段 */
    @Column(name = "travel_type")
    public String travelType;

    /** 食事 */
    @Column(name = "travel_meal")
    public String travelMeal;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}