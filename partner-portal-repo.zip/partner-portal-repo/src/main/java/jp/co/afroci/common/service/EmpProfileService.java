package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpProfileDao;
import jp.co.afroci.common.domain.dao.S10TEmpProfileDao;
import jp.co.afroci.common.domain.entity.S10TEmpProfile;

/**
 * 従業員情報を取り扱うService
 */
@Service
public class EmpProfileService extends AbstractService {

	@Autowired
	private S10TEmpProfileDao dao;
	@Autowired
	private CustomS10TEmpProfileDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpProfile entity) {
		return dao.insert((S10TEmpProfile)super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S10TEmpProfile entity) {
		return dao.update((S10TEmpProfile)super.getEntity(entity));
	}


	/**
	 * 削除登録.
	 */
	public int delete(S10TEmpProfile entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー(ユーザ)検索.
	 */
	public S10TEmpProfile selectId(String userCd) {
		return dao.selectById(userCd);
	}

	/**
	 * 全件検索.
	 */
	public List<S10TEmpProfile> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * シーケンス取得.
	 */
	public String selectEmpNoSeq() {
		return customDao.selectEmpNoSeq();
	}

}