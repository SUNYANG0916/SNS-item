package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpCarrierSkillDao;
import jp.co.afroci.common.domain.dao.S10TEmpCarrierSkillDao;
import jp.co.afroci.common.domain.entity.S10TEmpCarrierSkill;
import jp.co.afroci.common.dto.EmpSkillDto;

/**
 * 職歴情報を取り扱うService
 */
@Service
public class EmpCarrierSkillService extends AbstractService {

	@Autowired
	private S10TEmpCarrierSkillDao dao;
	@Autowired
	private CustomS10TEmpCarrierSkillDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpCarrierSkill entity) {
		return dao.insert((S10TEmpCarrierSkill)super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpCarrierSkill entity) {
		return dao.update((S10TEmpCarrierSkill)super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpCarrierSkill entity) {
		return dao.delete(entity);
	}


	/**
	 * 主キー検索.
	 */
	public S10TEmpCarrierSkill selectId(String userCd, int sequence) {
		return dao.selectById(userCd, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpCarrierSkill> selectUser(String userCd) {
		return customDao.selectByUserCd(userCd);
	}

	/**
	 * 全件検索.
	 */
	public List<S10TEmpCarrierSkill> selectAll() {
		return customDao.selectAll();
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}

	public List<EmpSkillDto> selectEmpOs(String userCd) {
		return customDao.selectEmpOs(userCd);
	}

	public List<EmpSkillDto> selectEmpDb(String userCd) {
		return customDao.selectEmpDb(userCd);
	}

	public List<EmpSkillDto> selectEmpProgram(String userCd) {
		return customDao.selectEmpProgram(userCd);
	}
}