package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * スケジュール情報DTO
 */
@Data
@Entity
public class ScheduleDto {

	/** シーケンス. */
	public String sequence;
	/** 従業員コード. */
	public String userCd;
	/** 従業員名. */
	public String userName;
	/** 対象日. */
	public String scheduleDate;
	/** 行番号. */
	public String rowNo;
	/** 開始時刻. */
	public String startTime;
	/** 終了時刻. */
	public String endTime;
	/** スケジュールタイトル. */
	public String scheduleTitle;
	/** スケジュール内容. */
	public String scheduleText;

}
