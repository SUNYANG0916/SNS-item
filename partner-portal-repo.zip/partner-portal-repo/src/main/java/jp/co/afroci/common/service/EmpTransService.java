package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpTransportDao;
import jp.co.afroci.common.domain.dao.S10TEmpTransportDao;
import jp.co.afroci.common.domain.entity.S10TEmpTransport;

/**
 * 交通費申請情報を取り扱うService
 */
@Service
public class EmpTransService extends AbstractService {

	@Autowired
	private S10TEmpTransportDao dao;
	@Autowired
	private CustomS10TEmpTransportDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpTransport entity) {
		return dao.insert(entity);
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpTransport entity) {
		return dao.update(entity);
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpTransport entity) {
		return dao.delete(entity);
	}


	/**
	 * 主キー検索.
	 */
	public S10TEmpTransport selectId(String userCd, String transYm, int sequence) {
		return dao.selectById(userCd, transYm, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpTransport> selectByUserYm(String userCd, String transYm) {
		return customDao.selectByUserYm(userCd, transYm);
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}