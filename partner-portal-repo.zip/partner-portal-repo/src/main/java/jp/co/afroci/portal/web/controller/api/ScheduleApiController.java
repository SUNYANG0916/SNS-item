package jp.co.afroci.portal.web.controller.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10TSchedule;
import jp.co.afroci.common.domain.entity.S10TScheduleDetail;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.dto.ScheduleDto;
import jp.co.afroci.common.service.ScheduleService;
import jp.co.afroci.portal.web.config.SettingsConfig;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;

/**
 * スケジュールコントローラ.
 */
@RestController
public class ScheduleApiController extends AbstractApiController {

	@Autowired
	SettingsConfig settingsConfig;

	@Autowired
	private ScheduleService service;

	/**
	 * スケジュール情報初期化.
	 */
	@RequestMapping(value = "/user/s10f005_init", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S10F005, null);


		return JSON.encode(applyObj);
	}

	/**
	 * スケジュール情報検索.
	 */
	@RequestMapping(value = "/user/s10f005_search", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

		Map<String, Object> applyObj = new HashMap<String, Object>();
		String scheduleYm = request.getParameter("scheduleYm");
		LoginUserDto userinfo = super.getUserInfo();
		// ログインユーザスケジュール
		applyObj.put("tbl_schedules_list", this.getListLoginUser(scheduleYm, userinfo.getUserCd()));
		// 他のユーザのスケジュール
		String searchConditions = request.getParameter("searchConditions");
		applyObj.put("tbl_schedules_all_list", this.getList(scheduleYm, searchConditions, userinfo.getUserCd()));
		return JSON.encode(applyObj);
	}

	private List<Map<String, Object>> getListLoginUser(String scheduleYm, String userCd) {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        String sequence = "";
        String display = "";
        Map<String, Object> map = new HashMap<String, Object>();
		for (ScheduleDto s10TSchedule : this.service.selectByYmUser(scheduleYm, userCd)) {
			String title = s10TSchedule.scheduleTitle;
			if(StringUtils.isNoneEmpty(title) && title.length() > 3) {
				title = title.substring(0, 3) + "..";
			}
			if (sequence.equals("")) {
				sequence = s10TSchedule.sequence;
				map.put("sequence", s10TSchedule.sequence);
				map.put("scheduleDate", s10TSchedule.scheduleDate);
				display = s10TSchedule.userName + "(" + s10TSchedule.startTime + " " + title;
			} else 	if (!sequence.equals(s10TSchedule.sequence)) {
				map.put("schedule", display + ")");
				list.add(map);

				display = "";
				sequence = s10TSchedule.sequence;
				map = new HashMap<String, Object>();
				map.put("sequence", s10TSchedule.sequence);
				map.put("scheduleDate", s10TSchedule.scheduleDate);
				display = s10TSchedule.userName + "(" + s10TSchedule.startTime + " " + title;
			} else {
				display += "," + s10TSchedule.startTime + " " + title;
			}
		}
		map.put("schedule", display + ")");
		list.add(map);
		return list;
	}


	private List<Map<String, Object>> getList(String scheduleYm, String searchConditions, String loginUserCd) {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        String sequence = "";
        String display = "";
        Map<String, Object> map = new HashMap<String, Object>();
		for (ScheduleDto s10TSchedule : this.service.selectByYm(scheduleYm, searchConditions)) {
			if (loginUserCd.equals(s10TSchedule.userCd)) {
				continue;
			}
			String title = s10TSchedule.scheduleTitle;
			if(StringUtils.isNoneEmpty(title) && title.length() > 3) {
				title = title.substring(0, 3) + "..";
			}
			if (sequence.equals("")) {
				sequence = s10TSchedule.sequence;
				map.put("sequence", s10TSchedule.sequence);
				map.put("userName", s10TSchedule.userName);
				map.put("scheduleDate", s10TSchedule.scheduleDate);
				display = s10TSchedule.userName + "(" + s10TSchedule.startTime + " " + title;
			} else 	if (!sequence.equals(s10TSchedule.sequence)) {
				map.put("schedule", display + ")");
				list.add(map);

				display = "";
				sequence = s10TSchedule.sequence;
				map = new HashMap<String, Object>();
				map.put("sequence", s10TSchedule.sequence);
				map.put("userName", s10TSchedule.userName);
				map.put("scheduleDate", s10TSchedule.scheduleDate);
				display = s10TSchedule.userName + "(" + s10TSchedule.startTime + " " + title;
			} else {
				display += "," + s10TSchedule.startTime + " " + title;
			}
		}
		map.put("schedule", display + ")");
		list.add(map);
		return list;
	}

	/**
	 * スケジュール詳細検索.
	 */
	@RequestMapping(value="/user/s10f005_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_schedule_list", this.service.selectByUser(super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}

	/**
	 * スケジュール全員詳細検索.
	 */
	@RequestMapping(value="/user/s10f005_alldetails", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getAllDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_schedule_all_list", this.service.selectByUser(super.getTargetSequence(request)));

		return JSON.encode(applyObj);
	}

    /**
     * スケジュール登録更新削除.
     */
    @RequestMapping(value="/user/s10f005_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    private String updateDetails(HttpServletRequest request, @RequestBody Map<String, Object> model) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");

		LoginUserDto userinfo = super.getUserInfo();

		Integer sequence = Integer.valueOf((String) model.get("sequence"));
    	String scheduleDate = (String) model.get("scheduleDate");

    	S10TSchedule inEntity = new S10TSchedule();
		inEntity.userCd = userinfo.getUserCd();
		inEntity.scheduleDate =  scheduleDate;
		inEntity.userName = userinfo.getLoginUserName();
		inEntity.sequence = sequence;

    	Object scheduleList = model.get("scheduleList");
    	List<Map<String, String>> inEntitys = ((List<Map<String, String>>) scheduleList);

    	boolean isFfist = Boolean.TRUE;
    	for (Map<String, String> map : inEntitys) {
			if (isFfist) {
				if (sequence == 0) {
					// 新規
					sequence = this.service.selectSeq();
					inEntity.sequence = sequence;
					this.service.insert(inEntity);
				} else {
					// 一括削除
					for (S10TScheduleDetail s10TScheduleDetail : this.service.selectByDetailUser(sequence)) {
						this.service.delete(s10TScheduleDetail);
					}
				}
				isFfist = Boolean.FALSE;
			}

            // 一括登録
            S10TScheduleDetail entity = new S10TScheduleDetail();

        	entity.sequence = sequence;
        	entity.rowNo = Integer.valueOf(map.get("rowNumber"));
        	entity.startTime = map.get("startTime");
        	entity.endTime = map.get("endTime");
        	entity.scheduleTitle = map.get("scheduleTitle");
        	entity.scheduleText = map.get("scheduleText");

            this.service.insert(entity);
    	}

    	// 明細一件もない場合削除
    	if (inEntitys.size() == 0) {
			// 明細一括削除
			for (S10TScheduleDetail s10TScheduleDetail : this.service.selectByDetailUser(sequence)) {
				this.service.delete(s10TScheduleDetail);
			}
			// ヘッダー削除
			this.service.delete(inEntity);
            resutlObj.put("msg", "削除処理が完了しました。");
    	} else {
            resutlObj.put("msg", "登録処理が完了しました。");
    	}

        return JSON.encode(resutlObj);
    }
}
