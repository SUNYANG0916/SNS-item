package jp.co.afroci.portal.web.controller.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MItem;
import jp.co.afroci.common.service.ItemMasterService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * S00F005-項目マスタコントローラ.
 */
@RestController
public class ItemMasterController extends AbstractApiController {

	@Autowired
	private ItemMasterService service;

	/**
	 * 項目マスタ情報初期化.
	 */
	@RequestMapping(value="/user/s00f005_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		return JSON.encode(super.getApplyObj(Constants.APPLY_ID.S00F005, null));
	}

	/**
	 * 項目マスタ情報検索.
	 */
	@RequestMapping(value="/user/s00f005_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getList(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_item_type_list", this.service.selectItemTypeAll());

		return JSON.encode(applyObj);
	}

	/**
	 * 項目マスタ明細検索.
	 */
	@RequestMapping(value="/user/s00f005_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String getDetails(HttpServletRequest request, Map<String, String> map) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        applyObj.put("tbl_item_list", this.service.selectByItemType(request.getParameter("itemType"), null));
		return JSON.encode(applyObj);
	}

	/**
	 * 項目マスタ情報登録.
	 */
	@RequestMapping(value="/user/s00f005_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(@RequestBody List<S00MItem> inEntitys) {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");

		for (S00MItem inEntity : inEntitys) {
			if (inEntity.deleteFlg == null) {
				inEntity.deleteFlg = Constants.DELETE_FLAG.OFF;
			}
			if (inEntity.itemSort == null) {
				inEntity.itemSort = 0;
			}

			if (inEntity.itemCd == null || inEntity.itemCd.equals("")) {
				// 新規
				// 項目コード採番
				inEntity.itemCd = this.service.selectItemNumbering(inEntity.itemType).itemCd;
				inEntity.itemVal = inEntity.itemType + "-" + inEntity.itemCd;

				this.service.insert(inEntity);
				resutlObj.put("msg", "登録処理が完了しました。");
			} else {
				// 更新
				S00MItem entity = this.service.selectId(inEntity.itemType, inEntity.itemCd);

				inEntity.createUser = entity.createUser;
				inEntity.createDate = entity.createDate;

				this.service.update(inEntity);
				resutlObj.put("msg", "更新処理が完了しました。");
			}
		}

		return JSON.encode(resutlObj);
	}

}
