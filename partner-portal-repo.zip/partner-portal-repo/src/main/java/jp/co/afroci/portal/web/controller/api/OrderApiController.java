package jp.co.afroci.portal.web.controller.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S10MSuppliers;
import jp.co.afroci.common.domain.entity.S20TOrder;
import jp.co.afroci.common.domain.entity.S20TOrderDetail;
import jp.co.afroci.common.service.OrderDetailService;
import jp.co.afroci.common.service.OrderService;
import jp.co.afroci.common.service.SuppliersService;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import jp.co.afroci.portal.web.util.Constants.DELETE_FLAG;
import net.arnx.jsonic.JSON;


/**
 * 注文書マスタコントローラ.
 */
@RestController
public class OrderApiController extends AbstractApiController {

    @Autowired
    private OrderService service;

    @Autowired
    private SuppliersService suppliersService;

    @Autowired
    private OrderDetailService orderDetailService;

    /** コンストラクタ. */
    public OrderApiController() {
        super();
    }

    /**
     * 画面初期ロードリクエスト.
     */
    @RequestMapping(value="/user/s30f002_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String init(Model model) {
        Map<String, Object> applyObj = super.getApplyObj(Constants.APPLY_ID.S30F002, null);
        // 項目マスタリスト取得対象
        String[][] items = {
                { Constants.ITEMS.ITEM_30033, "selPaymentTime", "" ,""},
                { Constants.ITEMS.ITEM_30031, "selDelete", "", ""},
                { Constants.ITEMS.ITEM_30034, "selCommissionType", "", ""},
                { Constants.ITEMS.ITEM_30035, "selAgreementType", "", ""}
        };
        this.service.setSelectItems(applyObj, items);

        return JSON.encode(applyObj);
    }

    /**
     * 注文書マスタ検索.
     */
    @RequestMapping(value="/user/s30f002_search", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getList(HttpServletRequest request, Model model) {
        Map<String, Object> applyObj = new HashMap<String, Object>();

        // キーワード検索条件
        String conditions = "%" + request.getParameter("cond") + "%";
        // 有効／失効（削除フラグ）
        String selDelete = request.getParameter("selDelete");
        String deleteFlag = null;
        if (selDelete.equals("30031-001")) {
            // 有効のみ
            deleteFlag = DELETE_FLAG.OFF;
        } else if (selDelete.equals("30031-002")) {
            // 失効のみ
            deleteFlag = DELETE_FLAG.ON;
        }

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (S20TOrder entity : service.selectAll(conditions, deleteFlag)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("orderNo", entity.orderNo);
            map.put("matterName", entity.matterName);
            map.put("suppliersToName", entity.suppliersToName);
            map.put("periodS", entity.periodS);
            map.put("periodE", entity.periodE);
            map.put("amountTotal", entity.amountTotal);
            list.add(map);
        }
        applyObj.put("tbl_order_list", list);

        return JSON.encode(applyObj);
    }

    /**
     * 注文書明細検索.
     */
    @RequestMapping(value="/user/s30f002_details", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getDetails(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();
        List<Map<String, Object>> tbl_working_list = new ArrayList<Map<String, Object>>();
        String orderNo = request.getParameter("orderNo");
        // 請求データ
        S20TOrder s20TOrder = service.selectId(orderNo);

        applyObj.put("agreementTypeName",this.service.getItemName(s20TOrder.agreementType));
        applyObj.put("paymentTimeName",this.service.getItemName(s20TOrder.paymentTime));
        applyObj.put("commissionTypeName", this.service.getItemName(s20TOrder.commissionType));

        applyObj.put("tbl_order_list", s20TOrder);


        // 請求明細データ
        BigDecimal amountSum = BigDecimal.ZERO;
        for (S20TOrderDetail entity : orderDetailService.selectByOrderDetail(orderNo)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("orderNo", entity.orderNo);
            map.put("quantity", entity.quantity);
            map.put("unitAmount", entity.unitAmount);
            map.put("amount", entity.amount);
            amountSum = amountSum.add(entity.amount);
            map.put("workingInfo", entity.workingInfo);
            map.put("workingDays", entity.workingDays);
            map.put("businessDays", entity.businessDays);
            map.put("note", entity.note);
            tbl_working_list.add(map);
        }
        // 明細リスト
        applyObj.put("tbl_working_list", tbl_working_list);

        // 消費税
        BigDecimal amountTax = s20TOrder.amountTotal.subtract(amountSum);
        applyObj.put("amountTax", amountTax);
        // 税抜き
        applyObj.put("amountSum",amountSum);
        // 総額
        applyObj.put("amountTotal", s20TOrder.amountTotal);

        return JSON.encode(applyObj);
    }

    /**
     * 注文書マスタ登録.
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s30f002_update", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String update(@RequestBody S20TOrder inEntity) {
        Map<String, Object> resultObj = new HashMap<String, Object>();
        resultObj.put("result", "ok");

        S20TOrder entity = service.selectId(inEntity.orderNo);
        try {
            if (entity == null) {
                // 新規
                String orderNo = "00000" + String.valueOf(service.selectSeq());
                inEntity.orderNo = "O" + orderNo.substring(orderNo.length() - 6);
                service.insert(inEntity);
                resultObj.put("msg", "登録処理が完了しました。");
            } else {
                // 更新
                inEntity.deleteFlg = entity.deleteFlg;
                service.update(inEntity);
                resultObj.put("msg", "更新処理が完了しました。");
            }
            resultObj.put("orderNo", inEntity.orderNo);
        } catch (IllegalArgumentException | SecurityException e) {
        	resultObj.put("msg", "処理失敗しました。");
        	resultObj.put("result", "error");
        }

        return JSON.encode(resultObj);
    }


    /**
     * 注文書明細登録.
     */
    @RequestMapping(value="/user/s30f002_updateDetails", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    private String updateUserRole(HttpServletRequest request, @RequestBody List<S20TOrderDetail> inEntitys) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");

        // 一括削除
        String orderNo = inEntitys.get(0).orderNo;
        for (S20TOrderDetail orderDetail : this.orderDetailService.selectByOrderDetail(orderNo)) {
            this.orderDetailService.delete(orderDetail);
        }

        // 一括登録
        for (S20TOrderDetail entity : inEntitys) {
            this.orderDetailService.insert(entity);
            resutlObj.put("msg", "登録処理が完了しました。");
        }
        return JSON.encode(resutlObj);
    }



    /**
     * 注文書マスタ論理削除.
     * @throws IllegalAccessException
     * @throws NoSuchFieldException
     */
    @RequestMapping(value="/user/s30f002_delete", method=RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String delete(@RequestBody S20TOrder inEntity) {
        Map<String, Object> resutlObj = new HashMap<String, Object>();
        resutlObj.put("result", "ok");
        try {
            S20TOrder entity = service.selectId(inEntity.orderNo);
            entity.deleteFlg = DELETE_FLAG.ON;
            service.update(entity);
            resutlObj.put("msg", "廃止処理が完了しました。");
        } catch (IllegalArgumentException | SecurityException e) {
            resutlObj.put("msg", "処理失敗しました。");
            resutlObj.put("result", "error");
        }

        return JSON.encode(resutlObj);
    }

    /**
     * 取引先検索.
     */
    @RequestMapping(value="/user/s30f002_master_suppliers", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
    public String getMasterSuppliers(HttpServletRequest request, Model model) {

        Map<String, Object> applyObj = new HashMap<String, Object>();

        String cond = "%" + request.getParameter("cond") + "%";

        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        for (S10MSuppliers s10MSuppliers : suppliersService.selectAll(cond, "0")) {
        	Map<String, String> map = new HashMap<String, String>();
        	map.put("suppliersNo", s10MSuppliers.suppliersNo);
        	map.put("suppliersName", s10MSuppliers.suppliersName);
        	map.put("suppliersJson", JSON.encode(s10MSuppliers));
        	list.add(map);
        }
        applyObj.put("tbl_suppliers_list", list);

        return JSON.encode(applyObj);
    }

}
