package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S10TEmpApply;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS10TEmpApplyDao {


    /**
     * @param userCd
     * @return the CustomS10TEmpApply entity
     */
    @Select
    List<S10TEmpApply> selectByUserYm(String userCd, String occurYm, String settleType);

    /**
     * @return the シーケンス
     */
    @Select
    Integer selectSeq();
}