package jp.co.afroci.common.domain.dao;

import jp.co.afroci.common.domain.entity.TContact;
import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface TContactDao {

    /**
     * @param contactSeq
     * @return the TContact entity
     */
    @Select
    TContact selectById(String contactSeq);

    /**
     * @param entity
     * @return affected rows
     */
    @Insert
    int insert(TContact entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Update
    int update(TContact entity);

    /**
     * @param entity
     * @return affected rows
     */
    @Delete
    int delete(TContact entity);
}