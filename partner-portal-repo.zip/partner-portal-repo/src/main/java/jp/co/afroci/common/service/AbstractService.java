package jp.co.afroci.common.service;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;

import jp.co.afroci.common.domain.custom.CustomS00MItemDao;
import jp.co.afroci.common.domain.entity.S00MItem;
import jp.co.afroci.common.domain.entity.S00MPostal;
import jp.co.afroci.common.dto.ItemInfoDto;
import jp.co.afroci.common.dto.LoginUserDto;

public class AbstractService {

    @Autowired
    private CustomS00MItemDao customDao;

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    protected Map<String, List<ItemInfoDto>> itemList = null;

    public static final String OPT_TXT_COL = "item_txt";
    public static final String OPT_VAL_COL = "item_val";
    public static final String OPT_TXT_KEY = "txt";
    public static final String OPT_VAL_KEY = "val";

    public AbstractService() {
    }

	/**
	 * ログイン情報の取得.
	 * */
	protected LoginUserDto getUserInfo() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof LoginUserDto) {
			return (LoginUserDto) principal;
		}

		return null;
	}

    public List<ItemInfoDto> getItems(String key) {
        if (itemList == null || itemList.size() == 0) {
            itemList = new HashMap<String, List<ItemInfoDto>>();
            for (S00MItem item : customDao.selectAll()) {
                if (itemList.get(item.itemType) == null) {
                    itemList.put(item.itemType, new ArrayList<ItemInfoDto>());
                }
                ItemInfoDto itemInfoDto = new ItemInfoDto();
                itemInfoDto.itemCd = item.itemCd;
                itemInfoDto.itemTxt = item.itemTxt;
                itemInfoDto.itemVal = item.itemVal;
                itemInfoDto.itemType = item.itemType;
                itemList.get(item.itemType).add(itemInfoDto);
            }
        }
        return itemList.get(key);
    }

    public String getItemName(String key) {
    	if (!StringUtils.isEmpty(key)) {
            String[] keys = key.split("-");
            for (ItemInfoDto item : getItems(keys[0])) {
                if (item.itemVal.equals(key)) {
                    return item.itemTxt;
                }
            }
    	}
        return "";
    }

    public String getItemNames(String keys) {
        String result = "";
        if (!StringUtils.isEmpty(keys)) {
            for (String val : keys.split("\\|")) {
                if (val.length() > 0) {
                    if (!result.equals("")) {
                        result += ", ";
                    }
                    result += this.getItemName(val);
                }
            }
        }
        return result;
    }

    public void setSelectItems(Map<String, Object> request, String[][] items) {
        // 対象ごと処理実施
        for (int i = 0; i < items.length; i++) {
        	boolean isBrank = false;
        	boolean isDispCd = false;
            // 項目タイプ
            String itemType = items[i][0];
            // リストID
            String listId = items[i][1];
            // 値項目ID
            String listVal = items[i][2];
            // 表示項目ID
            String listTxt = items[i][3];

            if (items[i].length > 4) {
            	isBrank = Boolean.valueOf(items[i][4]);
            }
            if (items[i].length > 5) {
            	isDispCd = Boolean.valueOf(items[i][5]);
            }

            List<ItemInfoDto> list = getItems(itemType);
            // 結果設定
            request.put(listId, this.getItemOption(list, listVal, listTxt, isBrank, isDispCd));
        }
    }


    /**
     * 項目マスタのリスト取得メソッド.
     *
     * @param list 対象リスト
     * @param key_val 値項目キー
     * @param key_txt 表示項目キー
     * @param isBrank 先頭空行作成区分
     * @param isDispCd 表示項目に値（コード）表示区分
     *
     * @return 処理結果マップリスト
     * */
    public List<Map<String, String>> getItemOption(List<ItemInfoDto> list, String key_val, String key_txt, boolean isBrank, boolean isDispCd) {
        List<Map<String, String>> opts = new ArrayList<Map<String, String>>();
        if (key_txt.equals("")) key_txt = OPT_TXT_KEY;
        if (key_val.equals("")) key_val = OPT_VAL_KEY;
        // 先頭空行ありの場合
        if (isBrank == true) {
            Map<String, String> opt = new HashMap<String, String>();
            opt.put(key_txt, "");
            opt.put(key_val, "");
            opts.add(opt);
        }
        // リスト内容作成
        for (ItemInfoDto item : list) {
            Map<String, String> opt = new HashMap<String, String>();
            if (isDispCd == true) {
                opt.put(key_txt, item.itemVal + " " + item.itemTxt);
                opt.put(key_val, item.itemVal);
            } else {
                opt.put(key_txt, item.itemTxt);
                opt.put(key_val, item.itemVal);
            }
            opts.add(opt);
        }
        // 処理結果を返す
        return opts;
    };

    /**
     * 郵便番号検索.
     */
    public List<S00MPostal> selectZip(String zipCd) {
        return this.jdbcTemplate.query(
                "select * from s00_m_postal where zip_cd='" + zipCd + "'",
                new BeanPropertyRowMapper<S00MPostal>(S00MPostal.class));
    }

    /**
     * エンティティ取得.
     */
    public Object getEntity(Object entity) {
    	LoginUserDto user = this.getUserInfo();
        // 作成者
		try {
			// 削除フラグ
			Field fdDeleteFlg = entity.getClass().getDeclaredField("deleteFlg");
			if (fdDeleteFlg.get(entity) == null || fdDeleteFlg.get(entity).equals("")) {
				fdDeleteFlg.set(entity, "0");
			}
			Field fdCreateUser = entity.getClass().getDeclaredField("createUser");
			if(fdCreateUser.get(entity) == null || fdDeleteFlg.get(entity).equals("")) {
			    fdCreateUser.set(entity, user.getUserCd());
			}
	        // 作成日時
	        Field fdCreateDate = entity.getClass().getDeclaredField("createDate");
	        if(fdCreateDate.get(entity) == null) {
	            fdCreateDate.set(entity, LocalDateTime.now());
	        }
	        // 更新カウンタ
	        Field fdUpdateCnt = entity.getClass().getDeclaredField("updateCnt");
	        if(fdUpdateCnt.get(entity) == null) {
	            fdUpdateCnt.set(entity, 1);
	        } else {
	            fdUpdateCnt.set(entity, fdUpdateCnt.getInt(entity) + 1);
	        }
	        // 更新者
	        Field fdUpdateUser = entity.getClass().getDeclaredField("updateUser");
	        fdUpdateUser.set(entity, user.getUserCd());
	        // 更新日時
	        Field fdUpdateDate = entity.getClass().getDeclaredField("updateDate");
	        fdUpdateDate.set(entity, LocalDateTime.now());

		} catch (SecurityException | NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}

        return entity;
    }
}
