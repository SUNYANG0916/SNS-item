package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MRoles;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS00MRolesDao {

    /**
     * @param roleId
     * @return the S00MRoles entity
     */
    @Select
    List<S00MRoles> selectAll(String conditions, String deleteFlag);

}