package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TWorkingDetailDao;
import jp.co.afroci.common.domain.dao.S10TWorkingDetailDao;
import jp.co.afroci.common.domain.entity.S10TWorkingDetail;
import jp.co.afroci.common.dto.WorkingListDto;

/**
 * 稼働情報を取り扱うService
 */
@Service
public class WorkingService extends AbstractService {

	@Autowired
	private S10TWorkingDetailDao dao;
	@Autowired
	private CustomS10TWorkingDetailDao customDao;


    /**
     * 主キー検索.
     */
    public S10TWorkingDetail selectId(String userCd, String pjCd, String workingMonth) {
        return dao.selectById(userCd, pjCd, workingMonth);
    }

	/**
	 * 新規登録
	 */
	public int insert(S10TWorkingDetail entity) {
		return dao.insert((S10TWorkingDetail) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TWorkingDetail entity) {
		return dao.update((S10TWorkingDetail) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TWorkingDetail entity) {
		return dao.delete(entity);
	}

	/**
	 * ユーザの稼働情報を検索.
	 */
	public List<WorkingListDto> selectByUserCd(String userCd) {
		return customDao.selectByUserCd(userCd);
	}


	/**
	 * ユーザの作業情報を検索.
	 */
	public List<WorkingListDto> selectByYM(String userCd, String workingMonth) {
		return customDao.selectByYM(userCd, workingMonth);
	}

}