package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS20TEstimateDetailDao;
import jp.co.afroci.common.domain.dao.S20TEstimateDetailDao;
import jp.co.afroci.common.domain.entity.S20TEstimateDetail;

/**
 * 見積明細情報を取り扱うService
 */
@Service
public class EstimateDetailService extends AbstractService {

	@Autowired
	private S20TEstimateDetailDao dao;

	@Autowired
	private CustomS20TEstimateDetailDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S20TEstimateDetail entity) {
		return dao.insert((S20TEstimateDetail) super.getEntity(entity));
	}

	/**
	 * 更新登録.
	 */
	public int update(S20TEstimateDetail entity) {
		return dao.update((S20TEstimateDetail) super.getEntity(entity));
	}

	/**
	 * 削除登録.
	 */
	public int delete(S20TEstimateDetail entity) {
		return dao.delete(entity);
	}

	/**
	 * 見積書明細取得.
	 */
	public List<S20TEstimateDetail> selectByEstimateDetail(String estimateNo) {
		return customDao.selectByEstimateAll(estimateNo);
	}
}
