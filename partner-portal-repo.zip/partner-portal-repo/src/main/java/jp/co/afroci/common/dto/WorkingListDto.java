package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * 稼働情報DTO
 */
@Data
@Entity
public class WorkingListDto {

	/** プロジェクトコード. */
	public String pjCd;
	/** プロジェクト名称. */
	public String pjNm;
	/** 稼働年月. */
	public String workingMonth;
	/** 稼働時間. */
	public String workingTimes;
	/** 原価. */
	public String costAmount;
	/** 単価. */
	public String unitAmount;
	/** 備考. */
	public String note;

}
