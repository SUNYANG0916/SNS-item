package jp.co.afroci.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.custom.CustomS10TEmpApplyDao;
import jp.co.afroci.common.domain.dao.S10TEmpApplyDao;
import jp.co.afroci.common.domain.entity.S10TEmpApply;

/**
 * 交通費申請情報を取り扱うService
 */
@Service
public class EmpApplyService extends AbstractService {

	@Autowired
	private S10TEmpApplyDao dao;
	@Autowired
	private CustomS10TEmpApplyDao customDao;

	/**
	 * 新規登録.
	 */
	public int insert(S10TEmpApply entity) {
		return dao.insert((S10TEmpApply) super.getEntity(entity));
	}

	/**
	 * 更新.
	 */
	public int update(S10TEmpApply entity) {
		return dao.update((S10TEmpApply) super.getEntity(entity));
	}

	/**
	 * 削除.
	 */
	public int delete(S10TEmpApply entity) {
		return dao.delete(entity);
	}


	/**
	 * 主キー検索.
	 */
	public S10TEmpApply selectId(String userCd, String occurYm, int sequence) {
		return dao.selectById(userCd, occurYm, sequence);
	}

	/**
	 * ユーザ検索.
	 */
	public List<S10TEmpApply> selectByUserYm(String userCd, String occurYm, String settleType) {
		return customDao.selectByUserYm(userCd, occurYm, settleType);
	}

	/**
	 * シーケンス取得.
	 */
	public Integer selectSeq() {
		return customDao.selectSeq();
	}
}