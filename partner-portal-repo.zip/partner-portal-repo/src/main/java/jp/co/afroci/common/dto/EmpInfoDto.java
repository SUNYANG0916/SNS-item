package jp.co.afroci.common.dto;

import org.seasar.doma.Entity;

import lombok.Data;

/**
 * 社員情報DTO
 */
@Data
@Entity
public class EmpInfoDto {

	/** 社員コード. */
	public String loginId;
	/** 社員コード. */
	public String userCd;
	/** 社員名. */
	public String loginUserName;
	/** 部署コード. */
	public String busyoCd;
	/** パスワード. */
	public String password;
	/** 社員イニシャル. */
	public String userInitial;
	/** 社員情報表示１（基本情報）. */
	public String dispDetail1;
	/** 社員情報表示２（学歴情報）. */
	public String dispDetail2;
	/** 社員情報表示３（資格情報）. */
	public String dispDetail3;
	/** 社員情報表示４（職務情報）. */
	public String dispDetail4;
	/** 社員情報表示５（スキル情報）. */
	public String dispDetail5;
	/** 社員情報表示６（スキル情報DL）. */
	public String dispDetail6;
	/** 社員情報表示７（申請情報）. */
	public String dispDetail7;
	/** 社員情報表示８（稼働情報）. */
	public String dispDetail8;
	/** 社員情報表示９（作業報告）. */
	public String dispDetail9;
}
