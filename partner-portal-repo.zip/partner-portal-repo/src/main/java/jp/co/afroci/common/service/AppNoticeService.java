package jp.co.afroci.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.afroci.common.domain.dao.S11TAlertNoticeDao;
import jp.co.afroci.common.domain.entity.S11TAlertNotice;

@Service
public class AppNoticeService extends AbstractService {
	@Autowired
	private S11TAlertNoticeDao dao;
	/**
	 * 新規登録.
	 */
	public int insert(S11TAlertNotice entity) {
		return dao.insert(entity);
	}

	/**
	 * 更新.
	 */
	public int update(S11TAlertNotice entity) {
		return dao.update(entity);
	}

	/**
	 * 削除.
	 */
	public int delete(S11TAlertNotice entity) {
		return dao.delete(entity);
	}

	/**
	 * 主キー検索.
	 */
	public S11TAlertNotice selectId(Integer noticeId) {
		return dao.selectById(noticeId);
	}

	public S11TAlertNotice getLastNotice() {
		return null;
	}
}
