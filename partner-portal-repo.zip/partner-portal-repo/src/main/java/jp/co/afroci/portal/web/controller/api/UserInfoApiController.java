package jp.co.afroci.portal.web.controller.api;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.afroci.common.domain.entity.S00MUser;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.service.UserInfoService;
import jp.co.afroci.common.util.CipherUtil;
import jp.co.afroci.portal.web.controller.AbstractApiController;
import jp.co.afroci.portal.web.util.Constants;
import net.arnx.jsonic.JSON;


/**
 * パスワード更新コントローラ.
 */
@RestController
public class UserInfoApiController extends AbstractApiController {

	@Autowired
	private UserInfoService service;

	/**
	 * パスワード更新画面初期化.
	 */
	@RequestMapping(value="/user/s00f003_init", method=RequestMethod.GET, produces="text/plain;charset=UTF-8")
	public String init(HttpServletRequest request, Model model) {
		return JSON.encode(super.getApplyObj(Constants.APPLY_ID.S00F003, null));
	}


	/**
	 * パスワード登録.
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws InvalidKeyException
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 */
	@RequestMapping(value="/user/s00f003_update", method=RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String update(HttpServletRequest request, Map<String, String> model)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
    	Map<String, Object> resutlObj = new HashMap<String, Object>();
		resutlObj.put("result", "ok");
		LoginUserDto userinfo = super.getUserInfo();
		String EncPassword = CipherUtil.encrypt(request.getParameter("password"), CipherUtil.key, CipherUtil.ALGORITHM_AES);
		S00MUser entity = this.service.selectPassword(userinfo.getUserCd(), EncPassword);
		if (entity == null) {
		    resutlObj.put("result", "error");
		    resutlObj.put("msg", "パスワード不一致");
		    return JSON.encode(resutlObj);
		}

		String EncPasswordNew = CipherUtil.encrypt(request.getParameter("passwordNew"), CipherUtil.key, CipherUtil.ALGORITHM_AES);
		entity.password = EncPasswordNew;
		// 更新
		this.service.update(entity);

		resutlObj.put("msg", "パスワードを更新しました。");

		return JSON.encode(resutlObj);
	}

}
