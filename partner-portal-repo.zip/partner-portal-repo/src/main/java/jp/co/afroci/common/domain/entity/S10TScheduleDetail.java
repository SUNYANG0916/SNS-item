package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * スケジュール明細
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_t_schedule_detail")
public class S10TScheduleDetail {

    /** シーケンス */
    @Id
    @Column(name = "sequence")
    public Integer sequence;

    /** 行番号 */
    @Id
    @Column(name = "row_no")
    public Integer rowNo;

    /** 時刻（開始） */
    @Column(name = "start_time")
    public String startTime;

    /** 時刻（終了） */
    @Column(name = "end_time")
    public String endTime;

    /** タイトル */
    @Column(name = "schedule_title")
    public String scheduleTitle;

    /** 内容 */
    @Column(name = "schedule_text")
    public String scheduleText;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}