package jp.co.afroci.portal.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.afroci.common.domain.dao.S00MUserDao;
import jp.co.afroci.common.domain.entity.S00MItem;
import jp.co.afroci.common.dto.ApplyDto;
import jp.co.afroci.common.dto.EmpInfoDto;
import jp.co.afroci.common.dto.LoginUserDto;
import jp.co.afroci.common.service.ItemMasterService;
import jp.co.afroci.portal.web.config.SettingsConfig;
import jp.co.afroci.portal.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public abstract class AbstractController {
	@Autowired
	protected HttpSession session;

	@Autowired
	protected SettingsConfig settingsConfig;

	@Autowired
	protected S00MUserDao dao;

	@Autowired
	private static ItemMasterService itemMasterSerive;

	/** 項目マスタ一覧. */
	private Map<String, List<S00MItem>> itemList;

	/**
	 * コンストラクタ.
	 * */
	protected AbstractController() {

	}

	/**
	 * ログイン情報の取得.
	 * */
	protected LoginUserDto getUserInfo() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof LoginUserDto) {
			return (LoginUserDto) principal;
		}

		return null;
	}

	/**
	 * アプリケーション情報の取得.
	 * */
	protected Map<String, Object> getApplyObj(String applyId, String userRow) {

		if (Constants.APPLY_ID.S00F001.equals(applyId)) {
			// メニューの場合、セッションクリア
			this.session.setAttribute("target_user_row", null);
		}

		// ユーザ情報
		LoginUserDto user = this.getUserInfo();
		// アプリケーションオブジェクト初期化
		Map<String, Object> applyObj = new HashMap<String, Object>();
		applyObj.put(ApplyDto.KEY_APPLY_ID, applyId);
		// 編集権限取得
    	boolean canEdit = Boolean.FALSE;
        // リクエスト権限チェック
		if (user.getAuthorities().contains(new SimpleGrantedAuthority("all"))) {
			// 管理者権限
			canEdit = Boolean.TRUE;
		} else {
			// 参照権限
			if (user.getAuthorities()
					.contains(new SimpleGrantedAuthority(applyId + "_r"))) {
			} else {
				// 権限ありません。
				throw new UsernameNotFoundException("アクセス権限がありません。");
			}
			// 更新権限
			if (user.getAuthorities()
					.contains(new SimpleGrantedAuthority(applyId + "_u"))) {
				// 更新権限
				canEdit = Boolean.TRUE;
			}
		}
		if (userRow != null) {
			canEdit = this.canEdit(userRow);
		}
		// ログインユーザ名
		applyObj.put("loginUser", user.getLoginUserName());
		// 処理対象ユーザ名
		if (this.getTargetUser() == null) {
			// メニューから遷移した場合
	    	applyObj.put("userName", user.getLoginUserName());
	    	applyObj.put("isTarget", Boolean.FALSE);
		} else {
			// 社員管理一覧から遷移した場合
	    	applyObj.put("userName", this.getTargetUser().loginUserName);
	    	applyObj.put("isTarget", Boolean.TRUE);
		}

		// 編集権限
		applyObj.put("canEdit", canEdit);

		// アプリケーションオブジェクトを返す
		return applyObj;
	}

	/**
	 * ユーザ管理画面のユーザ一覧取得.
	 * */
	@SuppressWarnings("unchecked")
	protected List<EmpInfoDto> getUserList() {
		Object list = this.session.getAttribute("user_list");
		if (list != null) {
			return (List<EmpInfoDto>) list;
		}
		return null;
	}

	/**
	 * 社員管理画面の社員一覧保持.
	 * */
	protected void setUserList(List<EmpInfoDto> list) {
		this.session.setAttribute("user_list", list);
	}

	/**
	 * 社員管理画面の社員一覧保持.
	 * */
	protected void setTargetUserRow(String userRow) {
		this.session.setAttribute("target_user_row", userRow);
	}

	/**
	 * 社員管理画面の選択社員取得.
	 * */
	protected EmpInfoDto getTargetUser(String userRow) {
		return this.getUserList().get(Integer.parseInt(userRow));
	}

	/**
	 * 社員管理画面の選択社員取得.
	 * */
	protected EmpInfoDto getTargetUser() {
		Object obj = this.session.getAttribute("target_user_row");
		if (obj == null) {
			return null;
		}
		return this.getTargetUser((String) obj);
	}

	/**
	 * 編集可能かどうかを判断.
	 *
	 * @param 社員管理一覧選択した行番号
	 * @return 当該社員の情報を編集可能かどうか（true:可能、flase：不可）
	 * */
	protected boolean canEdit(String userRow) {
		// セッション保持更新
		this.setTargetUserRow(userRow);
		if (userRow != null) {
			// 対象コード取得
		    String targetUserCd = this.getTargetUser().userCd;
		    if (targetUserCd.equals("")) {
		    	return true;
		    }
		    // ログインユーザコードと社員管理の社員一覧から遷移したユーザコードが一致かどうか
		    return this.getUserInfo().getUserCd().equals(targetUserCd);
		}
		return true;
	}


	/**
	 * 処理対象シーケンス情報取得.
	 * */
	protected int getTargetSequence(HttpServletRequest request) {
		Object sequence = request.getParameter("sequence");
		if (sequence != null && !sequence.equals("")) {
			return Integer.parseInt((String) request.getParameter("sequence"));
		}
		return 0;
	}

	/**
	 * 処理対象ユーザコード取得.
	 * */
	protected String getTargetUserCd() {
        String userCd = "";
		if (this.getTargetUser() == null) {
			userCd = this.getUserInfo().getUserCd();
		} else {
			userCd = this.getTargetUser().userCd;
		}
		return userCd;
	}

	/**
	 * 項目マスタリスト作成.
	 * */
	public List<S00MItem> getItems(String key) {
		if (this.itemList == null) {
			this.itemList = new HashMap<String, List<S00MItem>>();
			for (S00MItem item : itemMasterSerive.selectAll()) {
				if (this.itemList.get(item.itemType) == null) {
					this.itemList.put(item.itemType, new ArrayList<S00MItem>());
				}
				this.itemList.get(item.itemType).add(item);
			}
		}
		return this.itemList.get(key);
	}

	/**
	 * 項目名称取得.
	 * */
	protected String getItemName(String key) {
		String[] keys = key.split("-");
		for (S00MItem item : getItems(keys[0])) {
			if (item.itemVal.equals(key)) {
				return item.itemTxt;
			}
		}
		return "";
	}

}
