package jp.co.afroci.common.domain.custom;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

import jp.co.afroci.common.domain.entity.S00MRoleGrp;
import jp.co.afroci.common.dto.RolesInfoDto;

/**
 * @author Afroci Co., Ltd.
 */
@Dao
@ConfigAutowireable
public interface CustomS00MRoleGrpDao {

    /**
     * @return the S00MRoleGrp entity
     */
    @Select
    List<S00MRoleGrp> selectAll(String roleGrpId);

    /**
     * @return the S00MRoleGrp entity
     */
    @Select
    List<RolesInfoDto> selectViewAll(String roleGrpId);

}