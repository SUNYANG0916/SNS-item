package jp.co.afroci.common.domain.entity;

import java.time.LocalDateTime;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.Table;
import lombok.Data;

/**
 * 取引先マスタ
 * @author Afroci Co., Ltd.
 */
@Data
@Entity
@Table(name = "s10_m_suppliers")
public class S10MSuppliers {

    /** 取引先コード */
    @Id
    @Column(name = "suppliers_no")
    public String suppliersNo;

    /** 取引先名 */
    @Column(name = "suppliers_name")
    public String suppliersName;

    /** 取引開始日 */
    @Column(name = "start_date")
    public String startDate;

    /** 取引終了日 */
    @Column(name = "end_date")
    public String endDate;

    /** 代表者 */
    @Column(name = "pepresentative")
    public String pepresentative;

    /** 郵便番号 */
    @Column(name = "postal_code")
    public String postalCode;

    /** 住所（都道府県） */
    @Column(name = "address_1")
    public String address1;

    /** 住所（市区町村） */
    @Column(name = "address_2")
    public String address2;

    /** 住所（番地以降） */
    @Column(name = "address_3")
    public String address3;

    /** ビル名／部屋 */
    @Column(name = "address_4")
    public String address4;

    /** 最寄り駅 */
    @Column(name = "station")
    public String station;

    /** 電話 */
    @Column(name = "tel")
    public String tel;

    /** 代表Fax */
    @Column(name = "fax")
    public String fax;

    /** 代表メール */
    @Column(name = "mail")
    public String mail;

    /** 受発注送付先 */
    @Column(name = "zyuhacchu_souhusaki")
    public String zyuhacchuSouhusaki;

    /** 総務担当者名 */
    @Column(name = "somu_staff_name")
    public String somuStaffName;

    /** 総務担当電話 */
    @Column(name = "somu_staff_tel")
    public String somuStaffTel;

    /** 総務担当メール */
    @Column(name = "somu_staff_mail")
    public String somuStaffMail;

    /** 営業担当者名 */
    @Column(name = "sales_staff_name")
    public String salesStaffName;

    /** 営業担当電話 */
    @Column(name = "sales_staff_tel")
    public String salesStaffTel;

    /** 営業担当メール */
    @Column(name = "sales_staff_mail")
    public String salesStaffMail;

    /** 銀行コード */
    @Column(name = "ginko_cd")
    public String ginkoCd;

    /** 銀行名 */
    @Column(name = "ginko_mei")
    public String ginkoMei;

    /** 支店番号 */
    @Column(name = "shiten_no")
    public String shitenNo;

    /** 支店名 */
    @Column(name = "shiten_mei")
    public String shitenMei;

    /** 口座区分 */
    @Column(name = "kouza_type")
    public String kouzaType;

    /** 口座名 */
    @Column(name = "kouza_mei")
    public String kouzaMei;

    /** 口座番号 */
    @Column(name = "kouza_no")
    public String kouzaNo;

    /** 取引状態 */
    @Column(name = "suppliers_status")
    public String suppliersStatus;

    /** ソート */
    @Column(name = "sort")
    public Integer sort;

    /** 削除フラグ */
    @Column(name = "delete_flg")
    public String deleteFlg;

    /** 作成者 */
    @Column(name = "create_user")
    public String createUser;

    /** 作成日時 */
    @Column(name = "create_date")
    public LocalDateTime createDate;

    /** 更新カウンタ */
    @Column(name = "update_cnt")
    public Integer updateCnt;

    /** 更新者 */
    @Column(name = "update_user")
    public String updateUser;

    /** 更新日時 */
    @Column(name = "update_date")
    public LocalDateTime updateDate;
}