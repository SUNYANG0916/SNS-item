select
  trim(to_char(max(to_number(item_cd, '000')) + 1, '000')) as item_cd
from
  s00_m_item
where
  item_type = /*itemType*/''
