select
  /*%expand*/*
from
  s11_t_reviews_sent
where
  msg_id < /*msgId*/0 order by msg_id desc limit /*num*/20