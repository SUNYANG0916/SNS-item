select
  /*%expand*/*
from
  s10_m_pj_results
where
  pj_cd = /* pjCd */'a'
  and
  row_number = /* rowNumber */1
