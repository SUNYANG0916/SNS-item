select
  /*%expand*/*
from
  s10_t_emp_carrier_skill
where
  delete_flg = '0'
order by kaisi_ym desc,syuryo_ym desc