select nextval('s10_t_emp_educ_seq')
