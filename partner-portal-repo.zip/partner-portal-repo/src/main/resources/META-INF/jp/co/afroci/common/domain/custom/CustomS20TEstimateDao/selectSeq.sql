select nextval('s20_t_estimate_seq')
