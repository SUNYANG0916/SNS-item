select b.user_cd as userCd, a.item_val as itemVal, a.item_txt as itemText, case when b.program_gengo_cd is not null then '〇' else '' end as selItemVal
  from s00_m_item a
  left join (select user_cd, regexp_split_to_table(program_gengo_cd, '\|') as program_gengo_cd from s10_t_emp_carrier_skill) b
    on a.item_val = b.program_gengo_cd
   and b.user_cd = /* userCd */'a'
 where a.item_type = '30003'
   and a.item_txt <> '該当なし'
 order by a.item_val