select
  /*%expand*/*
from
  t_contact
where
  contact_seq = /* contactSeq */'a'
