select
  /*%expand*/*
from
  s10_t_emp_profile
where
  user_cd = /* userCd */'a'
