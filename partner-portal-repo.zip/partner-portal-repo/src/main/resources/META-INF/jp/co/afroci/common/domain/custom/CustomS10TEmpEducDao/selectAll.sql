select
  /*%expand*/*
from
  s10_t_emp_educ
where
  delete_flg = '0'
