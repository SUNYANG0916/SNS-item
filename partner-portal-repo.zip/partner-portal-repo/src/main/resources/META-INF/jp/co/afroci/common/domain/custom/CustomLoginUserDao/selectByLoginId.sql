select
  /*%expand*/*
from
  s00_m_user
where
  login_id = /* loginId */'a'
