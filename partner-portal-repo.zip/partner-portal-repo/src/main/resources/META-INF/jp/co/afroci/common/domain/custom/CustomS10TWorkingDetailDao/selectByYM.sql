select
  a.pj_cd as pjCd,
  b.pj_nm as pjNm,
  a.working_month as workingMonth,
  a.working_times as workingTimes,
  a.cost_amount as costAmount,
  a.unit_amount as unitAmount,
  a.note as note
from
  s10_t_working_detail a
left join
  s10_m_pj b
on
  b.pj_cd = a.pj_cd
where
  a.user_cd = /* userCd */'a'
  and
  a.working_month = /* workingMonth */'smith'
