select
  /*%expand*/*
from
  s10_m_question
where
  question_id = /* questionId */'a'
