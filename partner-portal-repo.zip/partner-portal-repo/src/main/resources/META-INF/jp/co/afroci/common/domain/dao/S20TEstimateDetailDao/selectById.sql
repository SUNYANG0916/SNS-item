select
  /*%expand*/*
from
  s20_t_estimate_detail
where
  estimate_no = /* estimateNo */'a'
  and
  row_number = /* rowNumber */1
