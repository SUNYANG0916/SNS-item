select
  b.role_id, c.role_nm
from
  s00_m_user_roles a
inner join
  s00_m_role_grp b
on
  a.role_grp_id = b.role_grp_id
left join
  s00_m_roles c
on
  c.role_id = b.role_id
where
  a.user_cd = /* userCd */'a'
