select
  /*%expand*/*
from
  s10_m_suppliers
where
  (suppliers_name like /* conditions */'hoge' escape '$'
   or
   suppliers_no like /* conditions */'hoge' escape '$')

/*%if deleteFlag != null */
and
  delete_flg = /* deleteFlag */'0'
/*%end*/

