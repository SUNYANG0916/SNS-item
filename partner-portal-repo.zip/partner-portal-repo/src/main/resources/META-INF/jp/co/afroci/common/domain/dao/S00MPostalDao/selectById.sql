select
  /*%expand*/*
from
  s00_m_postal
where
  no = /* no */1
