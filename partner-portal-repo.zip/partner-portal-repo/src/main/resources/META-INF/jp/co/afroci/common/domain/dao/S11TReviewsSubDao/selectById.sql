select
  /*%expand*/*
from
  s11_t_reviews_sub
where
  id = /* id */1
