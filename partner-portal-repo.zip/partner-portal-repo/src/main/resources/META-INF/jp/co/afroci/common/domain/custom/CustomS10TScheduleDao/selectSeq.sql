select nextval('s10_t_schedule_id_seq')
