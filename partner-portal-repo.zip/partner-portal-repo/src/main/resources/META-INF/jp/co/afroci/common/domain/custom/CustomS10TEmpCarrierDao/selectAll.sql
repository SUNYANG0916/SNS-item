select
  /*%expand*/*
from
  s10_t_emp_carrier
where
  delete_flg = '0'
