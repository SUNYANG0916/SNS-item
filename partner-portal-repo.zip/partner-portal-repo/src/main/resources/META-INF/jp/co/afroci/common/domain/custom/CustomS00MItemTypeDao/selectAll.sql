select
  /*%expand*/*
from
  s00_m_item_type
where
  delete_flg = '0'
