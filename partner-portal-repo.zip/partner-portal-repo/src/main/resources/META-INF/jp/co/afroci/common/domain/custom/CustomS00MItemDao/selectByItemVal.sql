select
  /*%expand*/*
from
  s00_m_item
where
  item_val = /*itemVal*/''
