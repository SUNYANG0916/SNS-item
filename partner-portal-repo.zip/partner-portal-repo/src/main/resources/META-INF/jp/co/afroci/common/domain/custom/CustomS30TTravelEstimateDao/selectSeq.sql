select nextval('s30_t_travel_seq')
