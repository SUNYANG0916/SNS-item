select
  /*%expand*/*
from
  s10_m_question_choices
where
  question_id = /* questionId */'a'
  and
  details_no = /* detailsNo */1
  and
  choices_code = /* choicesCode */1
