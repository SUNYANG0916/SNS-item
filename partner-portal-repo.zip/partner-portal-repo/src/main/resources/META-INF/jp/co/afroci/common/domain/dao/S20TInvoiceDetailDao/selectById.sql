select
  /*%expand*/*
from
  s20_t_invoice_detail
where
  invoice_no = /* invoiceNo */'a'
  and
  row_number = /* rowNumber */1
