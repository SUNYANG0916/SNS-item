select
  /*%expand*/*
from
  s20_t_invoice_detail
where
  invoice_no = /* invoiceNo */'hoge'


