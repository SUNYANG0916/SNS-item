select
  /*%expand*/*
from
  s10_t_schedule_detail
where
  sequence = /* sequence */'0'
  order by start_time