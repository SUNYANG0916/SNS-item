select
  /*%expand*/*
from
  s10_t_schedule
where
  sequence = /* sequence */1
  and
  user_cd = /* userCd */'a'
