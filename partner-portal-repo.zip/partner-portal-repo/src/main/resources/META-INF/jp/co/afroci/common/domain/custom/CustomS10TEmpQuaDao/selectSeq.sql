select nextval('s10_t_emp_qua_seq')
