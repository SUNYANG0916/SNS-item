select nextval('s11_t_reviews_sub_id_seq')
