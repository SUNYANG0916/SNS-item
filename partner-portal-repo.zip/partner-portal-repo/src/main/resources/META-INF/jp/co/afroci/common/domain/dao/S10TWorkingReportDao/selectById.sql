select
  /*%expand*/*
from
  s10_t_working_report
where
  user_cd = /* userCd */'a'
  and
  working_date = /* workingDate */'a'
