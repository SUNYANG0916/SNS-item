select
  b.role_id as roleId
, b.role_nm as roleNm
from
 s00_m_role_grp a
left join
 s00_m_roles b
on
 b.role_id = a.role_id
left join
 s00_m_item c
on
 c.item_val = b.role_grp_id
where
 a.role_grp_id = /* roleRrpId */''