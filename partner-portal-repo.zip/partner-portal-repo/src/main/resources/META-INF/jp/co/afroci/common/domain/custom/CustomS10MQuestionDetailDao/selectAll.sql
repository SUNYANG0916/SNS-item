select
  /*%expand*/*
from
  s10_m_question_detail
where
  question_id = /* questionId */'a'
and
  delete_flg = '0'
order by details_no