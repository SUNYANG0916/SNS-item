select
  /*%expand*/*
from
  s10_m_question_detail
where
  question_id = /* questionId */'a'
  and
  details_no = /* detailsNo */1
