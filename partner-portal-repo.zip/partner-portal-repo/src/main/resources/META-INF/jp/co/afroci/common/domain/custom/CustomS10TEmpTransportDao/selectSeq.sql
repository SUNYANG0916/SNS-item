select nextval('s10_t_emp_transport_id_seq')
