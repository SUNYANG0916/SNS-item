select
  /*%expand*/*
from
  s11_t_company_anken
where
  user_cd = /* userCd */'a'
  and
  company_id = /* companyId */1
  and
  business_id = /* businessId */1
