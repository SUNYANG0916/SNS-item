select
  /*%expand*/*
from
  s10_m_suppliers
where
  suppliers_no = /* suppliersNo */'a'
