select
  /*%expand*/*
from
  s11_t_reviews_sub
where
  msg_id = /* msgId */-1  order by id