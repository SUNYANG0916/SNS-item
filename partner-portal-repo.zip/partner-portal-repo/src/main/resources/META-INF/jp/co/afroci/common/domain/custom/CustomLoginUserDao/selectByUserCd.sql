select
  /*%expand*/*
from
  s00_m_user
where
  user_cd = /* userCd */'a'
