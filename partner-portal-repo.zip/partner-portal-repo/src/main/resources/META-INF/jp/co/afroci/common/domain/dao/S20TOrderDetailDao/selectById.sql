select
  /*%expand*/*
from
  s20_t_order_detail
where
  order_no = /* orderNo */'a'
  and
  row_number = /* rowNumber */1
