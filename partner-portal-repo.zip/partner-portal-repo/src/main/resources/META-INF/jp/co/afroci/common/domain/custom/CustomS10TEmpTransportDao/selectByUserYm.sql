select
  /*%expand*/*
from
  s10_t_emp_transport
where
  user_cd = /* userCd */'a'
  and
  trans_ym = /* transYm */'a'
  and
  delete_flg = '0'
