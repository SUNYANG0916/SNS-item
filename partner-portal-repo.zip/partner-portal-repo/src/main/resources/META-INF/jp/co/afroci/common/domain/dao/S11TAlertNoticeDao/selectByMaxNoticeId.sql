select
  /*%expand*/*
from
  s11_t_alert_notice
where
  notice_id = (select max(notice_id) from s11_t_alert_notice)