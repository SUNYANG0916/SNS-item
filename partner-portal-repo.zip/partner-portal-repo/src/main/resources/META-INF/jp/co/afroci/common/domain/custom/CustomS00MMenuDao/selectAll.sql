select
 c.menu_id,
 c.menu_nm,
 c.menu_type,
 c.apply_id
from
 s00_m_user_roles a
left join
 s00_m_role_grp b
on b.role_grp_id = a.role_grp_id

left join
 s00_m_menu c
on
 c.apply_id = SPLIT_PART(b.role_id ,'_', 1)
or
 b.role_id = 'all'

where
 a.user_cd = /* userCd */'a'
and
 c.menu_type = /* menuType */'0'
and
 a.delete_flg = '0'
and
 c.delete_flg = '0'
group by
 c.menu_id,
 c.menu_nm,
 c.menu_type,
 c.apply_id,
 a.sort
order by
 a.sort

