select
  /*%expand*/*
from
  s20_t_estimate
where
  (suppliers_from_name like /* conditions */'hoge' escape '$'
   or
   suppliers_to_name like /* conditions */'hoge' escape '$'
   or
   estimate_no like /* conditions */'hoge' escape '$'
   or
   matter_name like /* conditions */'hoge' escape '$'
   )
  /*%if deleteFlag != null */
  and
  delete_flg = /* deleteFlag */'0'
  /*%end*/


