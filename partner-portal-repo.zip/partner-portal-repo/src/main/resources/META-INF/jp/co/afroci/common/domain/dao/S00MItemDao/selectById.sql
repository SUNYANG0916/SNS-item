select
  /*%expand*/*
from
  s00_m_item
where
  item_type = /* itemType */'a'
  and
  item_cd = /* itemCd */'a'
