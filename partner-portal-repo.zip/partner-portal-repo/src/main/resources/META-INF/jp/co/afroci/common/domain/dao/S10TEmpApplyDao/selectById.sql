select
  /*%expand*/*
from
  s10_t_emp_apply
where
  user_cd = /* userCd */'a'
  and
  occur_ym = /* occurYm */'a'
  and
  sequence = /* sequence */1
