select
  a.*
from
  s00_m_user a
inner join
  s10_t_emp_profile b
on
  a.user_cd = b.user_cd
and
  b.nyusya_ymd = to_date(/*nyusyaYmd*/'', 'yyyy-mm-dd')
and
  UPPER(b.eiji_sei) = /*eijiSei*/''
and
  UPPER(b.eiji_mei) = /*eijiMei*/''
where
  a.delete_flg = '0'
