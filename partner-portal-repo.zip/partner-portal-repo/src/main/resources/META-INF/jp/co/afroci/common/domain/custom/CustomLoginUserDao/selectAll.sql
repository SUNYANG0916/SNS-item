select
  /*%expand*/*
from
  s00_m_user
where
  delete_flg = '0'

/*%if conditions != null */
and
  (login_id like /* conditions */'hoge'
   or
   login_user_name like /* conditions */'hoge'
  )
/*%end*/

order by login_id