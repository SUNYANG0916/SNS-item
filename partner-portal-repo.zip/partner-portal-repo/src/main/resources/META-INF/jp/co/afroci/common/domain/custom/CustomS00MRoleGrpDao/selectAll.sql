select
  /*%expand*/*
from
  s00_m_role_grp
where
  role_grp_id = /* roleGrpId */'a'
and
  delete_flg = '0'
