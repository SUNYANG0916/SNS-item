select
  /*%expand*/*
from
  s11_t_reviews_sent
where
  order by count desc limit /*num*/20