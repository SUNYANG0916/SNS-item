select
  /*%expand*/*
from
  s20_t_order_detail
where
  order_no = /* orderNo */'hoge'


