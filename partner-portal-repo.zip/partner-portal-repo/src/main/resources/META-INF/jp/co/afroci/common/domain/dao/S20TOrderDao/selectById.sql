select
  /*%expand*/*
from
  s20_t_order
where
  order_no = /* orderNo */'a'
