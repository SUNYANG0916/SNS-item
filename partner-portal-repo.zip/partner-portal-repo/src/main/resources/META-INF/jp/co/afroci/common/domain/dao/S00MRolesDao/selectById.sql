select
  /*%expand*/*
from
  s00_m_roles
where
  role_id = /* roleId */'a'
