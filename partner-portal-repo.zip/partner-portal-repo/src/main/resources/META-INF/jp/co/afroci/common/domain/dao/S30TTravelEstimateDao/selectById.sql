select
  /*%expand*/*
from
  s30_t_travel_estimate
where
  travel_no = /* travelNo */'a'
