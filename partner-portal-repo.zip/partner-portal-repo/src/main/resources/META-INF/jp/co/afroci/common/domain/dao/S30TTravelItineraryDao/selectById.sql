select
  /*%expand*/*
from
  s30_t_travel_itinerary
where
  travel_no = /* travelNo */'a'
  and
  row_number = /* rowNumber */1
