select
  /*%expand*/*
from
  s20_t_estimate
where
  estimate_no = /* estimateNo */'a'
