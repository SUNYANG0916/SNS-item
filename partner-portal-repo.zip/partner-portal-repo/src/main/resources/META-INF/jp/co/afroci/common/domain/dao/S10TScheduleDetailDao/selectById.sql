select
  /*%expand*/*
from
  s10_t_schedule_detail
where
  sequence = /* sequence */1
  and
  row_no = /* rowNo */1
