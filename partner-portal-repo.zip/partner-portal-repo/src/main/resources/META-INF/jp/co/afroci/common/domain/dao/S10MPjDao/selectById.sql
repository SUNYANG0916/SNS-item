select
  /*%expand*/*
from
  s10_m_pj
where
  pj_cd = /* pjCd */'a'
