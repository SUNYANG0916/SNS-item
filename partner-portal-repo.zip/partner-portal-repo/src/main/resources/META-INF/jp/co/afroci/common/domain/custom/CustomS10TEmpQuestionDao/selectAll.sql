select
  /*%expand*/*
from
  s10_t_emp_question
where
  user_cd = /* userCd */'a'
  and
  question_id = /* questionId */'a'
  and
  to_char(last_ts, 'YYYYMM') = to_char(CURRENT_DATE, 'YYYYMM')
