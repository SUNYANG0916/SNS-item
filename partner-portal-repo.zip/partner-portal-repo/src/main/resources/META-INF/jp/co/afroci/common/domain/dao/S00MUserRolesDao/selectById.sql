select
  /*%expand*/*
from
  s00_m_user_roles
where
  user_cd = /* userCd */'a'
  and
  role_grp_id = /* roleGrpId */'a'
