select
  /*%expand*/*
from
  s10_m_question
where
  delete_flg = '0'
order by
  sort_no, question_id