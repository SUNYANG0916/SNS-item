select
  /*%expand*/*
from
  s00_m_user_roles
where
  user_cd = /* userCd */'a'
and
  delete_flg = '0'
