select
 a.user_cd as userCd,
 a.login_id as loginId,
 a.login_user_name as loginUserName,
 substr(b.eiji_sei, 1, 1) || '.' || substr(b.eiji_mei, 1, 1) as userInitial,
 a.busyo_cd as busyoCd,
 a.password,
 case when b.user_cd is null then '0' else '1' end as dispDetail1,
 case when count(c.user_cd) = 0 then '0' else '1' end as dispDetail2,
 case when count(d.user_cd) = 0 then '0' else '1' end as dispDetail3,
 case when count(e.user_cd) = 0 then '0' else '1' end as dispDetail4,
 case when count(f.user_cd) = 0 then '0' else '1' end as dispDetail5,
 case when count(f.user_cd) = 0 then '0' else '1' end as dispDetail6,
 '1' as dispDetail7,
 '1' as dispDetail8
 from
  s00_m_user a
left join s10_t_emp_profile b
  on b.user_cd = a.user_cd
 and b.delete_flg = '0'
left join s10_t_emp_educ c
  on c.user_cd = a.user_cd
 and c.delete_flg = '0'
left join s10_t_emp_qua d
  on d.user_cd = a.user_cd
 and d.delete_flg = '0'
left join s10_t_emp_carrier e
  on e.user_cd = a.user_cd
 and e.delete_flg = '0'
left join s10_t_emp_carrier_skill f
  on f.user_cd = a.user_cd
 and f.delete_flg = '0'

where
  a.delete_flg = '0'

/*%if conditions != null */
 and
  (a.login_id like /* conditions */'hoge'
   or
   a.login_user_name like /* conditions */'hoge'
  )
/*%end*/
group by a.user_cd
     , a.login_id
     , a.busyo_cd
     , a.login_user_name
     , a.password
     , b.user_cd
     , b.eiji_sei
     , b.eiji_mei
order by a.login_id
