select
  a.role_id as roleId
, b.role_nm as roleNm
, a.role_grp_id as roleGrpId
, c.item_txt as roleGrpNm
from
 s00_m_role_grp a
left join
 s00_m_roles b
on
 b.role_id = a.role_id
left join
 s00_m_item c
on
 c.item_val = a.role_grp_id
where
 1 = 1
/*%if roleGrpId != null */
 and a.role_grp_id = /* roleGrpId */''
/*%end*/
order by
 a.role_grp_id, a.sort

