select
  a.sequence
  , a.user_cd as userCd
  , a.user_name as userName
  , a.schedule_date as scheduleDate
  , b.row_no as rowNo
  , b.start_time as startTime
  , b.end_time as endTime
  , b.schedule_title as scheduleTitle
  , b.schedule_text as scheduleText
from
  s10_t_schedule a
left join s10_t_schedule_detail b
  on a.sequence = b.sequence
where
  substring(a.schedule_date, 1, 7) = /* scheduleYm */'a'
  and
  a.delete_flg = '0'
  and
  (a.user_cd like /* searchConditions */'hoge' escape '$'
   or
   a.user_name like /* searchConditions */'hoge' escape '$'
  )
  order by a.schedule_date, b.start_time