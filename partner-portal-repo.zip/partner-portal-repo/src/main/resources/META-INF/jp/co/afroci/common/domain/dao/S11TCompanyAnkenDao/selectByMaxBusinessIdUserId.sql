select
  /*%expand*/*
from
  s11_t_company_anken
where
  user_cd = /* userCd */1
and
  business_id = (select max(business_id) from s11_t_company_anken where user_cd = /* userCd */1)