select
  /*%expand*/*
from
  s20_t_invoice
where
  invoice_no = /* invoiceNo */'a'
