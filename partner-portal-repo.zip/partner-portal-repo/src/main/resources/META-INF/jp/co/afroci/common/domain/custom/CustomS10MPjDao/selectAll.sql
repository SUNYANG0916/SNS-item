select
  /*%expand*/*
from
  s10_m_pj
where
  (pj_nm like /* conditions */'hoge' escape '$'
   or
   pj_cd like /* conditions */'hoge' escape '$')
/*%if deleteFlag != null */
and
   delete_flg = /* deleteFlag */'0'
/*%end*/
