select
  /*%expand*/*
from
  s11_t_reviews_sent
where
  msg_id = /* msgId */1
