select nextval('s10_t_emp_carrier_seq')
