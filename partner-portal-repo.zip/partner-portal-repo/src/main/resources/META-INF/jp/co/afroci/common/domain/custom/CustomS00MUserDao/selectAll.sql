select
  /*%expand*/*
from
  s00_m_user
where
  delete_flg = '0'
