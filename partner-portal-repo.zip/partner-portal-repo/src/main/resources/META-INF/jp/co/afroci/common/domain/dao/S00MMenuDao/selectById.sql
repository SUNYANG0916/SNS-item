select
  /*%expand*/*
from
  s00_m_menu
where
  menu_id = /* menuId */'a'
