select nextval('s10_m_pj_seq')
