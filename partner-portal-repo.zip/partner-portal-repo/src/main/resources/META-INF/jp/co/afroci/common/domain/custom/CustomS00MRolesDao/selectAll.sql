select
  /*%expand*/*
from
 s00_m_roles
where
  (role_id like /* conditions */'hoge' escape '$'
   or
   role_nm like /* conditions */'hoge' escape '$')
/*%if deleteFlag != null */
and
   delete_flg = /* deleteFlag */'0'
/*%end*/
