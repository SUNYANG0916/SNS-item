select
  a.role_id as roleId
, a.role_nm as roleNm
, b.role_grp_id as roleGrpId
, c.item_txt as roleGrpNm
, d.item_txt as roleTypeNm
from
 s00_m_roles a
left join
 s00_m_role_grp b
on
 b.role_id = a.role_id
left join
 s00_m_item c
on
 c.item_val = b.role_grp_id
left join
 s00_m_item d
on
 d.item_val = a.role_type
