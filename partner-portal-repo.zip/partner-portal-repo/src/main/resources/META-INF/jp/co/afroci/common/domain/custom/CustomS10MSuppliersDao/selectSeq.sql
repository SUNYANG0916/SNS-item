select nextval('s10_m_suppliers_seq')
