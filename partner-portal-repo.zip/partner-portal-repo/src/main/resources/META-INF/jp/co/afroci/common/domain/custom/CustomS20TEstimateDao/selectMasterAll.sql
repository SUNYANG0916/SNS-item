select
  a.estimate_no as estimateNo
, a.matter_name as estimateName
, a.suppliers_to_no as suppliersToNo
, a.suppliers_to_name as suppliersToName
, a.suppliers_from_no as suppliersFromNo
, a.suppliers_from_name as suppliersFromName
, b.postal_Code as postalCode
, b.address_1 as address1
, b.address_2 as address2
, b.address_3 as address3
, b.address_4 as address4
, b.tel
, b.fax
, b.ginko_Cd as ginkoCd
, b.ginko_Mei as ginkoMei
, b.shiten_No as shitenNo
, b.shiten_Mei as shitenMei
, b.kouza_Type as kouzaType
, b.kouza_Mei as kouzaMei
, b.kouza_No as kouzaNo
, b.pepresentative as pepresentative
, a.period_S as startDate
, a.period_E as endDate


from
  s20_t_estimate a
left join
  s10_m_suppliers b
on
  b.suppliers_no = a.suppliers_from_no
where
  (a.suppliers_from_name like /* conditions */'hoge' escape '$'
   or
   a.suppliers_to_name like /* conditions */'hoge' escape '$'
   or
   a.estimate_no like /* conditions */'hoge' escape '$'
   or
   a.matter_name like /* conditions */'hoge' escape '$'
   )
  /*%if deleteFlag != null */
  and
  a.delete_flg = /* deleteFlag */'0'
  /*%end*/


