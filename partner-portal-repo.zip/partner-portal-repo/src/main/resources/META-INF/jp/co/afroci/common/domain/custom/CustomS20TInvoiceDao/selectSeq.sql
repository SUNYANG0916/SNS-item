select nextval('s20_t_invoice_seq')
