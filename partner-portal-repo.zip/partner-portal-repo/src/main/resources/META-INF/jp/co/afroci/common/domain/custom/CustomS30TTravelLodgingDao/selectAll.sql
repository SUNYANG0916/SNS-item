select
  /*%expand*/*
from
  s30_t_travel_lodging
where
   travel_no like /* travelNo */'hoge' escape '$'
  /*%if deleteFlag != null */
  and
  delete_flg = /* deleteFlag */'0'
  /*%end*/


