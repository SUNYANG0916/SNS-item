select 
msg_id,user_cd 
from 
s11_t_reviews_sub 
where 
msg_id=/*msgId*/-1 
group by 
msg_id,user_cd