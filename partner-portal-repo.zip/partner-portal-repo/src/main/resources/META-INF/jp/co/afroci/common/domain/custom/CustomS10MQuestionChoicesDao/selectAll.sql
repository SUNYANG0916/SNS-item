select
  /*%expand*/*
from
  s10_m_question_choices
where
  question_id = /* questionId */'a'
and
  details_no = /* detailsNo */0
and
  delete_flg = '0'
order by details_no, choices_code