select
  s10_m_question.question_id
from
  s10_m_question
left join s10_m_question_detail
  on s10_m_question_detail.question_id = s10_m_question.question_id
where
  s10_m_question.question_id = /* questionId */'a'
