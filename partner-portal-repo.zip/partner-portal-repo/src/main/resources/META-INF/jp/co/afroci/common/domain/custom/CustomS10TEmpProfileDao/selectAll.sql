select
  /*%expand*/*
from
  s10_t_emp_profile
where
  delete_flg = '0'
