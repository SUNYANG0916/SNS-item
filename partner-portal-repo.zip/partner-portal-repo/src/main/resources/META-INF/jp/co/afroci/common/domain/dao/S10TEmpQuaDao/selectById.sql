select
  /*%expand*/*
from
  s10_t_emp_qua
where
  user_cd = /* userCd */'a'
  and
  sequence = /* sequence */1
