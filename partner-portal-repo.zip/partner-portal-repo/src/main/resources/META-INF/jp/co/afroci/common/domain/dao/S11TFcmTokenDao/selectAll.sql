select
  /*%expand*/*
from
  s11_t_fcm_token