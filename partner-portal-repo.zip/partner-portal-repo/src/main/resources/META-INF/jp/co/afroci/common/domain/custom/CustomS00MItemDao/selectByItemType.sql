select
  /*%expand*/*
from
  s00_m_item
where
  item_type = /*itemType*/''
/*%if deleteFlg != null */
and
  delete_flg = /*deleteFlg*/''
/*%end*/
order by
  item_sort
