select
  /*%expand*/*
from
  s10_t_emp_qua
where
  delete_flg = '0'
