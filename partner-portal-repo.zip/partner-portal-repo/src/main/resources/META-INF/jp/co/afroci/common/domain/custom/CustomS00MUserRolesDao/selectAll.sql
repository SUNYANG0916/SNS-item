select
  /*%expand*/*
from
  s00_m_user_roles
where
  delete_flg = '0'
