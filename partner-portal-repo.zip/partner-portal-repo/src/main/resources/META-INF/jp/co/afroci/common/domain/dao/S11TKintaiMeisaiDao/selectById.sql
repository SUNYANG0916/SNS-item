select
  /*%expand*/*
from
  s11_t_kintai_meisai
where
  user_cd = /* userCd */'a'
  and
  kintai_date = /* kintaiDate */'a'
