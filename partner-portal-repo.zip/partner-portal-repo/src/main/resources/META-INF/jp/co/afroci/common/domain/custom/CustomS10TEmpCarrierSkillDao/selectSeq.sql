select nextval('s10_t_emp_carrier_skill_seq')
