select
  /*%expand*/*
from
  s20_t_emp_transport
where
  user_cd = /* userCd */'a'
  and
  trans_ym = /* transYm */'a'
  and
  details_no = /* detailsNo */1
