select
  /*%expand*/*
from
  s00_m_item
where
  delete_flg = '0'
order by
  item_type, item_sort
