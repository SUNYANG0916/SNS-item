select
  /*%expand*/*
from
  s00_m_item_type
where
  item_type = /* itemType */'a'
