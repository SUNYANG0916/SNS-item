select
  /*%expand*/*
from
  s10_t_working_detail
where
  user_cd = /* userCd */'a'
  and
  pj_cd = /* pjCd */'a'
  and
  working_month = /* workingMonth */'a'
