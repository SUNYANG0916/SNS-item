select
  /*%expand*/*
from
  s10_t_emp_question
where
  user_cd = /* userCd */'a'
  and
  question_id = /* questionId */'a'
  and
  details_no = /* detailsNo */1
