select
  /*%expand*/*
from
  s30_t_travel_estimate
where
  (suppliers_from_name like /* conditions */'hoge' escape '$'
   or
   suppliers_to_name like /* conditions */'hoge' escape '$'
   or
   travel_no like /* conditions */'hoge' escape '$'
   or
   course_name like /* conditions */'hoge' escape '$'
   )
  /*%if deleteFlag != null */
  and
  delete_flg = /* deleteFlag */'0'
  /*%end*/


