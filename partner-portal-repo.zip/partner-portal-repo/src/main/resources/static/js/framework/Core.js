//document.write("<script type='text/javascript' src='/js/autosize.min.js'></script>");

// 共通（S_ComUtil）
var S_ComUtil = function() {
    if ((this instanceof S_ComUtil) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    this._objs = {};
    this.localeId = "ja";
    var ua = window.navigator.userAgent.toLowerCase();
    this.clientType = "pc";
    if ((ua.indexOf('iphone') > -1) || (ua.indexOf('ipad') > -1) || (ua.indexOf('android') > -1)) {
    	this.clientType = "sp";
    }
};

S_ComUtil.prototype.isEmpty = function(obj) {
    return (obj == undefined || obj === "" || obj == null);
};

S_ComUtil.prototype.isNotEmpty = function(obj) {
    return !this.isEmpty(obj);
};

S_ComUtil.prototype.add_els = function (p, els) {
    if (typeof(p) == "string") p = document.getElementById(p);
    if (els == undefined) return;
    var result = [];
    for (var i = 0; i < els.length; i++) {
        var el = els[i];
        var addEl = this.add_el(p, el);
        result[result.length] = addEl;
        // 子エレメントが存在する場合、再帰処理
        if (el.elems) this.add_els(addEl, el.elems);
    }
    return result;
};

S_ComUtil.prototype.add_el = function(p, obj) {
    var el = $("<" + obj.tag + ">").trigger("create")[0];
    // タグ生成、およびname属性設定
    var name = (obj.name == undefined) ? "" : obj.name;
    if (name != "") el.name = name;
    // テキストエリアの場合、縦サイズ自動調整
    if (obj.tag == "textarea") autosize($(el));
    // SELECTの場合、リスト候補を追加
    else if (obj.tag == "select") $s.sel.add(el, $s._objs[obj.name]);
    // テーブルの場合、オブジェクト定義保持
    else if (obj.tag == "table" || obj.tag == "ul" && this.isNotEmpty(obj.list_id)) $s._objs[obj.list_id] = obj;
    // 属性追加したエレメントをBODYへ追加
    if (p == undefined) {
        $(body).append(this.attribute(el, obj)).trigger("create");
    } else {
        $(p).append(this.attribute(el, obj)).trigger("create");
    }
    return el;
};

S_ComUtil.prototype.attribute = function(el, obj) {
    for (var key in obj){
        // タグ、名称、子エレメントを対象外
        if (key=='tag'||key=='name'||key=='elems') continue;
        try {
            if (key == 'text') {
                var text = obj.text;
                // ロケール対応
                if (this.localeId != "" && this.localeId != "ja") text = obj["text_" + this.localeId];
                if (obj.type == "button") el.value = text;
                else el.appendChild(document.createTextNode(text));
            } else if (key == 'style') {
                el.setAttribute(key, obj[key]);
            } else if (key.indexOf('-') > 0 || key == "for" || key == "maxlength") {
                el.setAttribute(key, obj[key]);
            } else if (obj[key]) {
                el[key] = obj[key];
            }
        } catch (e) {
            //設定エラースルー
        }
    }
    return el;
};

S_ComUtil.prototype.view_mode = function(el, exclusion_nm) {
    if (el == undefined) return;
    $(el).find("input").each(function(index,element){
    	if (element.type != "hidden" && element.id != exclusion_nm && element.name != exclusion_nm && element.isReadOnly != "true") {
            if (element.type == "text") {
            	element.readOnly = "readonly";
            } else {
            	element.disabled = true;
            }
    	}
    });
    $(el).find("textarea,select").each(function(index,element){
    	if (element.id != exclusion_nm && element.name != exclusion_nm){
        	$(element).prop("disabled", true);
    	}
    });
    $(el).find(".btn_row_add,.btn_row_del,.afr_upd,.afr_del").each(function(index,element){
    	if (element.id != exclusion_nm && element.name != exclusion_nm && element.isReadOnly != "true") {
    		$(element).css("display","none");
    	}
    });
};

S_ComUtil.prototype.edit_mode = function(el, exclusion_nm) {
    if (el == undefined) return;
    $(el).find("input").each(function(index,element){
    	if (element.type != "hidden" && element.id == exclusion_nm && element.name == exclusion_nm && element.isReadOnly == "true"){
    		if (element.type == "text") {
                taget.readOnly = "";
    		} else {
    			taget.disabled = false;
    		}
    	}
    });
    $(el).find("textarea,select").each(function(index,element){
    	if (element.id != exclusion_nm && element.name != exclusion_nm){
        	$(element).prop("disabled",false);
    	}
    });
    $(el).find(".btn_row_add,.btn_row_del,.afr_upd,.afr_del").each(function(index,element){
    	if (element.id != exclusion_nm && element.name != exclusion_nm && element.isReadOnly != "true") {
        	$(element).css("display","");
    	}
    });
};

S_ComUtil.prototype.get_validate = function(items, form) {
	$.validator.setDefaults({ ignore: '' });
    var data = {rules:{},messages:{}};
    for (var key in items) {
        var els = document.getElementsByName(items[key]);
        for (var i = 0; i < els.length; i++) {
            if (els.length > 1) {
                // 複数エレメントが同じ名称を持つ場合、ID自動付与
                if (els[i].id == undefined ||els[i].id == '') {
                    els[i].id = els[i].name + '_' + i;
                }
            }
            if (els[i].validate) {
            	var validate = JSON.parse(els[i].validate);
                if (validate) {
                    data.rules[els[i].name] = validate.rules;
                    data.messages[els[i].name] = validate.message;
                }
            }
        }
    }
    if (form) {
        data.errorClass = "sa-validation-error";
        data.errorElement="div";
        data.errorPlacement = function(error, element) {
            if (element.is(':radio, :checkbox')) {
                if ($(element).closest("li").length > 0) {
                	if ($(element).closest("td").find(".list_disp").length > 0) {
                		error.appendTo($(element).closest("td").find(".list_disp"));
                	} else {
                    	error.appendTo($(element).closest("ul"));
                	}
                } else {
                    error.appendTo($(element).closest("td"));
                }
            } else {
                error.appendTo($(element).closest("td"));
            }
        };
        $.validator.methods.id = function(value, element) { return true; };
        $.validator.methods.date = function(value, element) { return element.type == "date"; };
        return $(form).validate(data).form();
    }

    return data;
};

S_ComUtil.prototype.set_data = function (el_id, data, isBackGraund) {
    if ($s.com.isEmpty(data)) return;
    var list_obj = $s._objs[el_id];
    if ($s.com.isNotEmpty(list_obj)) {
    // 行クリア
    $s.tbl.clear(list_obj);
    // データごと処理繰り返し
    $.each(data, function(index, record) {
        // 行追加
        var trs = $s.lis.row_add(list_obj);
        // 値設定
        $s.com.set_val($(trs), record);
        // 背景色設定
        if (record.detail_no && isBackGraund == true && record.detail_no % 2 == 0) {
        $(trs).each(function(i, tr){
            $(tr).css('background-color','#F1F4FF');
        });
        }
        // ソート処理
        $("#" + el_id).stupidtable();
    });
    } else {
    // 値設定
    $s.com.set_val([$("#" + el_id)], data);
    }
};

S_ComUtil.prototype.set_val = function(els, data, isTblAdd) {
    if (data == undefined) return;
    for (var key in data) {
        var data_obj = data[key];
    	if (data_obj == null) {
    		continue;
    	}
        if(typeof(data_obj) == "object" && data_obj instanceof Array) {
            var list_el = $s._objs[key];
            if ($s.com.isNotEmpty(list_el)) {
            	if (isTblAdd != true) {
                    // 行クリア
                    $s.lis.clear(list_el);
            	}
                // データごと処理繰り返し
                $.each(data_obj, function(index, record) {
                    // 行追加
                    var trs = $s.lis.add(list_el);
                    var cd = $(trs).find("[for]").attr("for");
                    $(trs).find("#" + cd).attr("id", cd + index);
                    $(trs).find("[for]").attr("for", cd + index);
                    var rowNo = $(trs).find("label[data-db-key=row_no]");
                    if (rowNo) $(rowNo[0]).text(index + 1);
                    // 背景色設定
                    var evenColor = list_el["even_color"];
                    if (evenColor && evenColor != "") {
                        if (index % 2 != 0) {
                            $(trs).each(function(i, tr){
                                $(tr).children().each(function(col_index, col){
                                    $(col).css("background-color", evenColor);
                                });
                            });
                        }
                    }
                    // 値設定
                    $s.com.set_val($(trs), record);
                });
                if ($("#" + list_el.id).attr("data-role") == "listview") {
                    $("#" + list_el.id).listview("refresh");
                }
            }
        } else {
            var el = $(els).find("[data-db-key=" + key + "]");
            if (el == undefined) continue;
            if (el.prop("tagName")=="SELECT") {
                $s.sel.selected(el[0], data_obj);
                try {$(el).selectmenu('refresh',true);}catch{}
            } else if (el.prop("tagName")=="A") {
        		$(el).text(data_obj);
            } else if (el.prop("tagName")=="LABEL") {
            	if (data_obj && data_obj != "") {
                	if ($(el).hasClass("FMT_YYYYMM")) {
                		$(el).text($s.dat.fmt("YYYY年MM月", data_obj));
                	} else if ($(el).hasClass("FMT_YYYYMMDD")) {
                		$(el).text($s.dat.fmt("YYYY/MM/DD", data_obj));
                	} else if ($(el).hasClass("FMT_YMD_VAL")) {
                		$(el).text($s.dat.fmt("YYYY-MM-DD", data_obj));
                	} else if ($(el).hasClass("FMT_MMDD_JA")) {
                    	$(el).text($s.dat.fmt("MM月DD日", data_obj));
                	} else if ($(el).hasClass("FMT_DD")) {
                   		$(el).text($s.dat.fmt("DD(d)", data_obj));
                   		if ($(el).text().indexOf("日") > 0) {
                   			$(el).css("color","red");
                   		} else if ($(el).text().indexOf("土") > 0) {
                   			$(el).css("color","blue ");
                   		} else {
                   			$(el).css("color","black ");
                   		}
                	} else if ($(el).hasClass("FMT_AMOUNT")) {
                		$(el).text("￥" + Number(data_obj).toLocaleString());
                	} else {
                		$(el).text(data_obj);
                	}
            	}
            } else if (el.prop("tagName")=="TEXTAREA") {
                $(el).val(data_obj).text(data_obj);
            } else {
                if($(el).attr('type') == ("radio")) {
                    $(el).each(function(index, e){
                        if (e.value == "on") {
                            e.value = data_obj;
                        } else {
                            if (e.value == data_obj) {
                            	$(e).prop('checked', true).checkboxradio('refresh');
                            	return true;
                            }
                        }
                    });
                } else if ($(el).attr('type') == ("checkbox")) {
                	var tmps = data_obj.split("|");
                	for (var key in tmps) {
                		var tmp = tmps[key];
                        $(el).each(function(index, e){
                            if (e.value == "on") {
                                e.value = tmp;
                            } else {
                                if (e.value == tmp) {
                                	$(e).prop('checked', true).checkboxradio('refresh');
                                	return true;
                                }
                            }
                        });
                	}
                } else {
                    if ($(el).attr('type') == "date") {
                        data_obj = $s.dat.fmt("YYYY-MM-DD", data_obj);
                        $(el).val(data_obj);
                    } else if($(el).attr('type') == ("number")) {
                        $(el).val(data_obj);
                    } else if($(el).attr('type') == ("label")) {
                        $(el).text(data_obj);
                    } else {
                        $(el).val(data_obj);
                    }
                }
            }
        }
    }
};
S_ComUtil.prototype.getSendData = function(result, el) {
	var dbKey = $(el).attr("data-db-key");
	if ($(el).prop("tagName") == "INPUT") {
		if ($(el).attr("type") == "radio") {
			if ($(el).is(':checked')) {
				result[dbKey] = $(el).val();
			}
        } else if ($(el).attr("type") == "checkbox") {
        	if ($(el).is(':checked')) {
            	if (result[dbKey]) {
            		result[dbKey] += "|";
            	} else {
            		result[dbKey] = "";
            	}
            	result[dbKey] += $(el).val();
        	}
        } else {
        	result[dbKey] = $(el).val();
        }
	} else if ($(el).prop("tagName") == "SELECT") {
		result[dbKey] = $(el).val();
	} else if ($(el).prop("tagName") == "TEXTAREA") {
		result[dbKey] = $(el).val();
	} else if ($(el).prop("tagName") == "LABEL") {
		result[dbKey] = $(el).text();
	} else {
		result[dbKey] = $(el).val();
	}
};
S_ComUtil.prototype.ajax = function(_type, fnc, send_data, call_back, _url) {
	if (fnc == "_update" || fnc == "_delete") {
		if ($s.com.ajaxTransFlag == true) {
			return;
		} else {
			$s.com.ajaxTransFlag = true;
		}
	}
	var execUrl = $s.context + "/user/" + $s._objs.applyId + fnc;
	if(_url) {
		execUrl = $s.context + _url;
	}
	var option = {
	     type : _type,
	     url  : execUrl,
	     data : send_data,
	     contentType: 'application/json;charset=UTF-8',
	     dataType:"json"
	};
	if (_type == "POST") {
		option.data = JSON.stringify(send_data);
	}
	$.ajax(option).done(function(data, status, xhr) {
		// 通信成功時の処理
		if (data.msg) {
            setTimeout($s.apply._showPopup({title:"メッセージ", msg:data.msg, type:"ok"}), 100);
        }
    	if (call_back && call_back.done) {
    		call_back.done(data, status, xhr);
    	}
    }).fail(function(xhr, status, error) {
	    // 通信失敗時の処理
		if (xhr.responseText) {
			setTimeout($s.apply._showPopup({title:"メッセージ", html:xhr.responseText, type:"エラー発生"}), 100);
		}
    	if (call_back && call_back.fail) {
    		call_back.fail(xhr, status, error);
    	}
	}).always(function(arg1, status, arg2) {
	    // 通信完了時の処理
    	if (call_back && call_back.always) {
    		call_back.always(arg1, status, arg2);
    	}
    	$s.com.ajaxTransFlag = false;
	});
};

S_ComUtil.prototype.ajaxObj = function(type, fnc, send_data) {
	var ajaxObj =  {
        type: type,
        url: $s.context + "/user/" + $s._objs.applyId + fnc,
        data: send_data,
        contentType: 'application/json;charset=UTF-8',
        dataType:"json",
        success: function(data, status, xhr){
            // 取得データ設定
            if (data.msg) {
                setTimeout($s.apply._showPopup({title:"メッセージ", msg:data.msg, type:"ok"}), 100);
            }
        } ,
        error : function(XMLHttpRequest, textStatus, errorThrown) {
            alert("error:" + XMLHttpRequest + "/" + textStatus + "/" + errorThrown);
        }
    };
	if (type == "POST") {
		ajaxObj.data = JSON.stringify(send_data);
	}
	return ajaxObj;
};
S_ComUtil.prototype.inputClear = function($el) {
	// ラジオ、チェックボックス以外のINPUTとTEXTAREA
	$el.find("input[type!=button][type!=radio][type!=checkbox],textarea").each(function(index, element) {
        $(element).val("").text("");
    });
	// ラジオ、チェックボックス
	$el.find("input[type=radio],input[type=checkbox]").each(function(index, element) {
    	$(element).prop("selected", false).prop("checked", false).checkboxradio('refresh');
    });
	// セレクト
	$el.find("select").each(function (index, el){
        $(el).val($(el).find("option:first").val()).selectmenu('refresh');
    });
};

S_ComUtil.prototype.compressionImage = function(file, callback) {
	const THUMBNAIL_WIDTH = 600; // 画像リサイズ後の横の長さの最大値
	const THUMBNAIL_HEIGHT = 800; // 画像リサイズ後の縦の長さの最大値
	var blob = null;
	// 画像をリサイズする
	var image = new Image();
	var reader = new FileReader();
	reader.onload = function(e) {
	  image.onload = function() {
	    var width, height;
	    if(image.width > image.height){
	      // 横長の画像は横のサイズを指定値にあわせる
	      var ratio = image.height/image.width;
	      width = THUMBNAIL_WIDTH;
	      height = THUMBNAIL_WIDTH * ratio;
	    } else {
	      // 縦長の画像は縦のサイズを指定値にあわせる
	      var ratio = image.width/image.height;
	      width = THUMBNAIL_HEIGHT * ratio;
	      height = THUMBNAIL_HEIGHT;
	    }
	    // サムネ描画用canvasのサイズを上で算出した値に変更
	    var canvas = $('#afroci_canvas').attr('width', width).attr('height', height);
	    var ctx = canvas[0].getContext('2d');
	    // canvasに既に描画されている画像をクリア
	    ctx.clearRect(0,0,width,height);
	    // canvasにサムネイルを描画
	    ctx.drawImage(image,0,0,image.width,image.height,0,0,width,height);

	    // canvasからbase64画像データを取得
	    var base64 = canvas.get(0).toDataURL('image/jpeg');
	    // base64からBlobデータを作成
	    var barr, bin, i, len;
	    bin = atob(base64.split('base64,')[1]);
	    len = bin.length;
	    barr = new Uint8Array(len);
	    i = 0;
	    while (i < len) {
	      barr[i] = bin.charCodeAt(i);
	      i++;
	    }
	    blob = new Blob([barr], {type: 'image/jpeg'});
	    file = blob;
	    callback(blob);
	  }
	  image.src = e.target.result;
	}
	reader.readAsDataURL(file);
	return blob;
}
S_ComUtil.prototype.getExtension = function(fileName) {
    var fileTypes = fileName.split(".");
    var len = fileTypes.length;
    if (len === 0) {
      return "";
    }
    return fileTypes[len - 1];
};

var S_ListUtil = function(obj){
    if ((this instanceof S_ListUtil) == false) throw new Error("インスタンス生成失敗しました。");
    $(document).on("click", ".btn_row_add", function(e){
    	var id = $(this).closest('table').attr("id");
        var list_el = $s._objs[id];
        var data = {};
        data[id] = [{}];
        $s.com.set_val(list_el,data,true);
        //$s.lis.rownoSet(list_el, id);
    });
    $(document).on("click", ".btn_row_del", function(e){
    	var id = $(this).closest('table').attr("id");
        var list_el = $s._objs[id];
        var tr = $(this).closest('tr')[0];
        $s.lis.del(list_el, tr);
        $s.lis.rownoSet(list_el, id);
    });
};

S_ListUtil.prototype.clear = function(obj) {
    if (obj == undefined) return;
    var list = document.getElementById(obj.id);
    if (list.tagName == "TABLE") {
        if (list.tBodies.length < 1) {
            list.appendChild(document.createElement("tbody"));
            return list;
        } else {
            list.tBodies[0].innerHTML = "";
        }
    } else if(list.tagName == "UL") {
        list.innerHTML = "";
    }
    return list;
};
S_ListUtil.prototype.add = function(obj) {
    if (obj == undefined) return;
    var list = document.getElementById(obj.id);
    if (list.tagName == "TABLE") {
        var tBody = obj.elems[0];
        for (var i = 0; i < obj.elems.length; i++) {
            if (obj.elems[i].tag == "tBody") tBody = obj.elems[i];
        }
        return $s.com.add_els(list.tBodies[0], tBody.elems);
    } else if(list.tagName == "UL") {
        return $s.com.add_els(list, obj.elems);
    }
};
S_ListUtil.prototype.del = function(obj, li) {
    if (obj == undefined) return;
    var list = document.getElementById(obj.id);
    if (list.tagName == "TABLE") {
        var cnt = 0;
        var tBody = obj.elems[0];
        for (var i = 0; i < obj.elems.length; i++) {
            if (obj.elems[i].tag == "tBody") tBody = obj.elems[i];
        }
        for (var i = 0; i < tBody.elems.length; i++) {
            if (tBody.elems[i].tag == "tr") cnt++;
        }

        for (var i = cnt; i > 0; i--) {
            list.tBodies[0].deleteRow(li.sectionRowIndex + i - 1);
        }

    } else if(list.tagName == "UL") {
        if (li == undefined) return;
        list.removeChild(li);
    }
};

S_ListUtil.prototype.rownoSet = function(obj, id) {
    var cnt = 0;
    if (obj == undefined) {return;}
    var tBody = obj.elems[0];
    for (var i = 0; i < obj.elems.length; i++) {
        if (obj.elems[i].tag == "tBody") tBody = obj.elems[i];
    }
    for (var i = 0; i < tBody.elems.length; i++) {
        if (tBody.elems[i].tag == "tr") cnt++;
    }
    $("#" + id + " .btn_row_del").each(function(rowno, current){
    	var rowIndex = $(current).closest("tr").index();
    	for (var i = 1; i <= cnt; i++) {
    		var row = $(current).closest("table").find("tr").get(rowIndex + i);
    		$(row).find("[data-db-key]").each(function(index, el){
    			var key = $(el).attr("data-db-key") + "_" + rowno;
    			$(el).attr("id", key).attr("name", key);
    		});
    	}
    });
};

S_ListUtil.prototype.getRowData = function(id) {
	var obj = $s._objs[id];
    if (obj == undefined) return;
    var result = [];
    var list = document.getElementById(id);
    if (list.tagName == "TABLE") {
        var cnt = 0;
        var tBody = obj.elems[0];
        for (var i = 0; i < obj.elems.length; i++) {
            if (obj.elems[i].tag == "tBody") tBody = obj.elems[i];
        }
        for (var i = 0; i < tBody.elems.length; i++) {
            if (tBody.elems[i].tag == "tr") cnt++;
        }
        $("#" + id + " .btn_row_del").each(function(rowno, current){
        	result[rowno] = {};
        	var rowIndex = $(current).closest("tr").index();
        	for (var i = 0; i < cnt; i++) {
        		var row = $(current).closest("table").find("tbody tr").get(rowIndex + i);
        		$(row).find("[data-db-key]").each(function(index, el){
        			var key = $(el).attr("data-db-key");
        			var type = $(el).attr("type");
        	        if (type == "radio" && $(el).is(':checked')) {
        	        	result[rowno][key] = $(el).val();
        	        } else if (type == "checkbox") {
        	        	var tmp = $(el).is(':checked') ? "1" : "0";
        	        	if (result[rowno][key] == undefined) {
        	        		result[rowno][key] = tmp + "|";
        	        	} else {
        	        		result[rowno][key] += tmp + "|";
        	        	}
        	        } else if (type == "textarea") {
        	        	result[rowno][key] = $(el).text();
        	        } else {
            			result[rowno][key] = $(el).val();
        	        }
        		});
        	}
        });
    } else if(list.tagName == "UL") {
		result[result.length] = {};
		list.each(function(listno, li){
			li.find("[data-db-key]").each(function(index, el) {
				var key = $(el).attr("data-db-key");
				var type = $(el).attr("type");
		        if (type == "radio" && $(el).is(':checked')) {
		        	result[rowno][key] = $(el).val();
		        } else if (type == "checkbox" && $(el).is(':checked')) {
		        	result[rowno][key] += $(el).val() + "|";
		        } else if (type == "textarea") {
		        	result[rowno][key] = $(el).text();
		        } else {
	    			result[rowno][key] = $(el).val();
		        }
		    });
		});
    }
    return result;
};
S_ListUtil.prototype.getListData = function(list_nm, sort_name) {
    var list = [];
    $("table#" + list_nm + " tbody").children().each(function(index, tr){
        var data = {};
        $(tr).find("[data-db-key]").each(function(i, el){
        data[$(el).attr("data-db-key")] = $(el).val();
        });
        list[list.length] = data;
    });
    send_data[list_nm] = list;
    // 申請日並び替え
    if ($s.com.isNotEmpty(sort_name)) {
        send_data[list_nm].sort(
            function(a,b){
                var aName = a[sort_name];
                var bName = b[sort_name];
                if( aName < bName ) return -1;
                if( aName > bName ) return 1;
                return 0;
            }
        );
    }
    return list;
};

var S_SelectUtil = function(){
    if ((this instanceof S_SelectUtil) == false) throw new Error("インスタンス生成失敗しました。");
    this.sel;
};
S_SelectUtil.prototype.setSel = function(obj) {
    if (typeof(obj) == "string") {
        obj = document.getElementById(obj);
        if (obj == undefined) {
            obj = document.getElementsByName(obj)[0];
        }
    }
    if (obj != undefined || obj.tagName == "SELECT") {
        this.sel = obj;
    } else {
        return undefined;
    }
    return this.sel;
};
S_SelectUtil.prototype.clear = function(obj) {
    if (this.setSel(obj) == undefined) return;
    for (var i = this.sel.options.length - 1; 0 <= i; --i) {
        this.sel.removeChild(options[i]);
    }
};
S_SelectUtil.prototype.add = function(obj, opts) {
    if (this.setSel(obj) == undefined || opts == undefined) return;
    var fragment = document.createDocumentFragment();
    for (var i = 0; i < opts.length; i++) {
        var opt = opts[i];
        var el = document.createElement("option");
        el.setAttribute("value", opt.val);
        el.appendChild(document.createTextNode(opt.txt));
        fragment.appendChild(el);
    }
    this.sel.appendChild(fragment.cloneNode(true));
    return this.sel;
};
S_SelectUtil.prototype.selected = function(obj, val) {
    if (this.setSel(obj) == undefined) return;
    for (var i = 0; i < this.sel.options.length; i++) {
        var opt = this.sel.options[i];
        opt.selected = (opt.value == val);
    }
};
S_SelectUtil.prototype.get = function(obj, val) {
    if (this.setSel(obj) == undefined) return;
    if (val == undefined) {
        return this.sel.options[this.sel.selectedIndex];
    }
    for (var i = 0; i < this.sel.options.length; i++) {
        var opt = this.sel.options[i];
        if (opt.val == val) return opt;
    }
    return undefined;
};
S_SelectUtil.prototype.textForVal = function(obj, val) {
    if (this.setSel(obj) == undefined) return;
    for (var i = 0; i < this.sel.options.length; i++) {
        var opt = this.sel.options[i];
        if (opt.val == val) return opt.txt;
    }
    return "";
};

// 時刻オブジェクト
var S_TimeUtil = function() {
    if ((this instanceof S_TimeUtil) == false) throw new Error("インスタンス生成失敗しました。");
    this.time = '00:00';
};

S_TimeUtil.prototype.fmt = function(fmt, obj) {
    // デフォルトフォーマット
    if (!fmt) fmt = 'HH:mi:ss';
    var str = String(obj).replace(/:/g , '');
    var fixd = '';
    if (str.substr(0,1) == '-') {
        str = str.substr(1);
        fixd = '-';
    }
    var pattern = /^[:]?\d*$/;
    if (pattern.test(str) == false) return '00:00';
    var hh, mi, ss;
    if (str.length == 6) {
        hh = Number(str.substr(0,2));
        mi = Number(str.substr(2,4));
        ss = Number(str.substr(4));
    } else if (str.length == 5) {
        hh = Number(str.substr(0,1));
        mi = Number(str.substr(1,3));
        ss = Number(str.substr(3));
    } else if (str.length == 4) {
        hh = Number(str.substr(0,2));
        mi = Number(str.substr(2));
        ss = 0;
    } else if (str.length == 3) {
        hh = Number(str.substr(0,1));
        mi = Number(str.substr(1));
        ss = 0;
    } else if (str.length <= 2) {
        hh = Number(str);
        mi = 0;
        ss = 0;
    }
    if (ss > 60) {
        mi += 1;
        ss -= 60;
    }
    if (mi > 60) {
        hh += 1;
        mi -= 60;
    }
    fmt = fmt.replace(/HH/g, ('00' + hh).slice(-2));
    fmt = fmt.replace(/mi/g, ('00' + mi).slice(-2));
    fmt = fmt.replace(/ss/g, ('00' + ss).slice(-2));
    // 処理結果
    return (fixd + fmt);
};

S_TimeUtil.prototype.calc = function (s, e, f) {
    var result = '0.0';
    if (s == undefined || e == undefined || s == '' || e == '') return result;
    var str_s = s.split(':');
    var str_e = e.split(':');
    if (str_s.length > 1 && str_e.length > 1) {
        var h = str_e[0] - str_s[0];
        var m = str_e[1] - str_s[1];
        if (m < 0) {
            h -= 1;
            m = 60 + m;
        }
        result = h + '.' + String(Math.floor((m / 60) * 100));
    }
    if (f != undefined) return this.fmt(f, result);
    return result;
};
S_TimeUtil.prototype.add=function (s, t) {
    var result = '00:00';
    if (s == undefined || t == undefined || s == '' || t == '') return result;
    var str_s = s.split(':');
    if (str_s.length > 1) {
        var m = Number(t);
        var h = Math.floor((Number(str_s[1]) + m)/60);
        var hh = (h + Number(str_s[0]));
        var mm = (Number(str_s[1]) + m) - (h * 60);
        result = ("00" + hh).slice(-2) + ":" + ("00" + mm).slice(-2);
    }
    return result;
}


/** ローカル関数：時刻項目フォーカスアウト */
S_TimeUtil.prototype.blurTime = function(e) {
    e.srcElement.value = $s.tim.fmt('HH:mm', e.srcElement.value);
};

var S_NumberUtil = function() {
    if ((this instanceof S_NumberUtil) == false) throw new Error("インスタンス生成失敗しました。");
    this.FMT     = '0.00';
    this.R_CEIL  = 'ceil';
    this.R_FLOOR = 'floor';
    this.R_ROUND = 'round';
};

S_NumberUtil.prototype.getFmtMatchLength = function(val) {
    return (val == '') ? 0 : val.match(/0/g).length;
};
S_NumberUtil.prototype.fmtFixed = function(val, fixed) {
    var result = String(val).replace(/(\d)(?=(\d{3})+$)/g , '$1,');
    if (fixed != undefined) {
        var tmp = "";
        var tmpDecimal = result.split(".");
        if (tmpDecimal.length > 1) tmp = tmpDecimal[1];
        for (var i = tmp.length; i < fixed; i++) tmp += "0";
        result = tmpDecimal[0] + "." + tmp;
    }
    return result;
};

// フォーマット
S_NumberUtil.prototype.fmt = function(fmt, val, rounding) {
    // デフォルトフォーマット
    if (fmt == undefined || fmt == '') fmt = this.Fmt;
    if (val == undefined) return fmt;
    var index      = fmt.indexOf('0');
    var lastIndex  = fmt.lastIndexOf('0');
    var fmt_prefix = fmt.substring(0, index);
    var fmt_suffix = fmt.substr(lastIndex + 1);

    var fmt_arry = String(fmt).split('.');
    var fmt_num = fmt_arry[0].substr(index);
    var fmt_num_length = this.getFmtMatchLength(fmt_num);
    var fmt_dec = '';
    if (fmt_arry.length > 1) {
        fmt_dec = fmt_arry[1].substring(0, lastIndex + 1);
    }

    var val_arry = String(val).split('.');
    var val_num = val_arry[0];
    var val_dec = '';
    if (val_arry.length > 1) {
        val_dec = val_arry[1];
    }
    var fmt_dec_length = this.getFmtMatchLength(fmt_dec);
    if (val_dec.length > fmt_dec_length) {
        var pow = Math.pow(10 , fmt_dec_length);
        var tmp = Number('.' + val_dec);
        if (fmt_dec_length > 0) tmp = tmp * pow;
        if (rounding == this.R_CEIL) tmp = Math.ceil(tmp);        // 切り上げ
        else if (rounding == this.R_FLOOR) tmp = Math.floor(tmp); // 切り捨て
        else tmp = Math.round(tmp);                               // 四捨五入
        if (fmt_dec_length > 0) tmp = tmp / pow;
        if (tmp > 0) val_num = String(Number(val_num) + 1);
        val_dec = String(tmp).substr(String(tmp).indexOf('.') + 1);
    }
    for (var i=0; i<fmt_dec_length; i++) {
        val_dec = val_dec + '0';
    }
    val_dec = val_dec.substring(0, fmt_dec_length);

    if (val_num.length < fmt_num_length) {
        for (var i=0; i<fmt_num_length; i++) {
            val_num = '0' + val_num;
        }
        val_num = val_num.slice(-fmt_num_length);
    }
    // 処理結果返す
    var dec_mark = (fmt_arry.length > 1)?'.':'';
    return fmt_prefix + val_num + dec_mark + val_dec + fmt_suffix;
};

S_NumberUtil.prototype.blurNumber = function(e) {
    e.srcElement.value = $s.num.fmt('0.00', e.srcElement.value);
}

// コンストラクタ
var S_DateUtil = function (_def_holidays) {
    if ((this instanceof S_DateUtil) == false) throw new Error("インスタンス生成失敗しました。");
    this.sysDate = new Date();
    this.week = ["日","月","火","水","木","金","土"];
};


// システム日付（inputDateの値設定用）
S_DateUtil.prototype.sysDatVal = function() {
	return this.fmt("YYYY-MM-DD", this.sysDate);
};

S_DateUtil.prototype.sysMonthFirstDat = function() {
	return this.fmt("YYYY-MM-01", this.sysDate);
};
S_DateUtil.prototype.sysMonthLastDat = function() {
	return this.fmt("YYYY-MM-DD", new Date(this.sysDate.getFullYear(), this.sysDate.getMonth() + 1, 0));
};


// 日付フォーマット
S_DateUtil.prototype.fmt = function(fmt, date) {
    if (date == undefined) date = new Date();
    if (typeof(date) == "string") date = this.getDateForYmd(date);
    if (date.year && date.month && date.dayOfMonth) {
    	date = new Date(date.year, date.month, date.dayOfMonth);
    }
    // デフォルトフォーマット
    if (!fmt) fmt = 'YYYY-MM-DD hh:mm:ss.SSS';
    // フォーマット変換
    fmt = fmt.replace(/YYYY/g, date.getFullYear());
    fmt = fmt.replace(/MM/g, ('0' + (date.getMonth() + 1)).slice(-2));
    fmt = fmt.replace(/DD/g, ('0' + date.getDate()).slice(-2));
    fmt = fmt.replace(/hh/g, ('0' + date.getHours()).slice(-2));
    fmt = fmt.replace(/mi/g, ('0' + date.getMinutes()).slice(-2));
    fmt = fmt.replace(/ss/g, ('0' + date.getSeconds()).slice(-2));
    fmt = fmt.replace(/d/g, this.week[date.getDay()]);

    if (fmt.match(/S/g)) {
        var milliSeconds = ('00' + date.getMilliseconds()).slice(-3);
        var num = fmt.match(/S/g).length;
        for (var i=0; i<num; i++) {
            fmt = fmt.replace(/S/, milliSeconds.substring(i, i + 1));
        }
    }
    // 処理結果
    return fmt;
};
// 日付計算
S_DateUtil.prototype.add_date = function (num, interval, date) {
    if (date == undefined) date = new Date();
    switch (interval) {
        case 'YYYY': date.setYear(date.getYear() + num); break;
        case 'MM': date.setMonth(date.getMonth() + num); break;
        case 'hh': date.setHours(date.getHours() + num); break;
        case 'mi': date.setMinutes(date.getMinutes() + num); break;
        case 'ss': date.setSeconds(date.getSeconds() + num); break;
        default: date.setDate(date.getDate() + num);
    }
};
// 日付オブジェクト変換（yyyymmdd→Date()）
S_DateUtil.prototype.getDateForYmd = function(yyyymmdd) {
    var ymd = Array(3);
    var split = "";
    if (yyyymmdd.indexOf("-") > 0) split = "-";
    else if (yyyymmdd.indexOf("/") > 0) split = "/";
    if (split != "") {
        ymd = yyyymmdd.split(split);
    } else if (yyyymmdd.length == 8) {
        ymd[0] = yyyymmdd.substr(0, 4);
        ymd[1] = yyyymmdd.substr(4, 2);
        ymd[2] = yyyymmdd.substr(6, 2);
    }
    if (ymd.length == 3) {
        return new Date(ymd[0], Number(ymd[1])-1, ymd[2]);
    } else if (ymd.length == 2) {
    	return new Date(ymd[0], Number(ymd[1])-1, 1);
    }
};

var S_ElsUtil = function(){};
//
S_ElsUtil.prototype.getIconElems = function(class_name, text_val) {
    var elems = [];
    elems[elems.length] = {tag:'span',style:'padding:0 2px;margin-bottom:-4;',className:class_name};
    if (text_val != undefined) {
        elems[elems.length] = {tag:'span',style:'font-size:12px;',text:text_val};
    }
    return elems;
};

// サウザリー共通オブジェクト「$s」作成
$s = {_objs:{},_els:{}};
// 画面ロード時オブジェクト生成
$(function () {
    // 共通ユーティリティ初期化
    $s.com = new S_ComUtil();
    $s.dat = new S_DateUtil();
    $s.tim = new S_TimeUtil();
    $s.lis = new S_ListUtil();
    $s.num = new S_NumberUtil();
    $s.sel = new S_SelectUtil();
});
// 画面アンロード時オブジェクト破棄
$(window).unload(function(){ $s = null; });
