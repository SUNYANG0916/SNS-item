//作成日時：2019/08/29 22:21:40
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_conditions",className:"sa-form-container",elems:[
 {tag:"div",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:60%;",elems:[
   {tag:"input",type:"month",id:"conditions",placeholder:"作業年月"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:40%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_working_data",elems:[
 {tag:"table",id:"tbl_working_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_working_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:150px;",elems:[
     {tag:"label",text:"作業日",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:150px;",elems:[
     {tag:"label",text:"Title",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",style:"height:475px;",elems:[
   {tag:"tr","data-db-key":"selTr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",name:"a_edit",style:"font-size: 12px;",elems:[
      {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
     ]}
    ]}
   ,{tag:"td",style:"width:150px;text-align:center;",elems:[
     {tag:"label","data-db-key":"workingDate",name:"workingDate",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"workingTitle",name:"workingTitle",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"text-align:center;background-color:#ddd;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"5"}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_working_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
 {tag:"table",id:"tbl_working_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"作業日",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"date","data-db-key":"workingDate",id:"workingDate",name:"workingDate",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"Title",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"workingTitle",id:"workingTitle",name:"workingTitle",style:"font-size: 10px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"作業時間",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"label",text:"開始",style:"font-size: 12px;"}
      ,{tag:"input",type:"time","data-db-key":"workingTimeStart",id:"workingTimeStart",name:"workingTimeStart",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"label",text:"終了",style:"font-size: 12px;"}
      ,{tag:"input",type:"time","data-db-key":"workingTimeEnd",id:"workingTimeEnd",name:"workingTimeEnd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"作業内容",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"workingInfo",id:"workingInfo",name:"workingInfo"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"課題・問題",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"workingProblem",id:"workingProblem",name:"workingProblem"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"連絡情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"contactInfo",id:"contactInfo",name:"contactInfo",style:"width:100%;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"workingNote",id:"workingNote",name:"workingNote",style:"width:100%;"}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-top:10px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",name:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"廃止",id:"btn_delete",name:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",name:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
];

