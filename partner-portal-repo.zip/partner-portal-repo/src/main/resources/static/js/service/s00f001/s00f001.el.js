//作成日時：2019/07/07 12:26:24
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_menu_info",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"tbl_menu_info",className:"ui-grid-a",elems:[
  {tag:"div",id:"div_menu_work",className:"ui-block-a",elems:[
   {tag:"ul",style:"margin:5px 3px 1px 3px;border-radius: 5px;","data-role":"listview",elems:[
    {tag:"li",text:"一般メニュー",id:"list_title_1",className:"ui-icon-carat-u ui-btn-icon-right","data-role":"list-divider"}
   ]}
  ,{tag:"ul",id:"list_menu_work",className:"menu_list",style:"margin:0px 5px 5px 5px;",list_id:"list_menu_work","data-role":"listview","data-inset":"True",elems:[
    {tag:"li",elems:[
     {tag:"a",name:"a_list",className:"ui-btn ui-btn-icon-left ui-icon-bars",elems:[
      {tag:"label","data-db-key":"menuNm",name:"menuNm"}
     ,{tag:"input",type:"hidden","data-db-key":"menuId",name:"menuId"}
     ,{tag:"input",type:"hidden","data-db-key":"applyId",name:"applyId"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",id:"div_menu_manager",className:"ui-block-b",elems:[
   {tag:"ul",style:"margin:5px 3px 1px 3px;border-radius: 5px;","data-role":"listview",elems:[
    {tag:"li",text:"管理メニュー",id:"list_title_2",className:"ui-icon-carat-u ui-btn-icon-right","data-role":"list-divider"}
   ]}
  ,{tag:"ul",id:"list_menu_manager",className:"menu_list",style:"margin:0px 5px 5px 5px;",list_id:"list_menu_manager","data-role":"listview","data-inset":"True",elems:[
    {tag:"li",elems:[
     {tag:"a",name:"a_list",className:"ui-btn ui-btn-icon-left ui-icon-bars",elems:[
      {tag:"label","data-db-key":"menuNm",name:"menuNm"}
     ,{tag:"input",type:"hidden","data-db-key":"menuId",name:"menuId"}
     ,{tag:"input",type:"hidden","data-db-key":"applyId",name:"applyId"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",id:"div_menu_seikyu",className:"ui-block-b",elems:[
   {tag:"ul",style:"margin:5px 3px 1px 3px;border-radius: 5px;","data-role":"listview",elems:[
    {tag:"li",text:"請求管理メニュー",id:"list_title_3",className:"ui-icon-carat-u ui-btn-icon-right","data-role":"list-divider"}
   ]}
  ,{tag:"ul",id:"list_menu_seikyu",className:"menu_list",style:"margin:0px 5px 5px 5px;",list_id:"list_menu_seikyu","data-role":"listview","data-inset":"True",elems:[
    {tag:"li",elems:[
     {tag:"a",name:"a_list",className:"ui-btn ui-btn-icon-left ui-icon-bars",elems:[
      {tag:"label","data-db-key":"menuNm",name:"menuNm"}
     ,{tag:"input",type:"hidden","data-db-key":"menuId",name:"menuId"}
     ,{tag:"input",type:"hidden","data-db-key":"applyId",name:"applyId"}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

