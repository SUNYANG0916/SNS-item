/*************************
 * S10F001-プロジェクトマスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s10f001 = new s10f001_util();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s10f001_util = function(){
    if ((this instanceof s10f001_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    $("#h_title").text("プロジェクト一覧");
    // イベント
    this.event_init();
    this.mode = "update";
    // 一覧初期化
    $("#tbl_project_list").get(0).tBodies[0].innerHTML = "";
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_project_edit")[0]);
    }
};
/**
 * イベントの初期化
 * */
s10f001_util.prototype.event_init = function(e) {
	try {
		$(document).on('click', '#h_title', function(e){ $s.s10f001._ctrlEditView(this); });
	    // クリック_検索ボタン
		$(document).on('click', '#btn_search', function(e){ $s.s10f001._search(this); });
	    // クリック_新規
	    $(document).on('click', '[name=a_add]', function(e){ $s.s10f001._ctrlEditView(this); });
	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s10f001._selTr(e, this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s10f001._ctrlEditView(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s10f001._ctrlEditView(this); });
	    // クリック_登録・更新ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s10f001._update(this); });
	    // クリック_廃止リンク
	    $(document).on('click', '#btn_delete', function(e){ $s.s10f001._delete(this); });
	    // クリック_取引先検索リンク
	    $(document).on('click', '#a_suppliers', function(e){ $s.s10f001._master_suppliers(this); });
	    // クリック_取引先検索
	    $(document).on("click", "[name=btn_master_suppliers_search]", function(e) {$s.s10f001._master_suppliers_search(this);});
	    // クリック_取引先検索リンク
	    $(document).on('click', "[name=a_sel_suppliers]", function(e){ $s.s10f001._sel_suppliers(this); });
        // クリック_CSVファイル指定
        $(document).on('click', '#btn_csv_upload', function(e){
            if ($s._objs.canEdit == true) {
            	$("#csvfile").trigger("click");
            }
        });
        // チェンジ_CSVファイル指定変更
        $(document).on('change', '#csvfile', function(e){ $s.s10f001._csvFileUpLoad(this); });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};
s10f001_util.prototype._selTr = function(e, el) {
	if (e.target.name == "copy") {
		$s.s10f001._ctrlEditView(e.target);
	} else {
		var edit = $(el).find("#a_edit");
		if (edit) {
			$s.s10f001._ctrlEditView(edit[0]);
		}
	}
};
/**
 * プロジェクト一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s10f001_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var send_data = {cond:$("#cond").val(),selDelete:$("#selDelete").val()};
	var callback = {
		done : function(data, status, xhr){
			if (data.tbl_project_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            $s.com.set_val($("#div_project_info"), data);
		}
    };
    $s.com.ajax("GET", "_search", send_data, callback);
};
/**
 * プロジェクト情報取得
 *
 * @param el イベント発火エレメント
 *  */
s10f001_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {pjCd : $(el).closest("tr").find("#pjCd").text()};
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#div_project_edit"), data.tbl_project_list);
			if ($s.s10f001.mode == "create") {
				$("#div_project_edit #pjCd").val("");
				$("#div_project_edit #pjNm").val("");
			}
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s10f001_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
    // プロジェクト情報クリア
    $s.com.inputClear($("table#tbl_project_info"));
    if (el.id == "a_edit") {
    	// 新規モード
        this.mode = "update";
        // プロジェクト情報取得
        this._details(el);
        $("input#projectName").attr("readonly", false);
    } else if (el.id == "a_add") {
        // 編集モード
    	this.mode = "create";
    } else if (el.name == "copy") {
    	// コピー新規モード
    	this.mode = "create";
        // 明細情報取得
    	this._details(el);
    } else {
    	// 一覧表示
    	this.mode = "list";
    }

    // 表示制御
    if (this.mode == "create" || this.mode == "update") {
        $("#h_title").text("プロジェクト詳細");
        $("#div_project_list").css("display","none");
        $("#div_project_edit").css("display","block");
        $("#div_project_data").css("display","none");
        $("#conditions").css("display","none");
    } else {
        $("#h_title").text("プロジェクト一覧");
    	$("#div_project_list").css("display","block");
        $("#div_project_edit").css("display","none");
        $("#div_project_data").css("display","block");
        $("#conditions").css("display","");
    }
};


/**
 * プロジェクト情報登録更新
 * */
s10f001_util.prototype._update = function(el) {
	var pjCheckList = [];
	$("#form_projest :input").each(function(index, el) {
	    if ($(el).prop("validate")) pjCheckList[pjCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(pjCheckList, "#form_projest") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_project_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s10f001._search();
                    $s.s10f001._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_update", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

/**
 * プロジェクト情報登録更新
 * */
s10f001_util.prototype._delete = function(el) {

	var opt = {title: "確認", msg:"廃止します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_project_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s10f001._search();
                    $s.s10f001._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

s10f001_util.prototype._master_suppliers = function(el) {
	$(el).closest("tr").find("[data-db-key=suppliersNo]").val("");
	$(el).closest("tr").find("[data-db-key=suppliersName]").val("");
	var opt = {title: "取引先検索", type:"master"};
	opt.html = $("#master_suppliers").clone().css("display","").html();
	$(opt.html).find("#master_suppliers_cond").val(cond);
	$s.apply._showPopup(opt);
	$s.s10f001._master_suppliers_search($("#btn_master_suppliers_search")[0]);
};


s10f001_util.prototype._master_suppliers_search = function(el) {
	var send_data = {cond : $(el).closest("p").find("#master_suppliers_cond").val()};
	if (send_data.cond == "") {
		$(el).closest("p").find("#master_suppliers_cond").after("<div for='master_suppliers_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}

//	$(el).closest("tr").find("[data-db-key=suppliersNo]").val("");
//	$(el).closest("tr").find("[data-db-key=suppliersName]").val("");
//	var callback = {
//		done : function(data, status, xhr){
//			$s.com.set_val($("#master_suppliers"), data);
//
//			var opt = {title: "取引先検索", type:"master"};
//			opt.html = $("#master_suppliers").clone().css("display","").html();
//			$s.apply._showPopup(opt);
//        }
//	};
//	$s.com.ajax("GET", "_master_suppliers", send_data, callback);

	var callback = {
			done : function(data, status, xhr){
				$s.com.set_val($(el).closest("#popup_msg").find("#popupMsg"), data);
				var opt = {title: "取引先検索", type:"master"};
				opt.html = $("#master_suppliers").clone().css("display","").html();
				$(opt.html).find("#master_suppliers_cond").val(send_data.cond);
				$s.apply._showPopup(opt);
	        }
		};
	$s.com.ajax("GET", "_master_suppliers", send_data, callback);


};

s10f001_util.prototype._sel_suppliers = function(el) {
	var suppliersName = $(el).closest("tr").find("[data-db-key=suppliersName]").text();
	var suppliersNo = $(el).closest("tr").find("[data-db-key=suppliersNo]").text();
	$("#suppliersName").val(suppliersName);
	$("#suppliersNo").val(suppliersNo);
	$("#popup_ok").click();
};

/**
 * クリック_CSVのアップロード
 *
 * @param el イベント発火エレメント
 *  */
s10f001_util.prototype._csvFileUpLoad = function(el){
    if ($("[data-db-key=csvfile]").val() == "") {
    	return;
    }
    var file = $("[data-db-key=csvfile]")[0].files[0];
    // ファイルサイズチェック
    if (file && file.size > 1048576) {
        setTimeout($s.apply._showPopup({
            title : "メッセージ",
            msg : "ファイルサイズが転送上限（1M）超えているため、転送できません。"
        }), 100);
        return;
    }
    if (window.FormData) {
        var $form = $("#formCsvFile");
        $form.attr("enctype", "multipart/form-data");
        $form.attr("method", "post");
        var ajaxUrl = $s.context + "/user/" + $s._objs.applyId + "_upload";
        $.ajax({
            type : "POST",
            url  : ajaxUrl,
            data : new FormData($form[0]),
            processData : false,
            contentType: false,
        }).done(function(data) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが完了しました。"
            });
        }).fail(function(XMLHttpRequest, textStatus, errorThrown) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが失敗しました。"
            });
        });
    } else {
        $s.apply._showPopup({
            title : "メッセージ",
            msg : "アップロードに対応できていないブラウザです。"
        });
    }
};

