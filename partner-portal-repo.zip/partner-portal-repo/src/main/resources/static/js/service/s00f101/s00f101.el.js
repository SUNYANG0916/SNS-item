//作成日時：2019/09/06 23:40:15
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",className:"ui-grid-a",elems:[
  {tag:"div",id:"div_conditions",className:"ui-block-a",style:"width:60%;",elems:[
   {tag:"input",type:"text",id:"conditions",style:"margin:4px;",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:40%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;"}
  ]}
 ]}
,{tag:"div",id:"div_user_list",elems:[
  {tag:"table",id:"tbl_user_list",name:"tbl_user_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_user_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"氏名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"基本情報更新日時",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"ｽｷﾙ情報更新日時",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"セキュリティ実施日時",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"作業報告",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"input",type:"hidden","data-db-key":"user_row",name:"user_row"}
     ,{tag:"label","data-db-key":"user_initial",name:"user_initial",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"kihonYmd",name:"kihonYmd",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"skilYmd",name:"skilYmd",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"securityYmd",name:"securityYmd",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"input",type:"hidden","data-db-key":"apply_id",name:"apply_id",value:"s20f007"}
     ,{tag:"a",id:"a_working",name:"a_working",className:"ui-btn ui-icon-bullets ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

