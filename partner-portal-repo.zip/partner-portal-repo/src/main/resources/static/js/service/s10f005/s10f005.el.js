//作成日時：2019/12/15 20:57:01
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_calendar",className:"sa-form-container",elems:[
 {tag:"div",id:"div_ctrl",className:"ui-grid-b ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:200px;",placeholder:"navbar",elems:[
   {tag:"div",className:"ui-grid-b",elems:[
    {tag:"div",className:"ui-block-a",style:"width:40px;;margin-top:8px;",elems:[
     {tag:"a",text:"<",id:"a_month_back",name:"a_apply_back",className:"afr_upd ui-btn ui-corner-all",style:"padding:7px;"}
    ]}
   ,{tag:"div",className:"ui-block-b",style:"width:50%;margin-top:2px;",elems:[
     {tag:"input",type:"text",id:"inp_month",name:"inp_month",className:"ui-btn ui-corner-all",style:"padding:8px;text-align:center;font-size: 12px;",readOnly:"True"}
    ]}
   ,{tag:"div",className:"ui-block-c",style:"width:40px;margin-top:8px;",elems:[
     {tag:"a",text:">",id:"a_month_next",name:"a_apply_next",className:"afr_upd ui-btn ui-corner-all",style:"padding:7px;"}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 280px);",elems:[
   {tag:"input",type:"text",id:"searchConditions",name:"searchConditions",placeholder:"キーワード"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-c",style:"width:80px;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_calendar_list",elems:[
 {tag:"table",id:"tbl_calendar_list",className:"scroll_table",style:"width:100%;margin-top:5px;margin-bottom:20px;",list_id:"tbl_calendar_list",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:25%;",elems:[
     {tag:"label",text:"日付",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"予定内容",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",rowSpan:"2",elems:[
     {tag:"a",name:"list_schedule_ctlr",className:"ui-btn ui-btn-icon-notext ui-corner-all ui-icon-carat-d",style:"margin:auto;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:25%;text-align:center;",elems:[
     {tag:"a","data-db-key":"occurDate",name:"occurDate",style:"font-size: 12px;"}
    ,{tag:"input",type:"hidden","data-db-key":"weekDay"}
    ,{tag:"input",type:"hidden","data-db-key":"dateId"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",name:"schedules",elems:[
      {tag:"ul",name:"schedulesList",className:"ulScheduleList",style:"margin:2px;",elems:[
       {tag:"li",className:"aSchedule",style:"margin:0px;cursor: pointer;border-bottom:solid 1px wheat;",elems:[
        {tag:"a",text:"　",name:"aSchedulesText",style:"margin:3px;text-align:left;padding:3px;font-size:12px;"}
       ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
       ]}
      ]}
     ,{tag:"ul",name:"schedulesAllList",className:"ulScheduleAllList",style:"margin:2px;display:none;"}
     ]}
    ]}
   ,{tag:"td",elems:[
     {tag:"a",name:"list_schedule_ctlr",className:"ui-btn ui-icon-carat-d ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_schedule_edit",style:"display: none;padding:2px;",elems:[
 {tag:"table",id:"tbl_schedule_info",name:"tbl_schedule_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:50%;",elems:[
     {tag:"label",text:"従業員",style:"font-size: 12px;"}
    ,{tag:"input",type:"text","data-db-key":"userName",id:"userName",name:"userName",style:"width:100%;background-color: whitesmoke;",readOnly:"True"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label",text:"対象日",style:"font-size: 12px;"}
    ,{tag:"input",type:"date","data-db-key":"scheduleDate",id:"scheduleDate",name:"scheduleDate",style:"width:100%;background-color: whitesmoke;"}
    ,{tag:"input",type:"hidden","data-db-key":"sequence",id:"sequence",name:"sequence",value:"0"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_schedule_list",name:"tbl_schedule_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_schedule_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",id:"tbl_schedule_list_add",name:"tbl_schedule_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"時間（開始-終了）",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text","data-db-key":"timeCheck",name:"timeCheck",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"タイトル",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text","data-db-key":"scheduleTitleCheck",name:"scheduleTitleCheck",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",colSpan:"2",elems:[
     {tag:"label",text:"内容",style:"font-size: 12px;"}
    ,{tag:"input",type:"text","data-db-key":"schedulesTextCheck",name:"schedulesTextCheck",style:"display:none;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",name:"tbl_schedule_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"input",type:"time","data-db-key":"startTime",name:"startTime",style:"font-size: 10px;"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"input",type:"time","data-db-key":"endTime",name:"endTime",style:"font-size: 10px;"}
      ]}
     ]}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"scheduleTitle",name:"scheduleTitle"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",colSpan:"2",elems:[
     {tag:"textarea","data-db-key":"scheduleText",name:"scheduleText",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"a",id:"tbl_schedule_list_add",name:"tbl_schedule_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"2"}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-a",style:"margin-bottom:30px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"schedule_all",style:"display:none;",elems:[
 {tag:"table",id:"tbl_schedule_all_info",name:"tbl_schedule_all_info",className:"sa-form",style:"width:100%;",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:50%;",elems:[
     {tag:"label","data-db-key":"userName",id:"userName",name:"userName",className:"ui-btn",readOnly:"True"}
    ]}
   ,{tag:"td",style:"width:50%;",elems:[
     {tag:"label","data-db-key":"scheduleDate",id:"scheduleDate",name:"scheduleDate",className:"ui-btn"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_schedule_all_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_schedule_all_list",even_color:"#F1F4FF",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"label","data-db-key":"startTime",name:"startTime",style:"font-size: 12px;"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"label","data-db-key":"endTime",name:"endTime",style:"font-size: 12px;"}
      ]}
     ]}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"scheduleTitle",name:"scheduleTitle",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr","data-db-key":"selSuppliersTr",name:"selSuppliersTr",elems:[
    {tag:"td",colSpan:"2",elems:[
     {tag:"label","data-db-key":"scheduleText",name:"scheduleText",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
];

