/*************************
 * S30F001-請求書マスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s30f003 = new s30f003_util();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s30f003_util = function(){
    if ((this instanceof s30f003_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    this.mode = "update";
    // 対象取引先
    this.suppliersTarget = {};
    // 対象プロジェクト
    this.projectTarget = {};
    // タイトル
    $("#h_title").text("請求書一覧");
    // イベント
    this.event_init();
    // 一覧初期化
    $("#tbl_invoice_list").get(0).tBodies[0].innerHTML = "";
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_invoice_edit")[0]);
    }
};
/**
 * イベントの初期化
 * */
s30f003_util.prototype.event_init = function(e) {

	$(document).on('click', '#h_title', function(e){ $s.s30f003._ctrlEditView(this); });
    // クリック_検索ボタン
	$(document).on('click', '#btn_search', function(e){ $s.s30f003._search(this); });
    // クリック_新規
    $(document).on('click', '[name=a_add]', function(e){ $s.s30f003._ctrlEditView(this); });
    // クリック_編集リンク
    $(document).on('click', '[name=a_edit]', function(e){ $s.s30f003._ctrlEditView(this); });
    // クリック_行選択
    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s30f003._selTr(e, this); });
    // クリック_登録・更新ボタン
    $(document).on('click', '#btn_update', function(e){ $s.s30f003._update(this); });
    // クリック_廃止リンク
    $(document).on('click', '#btn_delete', function(e){ $s.s30f003._delete(this); });
    // クリック_戻るボタン

    $(document).on('click', '#btn_return', function(e){ $s.s30f003._ctrlEditView(this); });

    // クリック_見積書検索リンク
    $(document).on('click', '#aEstimate', function(e){ $s.s30f003._master_estimate(this); });
    // クリック_見積書行選択
    $(document).on('click', '[data-db-key=selEstimatesTr]', function(e){ $s.s30f003._selEstimateTr(this); });
    // クリック_見積書検索
    $(document).on("click", "[name=btn_master_estimates_search]", function(e) {$s.s30f003._master_estimates_search(this);});

    // クリック_プロジェクト検索リンク
    $(document).on('click', '#aPj', function(e){ $s.s30f003._master_project(this); });
    // クリック_プロジェクト行選択
    $(document).on('click', '[data-db-key=selProjectsTr]', function(e){ $s.s30f003._selProjectTr(this); });
    // クリック_プロジェクト検索
    $(document).on("click", "[name=btn_master_projects_search]", function(e) {$s.s30f003._master_projects_search(this);});

    // クリック_印刷
    $(document).on('click', '#btn_print', function(e){});
};

s30f003_util.prototype._selTr = function(e, el) {
	if (e.target.name == "output") {
		// 請求書出力
		$s.s30f003._print($(el).find("#a_edit"));
	} else if (e.target.name == "copy") {
		$s.s30f003._ctrlEditView(e.target);
	} else if (e.target.name == "a_edit") {
		$s.s30f003._ctrlEditView(e.target);
	}
};

/**
 * 請求書一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s30f003_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var send_data = {cond:$("#cond").val(),selDelete:$("#selDelete").val()};

	var callback = {
		done : function(data, status, xhr){
			if (data.tbl_invoice_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            $s.com.set_val($("#div_invoice_info"), data);
		}
    };
    $s.com.ajax("GET", "_search", send_data, callback);
};
/**
 * 請求書情報取得
 *
 * @param el イベント発火エレメント
 *  */
s30f003_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {invoiceNo : $(el).closest("tr").find("[data-db-key=invoiceNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#div_invoice_edit"), data.tbl_invoice_list);
			$s.com.set_val($("#div_invoice_edit"), {tbl_working_list : data.tbl_working_list});
			if ($s.s30f003.mode == "create") {
				$("#invoiceNo").val("");
			}
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s30f003_util.prototype._ctrlEditView = function(el) {
    // プロジェクト情報クリア
    $s.com.inputClear($("table#tbl_invoice_info"));
    if (el.id == "a_edit") {
    	// 編集モード
        this.mode = "update";
        // 明細情報取得
        this._details(el);
        $("#btn_delete").css("display","");
    } else if (el.id == "a_add") {
    	// 新規モード
        this.mode = "create";
        // 明細情報クリア
        $("#tbl_working_list tbody").html("");
        $("#btn_delete").css("display","none");
    } else if (el.name == "copy") {
    	// コピー新規モード
    	this.mode = "create";
        // 明細情報取得
    	this._details(el);
        $("#btn_delete").css("display","none");
    } else {
    	// 一覧表示
    	this.mode = "list";
    }

    // 表示制御
    if (this.mode == "create" || this.mode == "update") {
        $("#h_title").text("請求書詳細");
        $("#div_invoice_list").css("display","none");
        $("#div_invoice_edit").css("display","block");
        $("#div_invoice_data").css("display","none");
        $("#conditions").css("display","none");
    } else {
        $("#h_title").text("請求書一覧");
    	$("#div_invoice_list").css("display","block");
        $("#div_invoice_edit").css("display","none");
        $("#div_invoice_data").css("display","block");
        $("#conditions").css("display","");
    }
};


/**
 * 請求書情報登録更新
 * */
s30f003_util.prototype._update = function(el) {
	var educCheckList = [];
	var checkInputPj = $("table#tbl_working_list [name=pjNm]")[0];
	$(checkInputPj).val("OK");
	$("table#tbl_working_list [data-db-key=pjNm]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputPj).val("");
		}
	});

	var checkInputDeliveryDate = $("table#tbl_working_list [name=deliveryDate]")[0];
	$(checkInputDeliveryDate).val("OK");
	$("table#tbl_working_list [data-db-key=deliveryDate]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputDeliveryDate).val("");
		}
	});

	var checkInputDueDate = $("table#tbl_working_list [name=dueDate]")[0];
	$(checkInputDueDate).val("OK");
	$("table#tbl_working_list [data-db-key=dueDate]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputDueDate).val("");
		}
	});

	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) educCheckList[educCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(educCheckList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_invoice_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        send_data.amountTotal = $("table#tbl_working_list").find("#amountTotal").text();
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
        		var send_detail = [];
        		var $tr = $("table#tbl_working_list tBody tr");
        		var rowNumber = 0;
        		for(var i = 0; i < $tr.size(); i++) {
        			if (i % 2 == 0) {
        				send_detail[send_detail.length] = { invoiceNo : data.invoiceNo, rowNumber : rowNumber++ };
        			}
        			$($tr[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_detail[send_detail.length - 1], el); });
        		}

        		$s.com.ajax("POST", "_updateDetails", send_detail, {
                	done : function(data, status, xhr){
                		if (data.msg) {
                            $s.s30f003._search();
                            $s.s30f003._ctrlEditView($("#btn_return")[0]);
                        }
                	}
        		});
        	}
        };
	    $s.com.ajax("POST", "_update", send_data, callback);
    }
    $s.apply._showPopup(opt);
};

/**
 * 請求書情報登録廃止
 * */
s30f003_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"廃止します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_invoice_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s30f003._search();
                    $s.s30f003._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

/**
 * 見積書検索
 * */
s30f003_util.prototype._master_estimate = function(el) {
	var opt = {title: "見積書検索", type:"master"};
	opt.html = $("#master_estimates").clone().css("display","").html();
	$s.apply._showPopup(opt);
	$s.s30f003._master_estimates_search($("#btn_master_estimates_search")[0]);
};

s30f003_util.prototype._master_estimates_search = function(el) {
	var send_data = {cond : $(el).closest("p").find("#master_estimates_cond").val()};
	if (send_data.cond == "") {
		// 警告メッセージ
		$(el).closest("p").find("#master_estimates_cond").after("<div for='master_estimates_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#master_estimates"), data);
			var opt = {title: "見積書検索", type:"master"};
			opt.html = $("#master_estimates").clone().css("display","").html();
			$s.apply._showPopup(opt);
        }
	};
	$s.com.ajax("GET", "_master_estimate", send_data, callback);
};


/**
 * 見積書一覧から選択
 * */
s30f003_util.prototype._selEstimateTr = function(el) {
	var $selTr = $(el);

	$("#tbl_invoice_info #estimateNo").val($selTr.find("[data-db-key=estimateNo]").text());
	$("#tbl_invoice_info #estimateName").val($selTr.find("[data-db-key=estimateName]").text());

	$("#tbl_invoice_info #suppliersToNo").val($selTr.find("[data-db-key=suppliersToNo]").val());
	$("#tbl_invoice_info #suppliersToName").val($selTr.find("[data-db-key=suppliersToName]").val());
	$("#tbl_invoice_info #suppliersFromNo").val($selTr.find("[data-db-key=suppliersFromNo]").val());
	$("#tbl_invoice_info #suppliersFromName").val($selTr.find("[data-db-key=suppliersFromName]").val());
	$("#tbl_invoice_info #startDate").val($selTr.find("[data-db-key=startDate]").text());
	$("#tbl_invoice_info #endDate").val($selTr.find("[data-db-key=endDate]").text());
	$("#tbl_invoice_info #postalCode").val($selTr.find("[data-db-key=postalCode]").val());
	$("#tbl_invoice_info #address1").val($selTr.find("[data-db-key=address1]").val());
	$("#tbl_invoice_info #address2").val($selTr.find("[data-db-key=address2]").val());
	$("#tbl_invoice_info #address3").val($selTr.find("[data-db-key=address3]").val());
	$("#tbl_invoice_info #address4").val($selTr.find("[data-db-key=address4]").val());
	$("#tbl_invoice_info #pepresentative").val($selTr.find("[data-db-key=pepresentative]").val());
	$("#tbl_invoice_info #tel").val($selTr.find("[data-db-key=tel]").val());
	$("#tbl_invoice_info #fax").val($selTr.find("[data-db-key=fax]").val());
	$("#tbl_invoice_info #ginkoCd").val($selTr.find("[data-db-key=ginkoCd]").val());
	$("#tbl_invoice_info #ginkoMei").val($selTr.find("[data-db-key=ginkoMei]").val());
	$("#tbl_invoice_info #shitenNo").val($selTr.find("[data-db-key=shitenNo]").val());
	$("#tbl_invoice_info #shitenMei").val($selTr.find("[data-db-key=shitenMei]").val());
	$("#tbl_invoice_info #kouzaType").val($selTr.find("[data-db-key=kouzaType]").val());
	$("#tbl_invoice_info #kouzaNo").val($selTr.find("[data-db-key=kouzaNo]").val());
	$("#tbl_invoice_info #kouzaMei").val($selTr.find("[data-db-key=kouzaMei]").val());

	$("#popup_ok").click();
};

/**
 * プロジェクト検索
 * */
s30f003_util.prototype._master_project = function(el) {
	this.projectTarget = el;
	var opt = {title: "プロジェクト検索", type:"master"};
	opt.html = $("#master_projects").clone().css("display","").html();
	$s.apply._showPopup(opt);
	$s.s30f003._master_projects_search($("#btn_master_projects_search")[0]);
};
/**
 * プロジェクト検索
 * */
s30f003_util.prototype._master_projects_search = function(el) {

	var send_data = {cond : $(el).closest("p").find("#master_projects_cond").val()};
	if (send_data.cond == "") {
		$(el).closest("p").find("#master_projects_cond").after("<div for='master_projects_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#master_projects"), data);

			var opt = {title: "プロジェクト検索", type:"master"};
			opt.html = $("#master_projects").clone().css("display","").html();
			$s.apply._showPopup(opt);
        }
	};
	$s.com.ajax("GET", "_master_project", send_data, callback);
};

/**
 * プロジェクト一覧から選択
 * */
s30f003_util.prototype._selProjectTr = function(el) {
	var $selTr = $(el);
	var projectNm = $selTr.find("[data-db-key=pjNm]").text();
	var projectCd = $selTr.find("[data-db-key=pjCd]").text();
	var quantity = $selTr.find("[data-db-key=quantity]").val();
	var unitPrice = $selTr.find("[data-db-key=unitPrice]").val();
	var unitPriceNm = $selTr.find("[data-db-key=unitPriceNm]").val();
	var amount = $selTr.find("[data-db-key=amount]").val();
	var taxType = $selTr.find("[data-db-key=taxType]").val();
	var workingInfo = $selTr.find("[data-db-key=pjNote]").val();

	var $tr = $(this.projectTarget).closest("tr");
	$tr.find("[data-db-key=pjNm]").val(projectNm);
	$tr.find("[data-db-key=pjCd]").val(projectCd);
	$tr.find("[data-db-key=workingInfo]").text(workingInfo);
	$tr.find("[data-db-key=deliveryDate]").val($s.dat.sysMonthLastDat());

	$tr.next().find("[data-db-key=unitPrice]").val(unitPrice);
	$tr.next().find("[data-db-key=unitPriceNm]").text(unitPriceNm);
	$tr.next().find("[data-db-key=quantity]").text(quantity);
	$tr.next().find("[data-db-key=amount]").text(amount);
	$tr.next().find("[data-db-key=dueDate]").val($s.dat.sysMonthLastDat());

	// 金額集計
	var totalAmount = 0;
	$("#tbl_working_list [data-db-key='amount']").each(function(index, el){
		totalAmount += Number($(el).text());
	});
	$("#tbl_working_list #amountTotal").text(totalAmount);
	$("#popup_ok").click();
};



/**
 * 請求書印刷画面開く
 *
 * @param el イベント発火エレメント
 *  */
s30f003_util.prototype._print = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {invoiceNo : $(el).closest("tr").find("[data-db-key=invoiceNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			data.tbl_invoice_list.taxAmount = data.taxAmount;
			data.tbl_invoice_list.kouzaTypeNm = data.kouzaTypeNm;
			$s.com.set_val($("#div_invoice_print"), data.tbl_invoice_list);
			$s.com.set_val($("#div_invoice_print"), {tbl_working_list_print : data.tbl_working_list});
			$("#div_invoice_print #companyStamp").attr('src',$s.context + '/css/images/print/company_stamp.png');

			var printWindow = {};
			if ($s.com.clientType == "sp") {
                // iOs対応
				$("#div_invoice_print").css("display","block");
            } else {
    			printWindow = window.open("","PrintWindow" , '_blank');
    			printWindow.document.open();
    			printWindow.document.write("<HTML><HEAD><style>@media print{.no_print{display:none;}}</style><HEAD><BODY style='max-width:900px;margin-bottom:100px;'><input type='button' class='no_print' style='position: absolute;top:5px;' value='印刷' onclick='window.print();' />" + $("#div_invoice_print").html() + "</BODY></HTML>");
            }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};
