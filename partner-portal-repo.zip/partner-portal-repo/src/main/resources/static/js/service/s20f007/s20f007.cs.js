/*************************
 * S10F004-作業情報
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s20f007 = new s20f007_util();
        $("#h_title").text("作業一覧");
        // 画面表示
        $s.s20f007._search();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f007_util = function(){
    if ((this instanceof s20f007_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    $("#conditions").val($s.dat.fmt("YYYY-MM", $s.dat.sysDate));
    this.mode = "list";
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_working_edit")[0]);
    }
};
/**
 * イベントの初期化
 * */
s20f007_util.prototype.event_init = function(e) {
	try {
		$(document).on('click', '#h_title', function(e){ $s.s20f007._ctrlEditView(this); });
	    // 一覧へ戻る
	    $(document).on('click', '#a_return', function(e){
	    	if ($s._objs.rtnApply) {
	    		location.href=$s.context + "/user/apply?applyId=" + $s._objs.rtnApply;
	    	} else {
	    		location.href=$s.context + "/user/apply?applyId=s00f004";
	    	}
	    });
	    // クリック_検索
	    $(document).on('click', '#btn_search', function(e){ $s.s20f007._search(this); });
	    // クリック_新規
	    $(document).on('click', '#btn_new', function(e){ $s.s20f007._ctrlEditView(this); });
	    // クリック_新規
	    $(document).on('click', '#a_add', function(e){ $s.s20f007._ctrlEditView(this); });
	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s20f007._selTr(this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s20f007._ctrlEditView(this); });
	    // クリック_登録ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s20f007._update(this); });
	    // クリック_削除ボタン
	    $(document).on('click', '#btn_delete', function(e){ $s.s20f007._delete(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s20f007._ctrlEditView(this); });

	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};
s20f007_util.prototype._selTr = function(el) {
	var edit = $(el).find("[name=a_edit]");
	if (edit.length > 0) {
		$s.s20f007._ctrlEditView(edit[0]);
	}
};
/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f007_util.prototype._ctrlEditView = function(el) {
	// 入力情報クリア
	$s.com.inputClear($("#div_working_edit"));
    if (el.name == "a_add") {
        // 新規モード
    	$s.s20f007.mode = "create";
    	$("#workingDate").val($s.dat.fmt("YYYY-MM-DD", $s.dat.sysDate));
    	$("#workingTimeStart").val("09:00");
    	$("#workingTimeEnd").val("18:00");
    } else if (el.name == "a_edit") {
        // 編集モード
    	$s.s20f007.mode = "edit";
        // 対象従業員の稼働情報取得
        this._details(el);
    } else if (el.name == "btn_return") {
    	$s.s20f007.mode = "list";
        $s.s20f007._search();
    }

    // 表示制御
    if ($s.s20f007.mode == "list") {
        $("#btn_new").css("display","");
        $("#div_working_data").css("display","block");
        $("#div_conditions").css("display","block");
        $("#div_working_edit").css("display","none");
        $("#h_title").text("作業一覧");
    } else {
    	$("#btn_new").css("display","none");
        $("#div_working_data").css("display","none");
        $("#div_conditions").css("display","none");
        $("#div_working_edit").css("display","block");
        $("#h_title").text("作業情報");
    }
};
/**
 * 作業一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s20f007_util.prototype._search = function(el) {
	var send_data = { workingMonth : $("#conditions").val() };
	var callback = {
		done : function(data,status,xhr){
			if (data.tbl_working_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            // 取得データ設定
            $s.com.set_val($("#div_working_info_edit"), data);
            if ($s._objs.canEdit == false) {
                $s.com.view_mode($("#div_working_info_edit")[0]);
            }
        }
	};
    $s.com.ajax("GET", "_search", send_data, callback);
};

/**
 * 作業詳細情報取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f007_util.prototype._details = function(el) {
	var workingDate = $(el).closest("tr").find("[data-db-key=workingDate]").text().replace("/","-");
	workingDate = workingDate.replace("/","-");
    // 送信データオブジェクト初期化
    var send_data = {
    		workingDate : workingDate
    };
    // 成功時のコールバック
    var callback = {
        done : function(data, status, xhr){
            // 取得データ設定
            $s.com.set_val($("#tbl_working_info"), data.tbl_working_info);
        }
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 作業情報登録更新.
 * */
s20f007_util.prototype._update = function(el) {
	var educCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) educCheckList[educCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(educCheckList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_working_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s20f007._search();
                    $s.s20f007._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_update", send_data, callback);
	}
    $s.apply._showPopup(opt);
};
/**
 * 作業情報削除.
 * */
s20f007_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"削除します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
        var send_data = {
				workingDate:$("table#tbl_working_info [data-db-key=workingDate]").val()
		};
        var callback = {
            done : function(data, status, xhr){
                if (data.msg) {
                    $s.s20f007._search();
                    $s.s20f007._ctrlEditView($("#btn_return")[0]);
                }
            }
        };
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

