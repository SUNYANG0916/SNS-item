/*************************
 * s00f101-部署要員管理
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f101 = new s00f101_util();
        $("#h_title").text("社員管理");
        // 一覧初期表示
        $s.s00f101._search();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f101_util = function(){
    if ((this instanceof s00f101_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
};

/**
 * イベントの初期化
 * */
s00f101_util.prototype.event_init = function(e) {
    // クリック_検索ボタン
    $('#btn_search').on('click', function(e){ $s.s00f101._search(this); });

    // クリック_詳細アイコンリンク
    $(document).on('click', '[name=a_working]', function(e){ $s.s00f101._userDetial(this); });


};
/**
 * イベント_メニューオープン
 * */
s00f101_util.prototype._userDetial = function(el) {
	var applyId = $(el).closest("tr").find("[data-db-key=apply_id]").val();
	var userRow = $(el).closest("tr").find("[data-db-key=user_row]").val();
	location.href=$s.context + "/user/apply?applyId=" + applyId + "&userRow=" + userRow + "&rtnApply=" + "s00f101";
};


/**
 * ユーザ一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s00f101_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var ajaxOpt = $s.com.ajaxObj("GET", "_search", {conditions:$("#conditions").val()});
	ajaxOpt.success = function(data, status, xhr){
		if (data.tbl_user_list.length == 0 && el) {
			setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
		}
        $s.com.set_val($("#div_user_info"), data);
	    $("table#tbl_user_list input:hidden").each(function(index, el){
	    	if ($(el).val() == "1") {
	    		$(el).next("a").css("display","");
	    	}
	    });
	    // モバイル画面の場合、スキル一覧出力しない
    	if ($s.com.clientType == "sp") {
    	    $("table#tbl_user_list tr").each(function(index, tr){
    	    	$(tr).find("th:last,td:last").css("display","none");
    	    });
    	}
    }
    // 送信データオブジェクト初期化
    $.ajax(ajaxOpt);
};
