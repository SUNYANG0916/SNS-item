//作成日時：2019/07/13 21:20:24
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_emp_info_edit",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",id:"div_emp_edit",elems:[
  {tag:"table",id:"tbl_emp_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:35%;",colSpan:"2",elems:[
      {tag:"label",text:"入社年月日",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:70%;",elems:[
      {tag:"input",type:"date","data-db-key":"nyusyaYmd",id:"nyusyaYmd",name:"nyusyaYmd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"userCd",id:"userCd",name:"userCd"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"部署名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"busyoCd",id:"selBusyoCd",name:"selBusyoCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"役職名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"yakusyokuKbn",id:"selYakusyokuKbn",name:"selYakusyokuKbn",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",style:"width:15%;",rowSpan:"6",elems:[
      {tag:"label",text:"氏名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:20%;",elems:[
      {tag:"label",text:"姓（漢字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kanjiSei",name:"kanjiSei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"山田"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"名（漢字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kanjiMei",name:"kanjiMei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"太郎"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"姓（カナ）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kanaSei",name:"kanaSei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"ヤマダ"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"名（カナ）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kanaMei",name:"kanaMei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"タロウ"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"姓（英字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"eijiSei",name:"eijiSei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"Yamada"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"名（英字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"eijiMei",name:"eijiMei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"Taro"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"生年月日",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"date","data-db-key":"seinentukihiYmd",name:"seinentukihiYmd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"性別",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"男",for:"seibetuKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"seibetuKbn",id:"seibetuKbn_1",name:"seibetuKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"女",for:"seibetuKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"seibetuKbn",id:"seibetuKbn_2",name:"seibetuKbn",value:"2",className:"radio"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"血液型",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"Ａ",for:"ketuekigataKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"ketuekigataKbn",id:"ketuekigataKbn_1",name:"ketuekigataKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"Ｂ",for:"ketuekigataKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"ketuekigataKbn",id:"ketuekigataKbn_2",name:"ketuekigataKbn",value:"2",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ,{tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"ＡＢ",for:"ketuekigataKbn_3",elems:[
         {tag:"input",type:"radio","data-db-key":"ketuekigataKbn",id:"ketuekigataKbn_3",name:"ketuekigataKbn",value:"3",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"Ｏ",for:"ketuekigataKbn_4",elems:[
         {tag:"input",type:"radio","data-db-key":"ketuekigataKbn",id:"ketuekigataKbn_4",name:"ketuekigataKbn",value:"4",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"国籍",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"日本",for:"kokusekiKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"kokusekiKbn",id:"kokusekiKbn_1",name:"kokusekiKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"外国",for:"kokusekiKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"kokusekiKbn",id:"kokusekiKbn_2",name:"kokusekiKbn",value:"2",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"婚姻状況",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"未婚",for:"konyinKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"konyinKbn",id:"konyinKbn_1",name:"konyinKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"既婚",for:"konyinKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"konyinKbn",id:"konyinKbn_2",name:"konyinKbn",value:"2",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"3",elems:[
      {tag:"label",text:"子供生年月日",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"１人目",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"date","data-db-key":"kodomo1Ymd",id:"kodomo1Ymd",name:"kodomo1Ymd"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"２人目",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"date","data-db-key":"kodomo2Ymd",id:"kodomo2Ymd",name:"kodomo2Ymd"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"３人目",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"date","data-db-key":"kodomo3Ymd",id:"kodomo3Ymd",name:"kodomo3Ymd"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"4",elems:[
      {tag:"label",text:"住所",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"郵便番号",id:"a_post",name:"a_post",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-b",elems:[
       {tag:"div",className:"ui-block-a",style:"width:calc(100% - 40px);",elems:[
        {tag:"input",type:"text","data-db-key":"postNo",name:"postNo",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"110-0010"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:40px;",elems:[
        {tag:"a",id:"a_post",name:"a_post",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"都道府県",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"todofukenCd",name:"todofukenCd",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"東京都"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"市区郡以降",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"shikuchoson",name:"shikuchoson",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"千代田区東神田２－２－１"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ビル名／部屋番号",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"birumei",name:"birumei",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"NMビル２F"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"2",elems:[
      {tag:"label",text:"最寄駅",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"沿線",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"ensenCd",name:"ensenCd",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"JR山手線"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"駅名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"eki",name:"eki",style:"width:100%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"秋葉原駅"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"2",elems:[
      {tag:"label",text:"メール",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"社内",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"email","data-db-key":"mail",name:"mail",style:"width:100%;",placeholder:"taro.yamada@snssoft.co.jp"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"個人",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"email","data-db-key":"maiKojinl",name:"maiKojinl",style:"width:100%;",placeholder:"g.yamada@gmail.com"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"2",elems:[
      {tag:"label",text:"電話",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"固定",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"tel","data-db-key":"telKotei",name:"telKotei",placeholder:"03-5817-8244"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"携帯",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"tel","data-db-key":"telKeitai",name:"telKeitai",placeholder:"090-1122-2233"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"8",elems:[
      {tag:"label",text:"プロジェクト関連",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"希望通勤時間（H）",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"tukinJikan",name:"tukinJikan",placeholder:"1"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"日本語資格",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-b",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"N1",for:"sikakuNihongoKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"sikakuNihongoKbn",id:"sikakuNihongoKbn_1",name:"sikakuNihongoKbn",value:"1",className:"radio"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"N2",for:"sikakuNihongoKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"sikakuNihongoKbn",id:"sikakuNihongoKbn_2",name:"sikakuNihongoKbn",value:"2",className:"radio"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-c",elems:[
        {tag:"label",text:"N3",for:"sikakuNihongoKbn_3",elems:[
         {tag:"input",type:"radio","data-db-key":"sikakuNihongoKbn",id:"sikakuNihongoKbn_3",name:"sikakuNihongoKbn",value:"3",className:"radio"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"TOEIC/TOEFL",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"number","data-db-key":"toeic",name:"toeic",placeholder:"910"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"得意技術",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"tokuiGijutuDisp",name:"tokui_gijutu_disp",className:"list_disp"}
     ,{tag:"ul",id:"tokui_gijutu_list",name:"tokui_gijutu_list",style:"display:none;",list_id:"tokui_gijutu_list",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"tokuiGijutuName",name:"tokuiGijutuName",for:"tokuiGijutuCd",elems:[
         {tag:"input",type:"radio","data-db-key":"tokuiGijutuCd",id:"tokuiGijutuCd",name:"tokuiGijutuCd",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"得意工程",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"tokuiKoteiDisp",name:"tokui_kotei_disp",className:"list_disp"}
     ,{tag:"ul",id:"tokui_kotei_list",name:"tokui_kotei_list",style:"display:none;",list_id:"tokui_kotei_list",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"tokuiKoteiName",name:"tokuiKoteiName",for:"tokuiKoteiCd",elems:[
         {tag:"input",type:"radio","data-db-key":"tokuiKoteiCd",id:"tokuiKoteiCd",name:"tokuiKoteiCd",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"自己アピール",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"jikoPr",name:"jikoPr",style:"width:100%;height:100%;",validate:"{\"rules\":{\"minlength\":200},\"message\":{\"minlength\":\"200文字以上入力してください。\"}}",placeholder:"PG/SEとして8年目になります。２年目からはチームリーダー、３年目からはプロジェクトマネジャーを担当しました。プログラマーとしては様々な実務経験を通して、CやJava、PHP、Perlなど数多くの開発言語に対応可能です。上流工程から下流工程、導入・運用にいたるまで、システム開発・運用の全般に携わってきました。"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"出張可否（国内）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"可",for:"syuchoKokunaiKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"syuchoKokunaiKbn",id:"syuchoKokunaiKbn_1",name:"syuchoKokunaiKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"否",for:"syuchoKokunaiKbn_2",className:"radio",elems:[
         {tag:"input",type:"radio","data-db-key":"syuchoKokunaiKbn",id:"syuchoKokunaiKbn_2",name:"syuchoKokunaiKbn",value:"2",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"出張可否（海外）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"可",for:"syuchoKaigaiKbn_1",elems:[
         {tag:"input",type:"radio","data-db-key":"syuchoKaigaiKbn",id:"syuchoKaigaiKbn_1",name:"syuchoKaigaiKbn",value:"1",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"否",for:"syuchoKaigaiKbn_2",elems:[
         {tag:"input",type:"radio","data-db-key":"syuchoKaigaiKbn",id:"syuchoKaigaiKbn_2",name:"syuchoKaigaiKbn",value:"2",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"興味／趣味",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"kyomiSyumi",name:"kyomiSyumi",style:"width:100%;",placeholder:"スキューバダイビング、水泳、バッティングセンター、フットサル"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"5",elems:[
      {tag:"label",text:"緊急連絡先",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"関係",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kinkyuKankeiKbn",name:"kinkyuKankeiKbn",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"親／妻／親友／親戚"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"氏名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"kinkyuShimei",name:"kinkyuShimei",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"山田　次郎"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"メールアドレス",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"email","data-db-key":"kinkyuMail",name:"kinkyuMail",placeholder:"ji.yamada@rakuten.com"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"固定電話",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"tel","data-db-key":"kinkyuTelKotei",id:"kinkyuTelKotei",name:"kinkyuTelKotei",placeholder:"03-0123-4567"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"携帯電話",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"tel","data-db-key":"kinkyuTelKeitai",id:"kinkyuTelKeitai",name:"kinkyuTelKeitai",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"080-5555-6666"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",elems:[
  {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
 ]}
]}
];

