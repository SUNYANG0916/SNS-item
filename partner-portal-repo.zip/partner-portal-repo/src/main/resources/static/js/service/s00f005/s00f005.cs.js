/*************************
 * S00F005-項目マスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f005 = new s00f005_util();
        $("#h_title").text("項目マスタ");
        // 一覧初期表示
        $s.s00f005._search();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f005_util = function(){
    if ((this instanceof s00f005_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_item_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s00f005_util.prototype.event_init = function(e) {
    // クリック_検索ボタン
    $('#btn_search').on('click', function(e){ $s.s00f005._search(this); });
    // クリック_新規リンク
    $("#btn_new").on('click', function(e){ $s.s00f005._ctrlEditView(this); });
    // クリック_一覧へ戻るリンク
    $("#btn_return").on('click', function(e){ $s.s00f005._ctrlEditView(this); });
    // クリック_更新ボタン
    $("#btn_update").on('click', function(e){ $s.s00f005._update(this); });

    $(document).on("click", ".btn_row_add", function(e){
    	setTimeout(function() {
    		$("#tbl_item_list tBody tr:last").find(".btn_row_del").css("display","");
    		$("#tbl_item_list tBody tr:last").find("[data-db-key=itemSort]").val(0);
    		$("#tbl_item_list tBody tr:last").find("[data-db-key=itemType]").val($("#tbl_item_type_info").find("[data-db-key=itemType]").text());
    	}, 100);
    });

    // クリック_編集リンク
    $(document).on('click', '[name=a_edit]', function(e){ $s.s00f005._ctrlEditView(this); });
    // クリック_詳細アイコンリンク
    $(document).on('click', '.document_16', function(e){ $s.s00f005._userDetial(this); });
    // クリック_スキルシートダウンロードアイコンリンク
    $(document).on('click', '.file_excel_16', function(e){ $s.s00f005._skillDownload(this); });
};

/**
 * 項目一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s00f005_util.prototype._search = function(el) {

	$s.com.ajax("GET", "_search", {conditions:$("#conditions").val()},
		{
			done : function(data,status,xhr){
            // 取得データ設定
	            $s.com.set_val($("#div_item_type_info"), data);
	        }
	});
};

/**
 * 項目詳細情報取得
 *
 * @param el イベント発火エレメント
 *  */
s00f005_util.prototype._details = function(el) {

	var itemType = $(el).closest("tr").find("[data-db-key=itemType]").text();
	var itemTypeName = $(el).closest("tr").find("[data-db-key=itemTypeName]").text();
	$("#tbl_item_type_info").find("[data-db-key=itemType]").text(itemType);
	$("#tbl_item_type_info").find("[data-db-key=itemTypeName]").text(itemTypeName);
	$s.com.ajax("GET", "_details", {itemType:itemType},
			{
				done : function(data,status,xhr){
	            // 取得データ設定
					$s.com.set_val($("#div_item_edit"), data);
		        }
		});
};

/**
 * 項目マスタ情報登録更新
 *
 * @param el イベント発火エレメント
 *  */
s00f005_util.prototype._update = function(el) {
	var empCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) empCheckList[empCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(empCheckList, "#applycationForm") == true) {
	    // 送信データオブジェクト初期化
	    var send_data = [];
	    $("table#tbl_item_list tBody tr").each(function(index, tr){
	    	var item = {};
	    	$(tr).find("[data-db-key]").each(function(i, el){
	    		$s.com.getSendData(item, el);
	    	});
	    	send_data[send_data.length] = item;
	    });
		$s.com.ajax("POST", "_update", send_data, {
			done : function(data,status,xhr){
	            // 取得データ設定
				$s.s00f005._ctrlEditView($("#btn_return")[0]);
		    }
		});
	} else {
		$s.apply._showInputErrPopup();
	}
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s00f005_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
	// 入力情報クリア
	$s.com.inputClear($("table#tbl_item_info"));
    if (el.id == "btn_new") {
        // 新規モード
        isShowEdit = true;
    } else if (el.id == "a_edit") {
        // 編集モード
        isShowEdit = true;
        // 対象ユーザ情報取得
        this._details(el);
    } else if (el.id == "btn_return") {
        // 一覧表示
        isShowEdit = false;
    }

    // 表示制御
    if (isShowEdit == true) {
        $("#h_title").text("項目分類詳細");
        $("#div_item_type_list").css("display","none");
        $("#div_item_type_edit").css("display","block");
        $("#conditions").closest("div").css("display","none");
        $("#div_item_type_info").css("display","none");
        $("#btn_search").css("display","none");
        $("#btn_new").css("display","none");
        $("#btn_return").css("display","");
    } else {
        $("#h_title").text("項目分類一覧");
    	$("#div_item_type_list").css("display","block");
        $("#div_item_type_edit").css("display","none");
        $("#conditions").closest("div").css("display","");
        $("#div_item_type_info").css("display","");
        $("#btn_search").css("display","");
        $("#btn_new").css("display","");
        $("#btn_return").css("display","none");
    }
};
