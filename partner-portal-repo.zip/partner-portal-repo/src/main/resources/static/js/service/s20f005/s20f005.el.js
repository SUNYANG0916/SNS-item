//作成日時：2019/07/07 13:00:10
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_skill",className:"sa-form-container",elems:[
 {tag:"div",className:"ui-grid-a",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;","data-role":"navbar",elems:[
   {tag:"h3",text:"スキルシート",id:"btn_dl",name:"btn_dl",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;text-align: center; cursor: pointer; text-decoration: underline; color: blue; display: block;"}
  ,{tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"display:none;padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_rtn_list",name:"a_rtn_list",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",id:"div_skill_list",elems:[
  {tag:"table",id:"tbl_skill_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_skill_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:40px;",elems:[
      {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"案件名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:100px;",elems:[
      {tag:"label",text:"開始年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:100px;",elems:[
      {tag:"label",text:"終了年月",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
     {tag:"td",style:"text-align:center;",elems:[
      {tag:"a",id:"a_edit",name:"a_edit",style:"font-size: 12px;",elems:[
       {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
      ]}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"ankenMei",name:"ankenMei",style:"font-size: 12px;"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"kaisiYm",name:"kaisiYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"syuryoYm",name:"syuryoYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_skill_edit",style:"display:none;margin:auto;",elems:[
  {tag:"table",id:"tbl_skill_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:10%;",rowSpan:"6",elems:[
      {tag:"label",text:"案件",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:15%;",elems:[
      {tag:"label",text:"案件名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:75%;",elems:[
      {tag:"input",type:"text","data-db-key":"ankenMei",name:"ankenMei",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"開始年月",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"kaisiYm",name:"kaisiYm",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"終了年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"syuryoYm",name:"syuryoYm"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"規模",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"ul",id:"list_kibo",name:"list_kibo",list_id:"list_kibo",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"kiboName",name:"kiboName",for:"kibo",elems:[
         {tag:"input",type:"radio","data-db-key":"kibo",id:"kibo",name:"kibo",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"作業場所",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label",text:"１．日本",for:"sagyoBasyo_1",elems:[
       {tag:"input",type:"radio","data-db-key":"sagyoBasyo",id:"sagyoBasyo_1",name:"sagyoBasyo",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"1"}
      ]}
     ,{tag:"label",text:"２．外国",for:"sagyoBasyo_2",elems:[
       {tag:"input",type:"radio","data-db-key":"sagyoBasyo",id:"sagyoBasyo_2",name:"sagyoBasyo",value:"2"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"役割",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"yakuwariKbn",name:"selYakuwariKbn",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"業界",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"gyokaiDisp",name:"list_gyokai_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_gyokai",name:"list_gyokai",style:"display:none;",list_id:"list_gyokai",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"gyokaiName",name:"gyokaiName",for:"gyokaiCd",elems:[
         {tag:"input",type:"radio","data-db-key":"gyokaiCd",id:"gyokaiCd",name:"gyokaiCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",colSpan:"2",elems:[
      {tag:"label",text:"工程",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"koteiDisp",name:"list_kotei_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_kotei",name:"list_kotei",style:"display:none;",list_id:"list_kotei",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"koteiName",name:"koteiName",for:"koteiCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"koteiCd",id:"koteiCd",name:"koteiCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"3",elems:[
      {tag:"label",text:"OS/DB/ミドルウェア",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"ＯＳ",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"osDisp",name:"list_os_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_os",name:"list_os",style:"display:none;",list_id:"list_os",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"osName",name:"osName",for:"osCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"osCd",id:"osCd",name:"osCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ＤＢ",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"dbDisp",name:"list_db_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_db",name:"list_db",style:"display:none;",list_id:"list_db",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"dbName",name:"dbName",for:"dbCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"dbCd",id:"dbCd",name:"dbCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ミドルウェア",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"midoruweaDisp",name:"list_midoruwea_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_midoruwea",name:"list_midoruwea",style:"display:none;",list_id:"list_midoruwea",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"midoruweaName",name:"midoruweaName",for:"midoruweaCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"midoruweaCd",id:"midoruweaCd",name:"midoruweaCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"3",elems:[
      {tag:"label",text:"開発言語／フレームワーク",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"プログラム言語",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"midoruweaDisp",name:"list_program_gengo_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_program_gengo",name:"list_program_gengo",style:"display:none;",list_id:"list_program_gengo",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"programGengoName",name:"programGengoName",for:"programGengoCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"programGengoCd",id:"programGengoCd",name:"programGengoCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"JavaScriptライブラリ",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"javaLibDisp",name:"list_java_lib_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_java_lib",name:"list_java_lib",style:"display:none;",list_id:"list_java_lib",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"javaLibName",name:"javaLibName",for:"javaLibCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"javaLibCd",id:"javaLibCd",name:"javaLibCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"フレームワーク",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"frameworkDisp",name:"list_framework_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_framework",name:"list_framework",style:"display:none;",list_id:"list_framework",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"frameworkName",name:"frameworkName",for:"frameworkCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"frameworkCd",id:"frameworkCd",name:"frameworkCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"4",elems:[
      {tag:"label",text:"ツール",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"開発",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"toolKaihatuDisp",name:"list_tool_kaihatu_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_tool_kaihatu",name:"list_tool_kaihatu",style:"display:none;",list_id:"list_tool_kaihatu",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"toolKaihatuName",name:"toolKaihatuName",for:"toolKaihatuCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"toolKaihatuCd",id:"toolKaihatuCd",name:"toolKaihatuCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"クラウド",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"toolCloudDisp",name:"list_tool_cloud_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_tool_cloud",name:"list_tool_cloud",style:"display:none;",list_id:"list_tool_cloud",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"toolCloudName",name:"toolCloudName",for:"toolCloudCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"toolCloudCd",id:"toolCloudCd",name:"toolCloudCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ユーティリティ",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"toolUtilityDisp",name:"list_tool_utility_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_tool_utility",name:"list_tool_utility",style:"display:none;",list_id:"list_tool_utility",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"toolUtilityName",name:"toolUtilityName",for:"toolUtilityCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"toolUtilityCd",id:"toolUtilityCd",name:"toolUtilityCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ビジネス",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"toolBisinesuDisp",name:"list_tool_bisinesu_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_tool_bisinesu",name:"list_tool_bisinesu",style:"display:none;",list_id:"list_tool_bisinesu",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"toolBisinesuName",name:"toolBisinesuName",for:"toolBisinesuCd",elems:[
         {tag:"input",type:"checkbox","data-db-key":"toolBisinesuCd",id:"toolBisinesuCd",name:"toolBisinesuCd",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",rowSpan:"2",elems:[
      {tag:"label",text:"活躍／感想",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"感想",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"a","data-db-key":"annkenKansouDisp",name:"list_annken_kansou_disp",className:"list_disp"}
     ,{tag:"ul",id:"list_annken_kansou",name:"list_annken_kansou",style:"display:none;",list_id:"list_annken_kansou",elems:[
       {tag:"li",elems:[
        {tag:"label","data-db-key":"annkenKansouName",name:"annkenKansouName",for:"annkenKansou",elems:[
         {tag:"input",type:"checkbox","data-db-key":"annkenKansou",id:"annkenKansou",name:"annkenKansou",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"作業内容",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"annkenSagyoSyosai",name:"annkenSagyoSyosai",style:"width:95%;",validate:"{\"rules\":{\"minlength\":30},\"message\":{\"minlength\":\"30文字以上入力してください。\"}}"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-b",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"削除",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-c",elems:[
    {tag:"a",text:"戻る",id:"btn_return",name:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
];

