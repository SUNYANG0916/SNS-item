/*************************
 * S00F004-アカウントマスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f004 = new s00f004_util();
        $("#h_title").text("社員管理");
        // 一覧初期表示
        $s.s00f004._search();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f004_util = function(){
    if ((this instanceof s00f004_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_user_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s00f004_util.prototype.event_init = function(e) {
	try {
		$("#h_title").on('click', function(e){ $s.s00f004._ctrlEditView(this); });
	    // クリック_検索ボタン
	    $('#btn_search').on('click', function(e){ $s.s00f004._search(this); });
	    // クリック_新規リンク
	    $("#a_add").on('click', function(e){ $s.s00f004._ctrlEditView(this); });
	    // クリック_一覧へ戻るリンク
	    $("#btn_return").on('click', function(e){ $s.s00f004._ctrlEditView(this); });
	    // クリック_更新ボタン
	    $("#btn_update").on('click', function(e){ $s.s00f004._update(this); });
	    // クリック_削除ボタン
	    $("#btn_delete").on('click', function(e){ $s.s00f004._delete(this); });

	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s00f004._ctrlEditView(this); });
	    // クリック_詳細アイコンリンク
	    $(document).on('click', '.document_16', function(e){ $s.s00f004._userDetial(this); });
	    // クリック_スキルシートダウンロードアイコンリンク
	    $(document).on('click', '.file_excel_16', function(e){ $s.s00f004._skillDownload(this); });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};

/**
 * ユーザ一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s00f004_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var ajaxOpt = $s.com.ajaxObj("GET", "_search", {conditions:$("#conditions").val()});
	ajaxOpt.success = function(data, status, xhr){
		if (data.tbl_user_list.length == 0 && el) {
			setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
		}
        $s.com.set_val($("#div_user_info"), data);
	    $("table#tbl_user_list input:hidden").each(function(index, el){
	    	if ($(el).val() == "1") {
	    		$(el).next("a").css("display","");
	    	}
	    });
	    // モバイル画面の場合、スキル一覧出力しない
    	if ($s.com.clientType == "sp") {
    	    $("table#tbl_user_list tr").each(function(index, tr){
    	    	$(tr).find("th:last,td:last").css("display","none");
    	    });
    	}
    }
    // 送信データオブジェクト初期化
    $.ajax(ajaxOpt);
};

/**
 * ユーザ詳細情報取得
 *
 * @param el イベント発火エレメント
 *  */
s00f004_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {
    	userRow : $(el).closest("tr").find("[data-db-key=user_row]").val()
    };
	var callback = {
		done : function(data, status, xhr){
            $s.com.set_val($("#div_user_edit"), data.tbl_user_info);
            $s.com.set_val($("#tbl_role_info"), data);
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * ユーザ情報登録更新
 *
 * @param el イベント発火エレメント
 *  */
s00f004_util.prototype._update = function(el) {
	var empCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) empCheckList[empCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(empCheckList, "#applycationForm") == true) {
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
        	    var send_data = {};
        	    $("table#tbl_user_info [data-db-key]").each(function(index, el){
        	    	$s.com.getSendData(send_data, el);
        	    });
        		$s.com.ajax("POST", "_update", send_data, {
                	done : function(data, status, xhr){
                        $s.s00f004._search();
                        $s.s00f004._ctrlEditView($("#btn_return")[0]);
                	}
        		});
        	}
        };

		var send_detail = [];
		var $tr = $("table#tbl_role_list tBody tr");
		for(var i = 0; i < $tr.size(); i++) {
			send_detail[send_detail.length] = {
					userCd : $("#tbl_user_info").find("[name=userCd]").val() ,
					roleGrpId : $($tr[i]).find("[data-db-key=roleGrpId]").val()
			};
		}

	    $s.com.ajax("POST", "_updateUserRole", send_detail, callback);
	} else {
		$s.apply._showInputErrPopup();
	}
};
/**
 * ユーザ情報削除.
 * */
s00f004_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"削除します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    var send_data = {};
	    $("table#tbl_user_info [data-db-key]").each(function(index, el){
	    	$s.com.getSendData(send_data, el);
	    });
        var callback = {
            done : function(data, status, xhr){
        		$s.com.ajax("POST", "_delete", send_data, {
                	done : function(data, status, xhr){
                        if (data.msg) {
                            $s.s00f004._search();
                            $s.s00f004._ctrlEditView($("#btn_return")[0]);
                        }
                	}
        		});
            }
        };
	    $s.com.ajax("POST", "_deleteUserRole", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s00f004_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
	// 入力情報クリア
	$s.com.inputClear($("table#tbl_user_info"));
    if (el.id == "a_add") {
        // 新規モード
        isShowEdit = true;
        $("input#userCd").attr("readonly", false);
        $("#tbl_role_list")[0].tBodies[0].innerHTML = "";
        $(".btn_row_add").click();
    } else if (el.id == "a_edit") {
        // 編集モード
        isShowEdit = true;
        // 対象ユーザ情報取得
        this._details(el);
        $("input#userCd").attr("readonly", true);
    } else if (el.id == "btn_return") {
        // 一覧表示
        isShowEdit = false;
    }

    // 表示制御
    if (isShowEdit == true) {
        $("#h_title").text("従業員詳細");
        $("#div_user_list").css("display","none");
        $("#div_user_edit").css("display","block");
        $("#div_conditions").css("display","none");
        $("#btn_search").css("display","none");
        $("#btn_return").css("display","");
    } else {
        $("#h_title").text("従業員一覧");
    	$("#div_user_list").css("display","block");
        $("#div_user_edit").css("display","none");
        $("#div_conditions").css("display","");
        $("#btn_search").css("display","");
        $("#btn_return").css("display","none");
    }
};

/**
 * イベント_メニューオープン
 * */
s00f004_util.prototype._userDetial = function(el) {
	var applyId = "";
	var id = $(el).closest("a").attr("id");
	switch ( id ) {
        case "a_detail1": applyId = "s20f001"; break;
        case "a_detail2": applyId = "s20f002"; break;
        case "a_detail3": applyId = "s20f003"; break;
        case "a_detail4": applyId = "s20f004"; break;
        case "a_detail5": applyId = "s20f005"; break;
        case "a_detail8": applyId = "s10f003"; break;
        case "a_detail9": applyId = "s20f007"; break;
        case "a_detail7": applyId = "s20f008"; break;
	}
	if (applyId != "") {
		var userRow = $(el).closest("tr").find("[data-db-key=user_row]").val();
	    location.href=$s.context + "/user/apply?applyId=" + applyId + "&userRow=" + userRow;
	}
};

/**
 * イベント_スキル帳票ダウンロード
 * */
s00f004_util.prototype._skillDownload = function(el) {
	var applyId = "";
	var userRow = $(el).closest("tr").find("[data-db-key=user_row]").val();
    var userInitial = $(el).closest("tr").find("[data-db-key=user_initial]").val();
    jQuery.mobile.loading('show');
	var xhr = new XMLHttpRequest();
	xhr.open("GET", $s.context + "/user/download?userRow=" + userRow, true);
	xhr.responseType = 'arraybuffer';
	xhr.onload = function(e) {
		if (xhr.status === 200) {
			var downloadData = new Blob([ this.response ], {
				type : 'application/vnd.ms-excel'
			});
			var filename = "スキルシート（" + userInitial + "）.xlsx";
			if (window.navigator.msSaveBlob) {
				window.navigator.msSaveBlob(downloadData, filename); // IE用
			} else {
				var downloadUrl = (window.URL || window.webkitURL)
						.createObjectURL(downloadData);
				if ($s.com.clientType == "sp") {
					var _url = $s.context + "/js/report/" + filename;
					window.open(_url, '_self');
					} else {
					var link = document.createElement('a');
					link.href = downloadUrl;
					link.download = filename;
					link.click();
				}
			}
		} else {
			var msg = "エラー発生しました。（" + xhr.status + "）";
			var html = "";
			try {
				html = xhr.responseText;
			} catch (e) {
			}
			setTimeout($s.apply._showPopup({
				title : "メッセージ",
				msg : msg,
				html : html,
				type : "エラー発生"
			}), 200);
		}
		jQuery.mobile.loading('hide');

	};
	xhr.send();

};
