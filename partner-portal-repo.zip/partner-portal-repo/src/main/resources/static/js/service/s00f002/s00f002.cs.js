/*************************
 * S00F002-ロールマスタ
 * 初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f002 = new s00f002_util();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f002_util = function(){
    if ((this instanceof s00f002_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    // 一覧初期化
    $("#tbl_role_list").get(0).tBodies[0].innerHTML = "";
    // デフォルトチェック
    $("#inp_cond_flg").prop("checked",true);
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_pass_edit")[0]);
    }
};
/**
 * イベントの初期化
 * */
s00f002_util.prototype.event_init = function(e) {
    // クリック_検索ボタン
    $('#btn_search').on('click', function(e){ $s.s00f002._search(this); });
    // クリック_新規リンク
    $("#btn_new").on('click', function(e){ $s.s00f002._ctrlEditView(this); });
    // クリック_一覧へ戻るリンク
    $("#btn_list").on('click', function(e){ $s.s00f002._ctrlEditView(this); });
    // クリック_登録ボタン
    $("#btn_update").on('click', function(e){ $s.s00f002._update(this); });
    // クリック_削除ボタン
    $("#btn_delete").on('click', function(e){ $s.s00f002._delete(this); });
    // クリック_編集リンク
    $(document).on('click', '[name=a_edit]', function(e){ $s.s00f002._ctrlEditView(this); });
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s00f002_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
    if (el.id == "btn_new") {
        // 新規モード
        isShowEdit = true;

        $("#div_role_edit input[type!=button]").each(function(index) {
            $(this).val("").text("");
        });
    } else if (el.id == "a_edit") {
        // 編集モード
        isShowEdit = true;

        // 対象ロール情報取得
        this._getRoleInfo(el);
    } else if (el.id == "btn_list") {

    }

    // 表示制御
    if (isShowEdit == true) {
        $("#div_role_list").css("display","none");
        $("#div_role_edit").css("display","block");
        $("input#roleId").attr("readonly", true);
        $("input#roleId").addClass("imui-text-readonly");
        $("#h_title").text("ロール詳細");

        $("#btn_new").css("display","none");
        $("#btn_list").css("display","");
        $("#div_conditions").css("display","none");
    } else {
        $("input#roleId").attr("readonly", false);
        $("input#roleId").removeClass("imui-text-readonly");
        $("#div_role_list").css("display","block");
        $("#div_role_edit").css("display","none");
        $("#h_title").text("ロール一覧");

        $("#btn_new").css("display","");
        $("#btn_list").css("display","none");
        $("#div_conditions").css("display","");
    }
};

/**
 * ロール一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s00f002_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {fnc:"getRoleList", applyId:$s._objs.applyId};
    var send_data = {};
    send_data.cond = $("#cond").val();
    send_data.del_flag = $("#inp_cond_flg").prop("checked") == true ?"1":"0";
	var callback = {
		done : function(data, status, xhr){
            $s.com.set_val($("#div_role_info"), result);
		}
	};
    $s.com.ajax("GET", "getRoleList", send_data, callback);
};

/**
 * ロール情報詳細取得
 *
 * @param el イベント発火エレメント
 *  */
s00f002_util.prototype._getRoleInfo = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {fnc:"getRoleInfo", applyId:$s._objs.applyId};
    send_data.cond = $(el).closest("tr").find("#roleId").text();
	var callback = {
		done : function(data, status, xhr){
            // 取得データ設定
            $s.com.set_val($("#div_role_edit"), result);
        }
    };
    $s.com.ajax("GET", "getRoleInfo", send_data, callback);
};

/**
 * ロール登録更新
 *
 * @param el イベント発火エレメント
 *  */
s00f002_util.prototype._update = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {fnc:"updateRole", applyId:$s._objs.applyId};
    $("table#tbl_role_info [data-db-key]").each(function(index, el){
        if ($(el).attr("type") == "radio" && $(el).is(':checked')) {
        	send_data[$(el).attr("data-db-key")] = $(el).val();
        } else if ($(el).attr("type") == "checkbox" && $(el).is(':checked')) {
        	send_data[$(el).attr("data-db-key")] += $(el).val() + " ";
        } else if ($(el).attr("type") != "radio") {
        	send_data[$(el).attr("data-db-key")] = $(el).val();
        }
    });
    $s.com.ajax("POST", "getRoleInfo", send_data, {});
};
/**
 * ロール登録更新
 *
 * @param el イベント発火エレメント
 *  */
s00f002_util.prototype._delete = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {};
    $("table#tbl_role_info [data-db-key]").each(function(index, el){
        if ($(el).attr("type") == "radio" && $(el).is(':checked')) {
        	send_data[$(el).attr("data-db-key")] = $(el).val();
        } else if ($(el).attr("type") == "checkbox" && $(el).is(':checked')) {
        	send_data[$(el).attr("data-db-key")] += $(el).val() + " ";
        } else if ($(el).attr("type") != "radio") {
        	send_data[$(el).attr("data-db-key")] = $(el).val();
        }
    });
    $s.com.ajax("POST", "_delete", send_data, {});
};
