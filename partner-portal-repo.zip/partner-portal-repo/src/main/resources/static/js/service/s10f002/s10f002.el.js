//作成日時：2019/07/08 22:01:47
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_conditions",className:"sa-form-container",elems:[
 {tag:"div",id:"conditions",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(75% - 110px);",elems:[
   {tag:"input",type:"text",id:"cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:110px;padding-top:2px;",elems:[
   {tag:"select",id:"selDelete",name:"selDelete"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_suppliers_data",style:"margin-top:0px;",elems:[
 {tag:"table",id:"tbl_suppliers_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_suppliers_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:150px;",elems:[
     {tag:"label",text:"取引先名",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"代表者",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"電話",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"受発注送付先",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",style:"height:475px;",elems:[
   {tag:"tr","data-db-key":"selTr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",style:"font-size: 12px;",elems:[
      {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
     ]}
    ]}
   ,{tag:"td",style:"width:150px;",elems:[
     {tag:"label","data-db-key":"suppliersName",id:"suppliersName",name:"suppliersName",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"suppliersNo",id:"suppliersNo",name:"suppliersNo",style:"display:none;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"pepresentative",id:"pepresentative",name:"pepresentative",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"tel",id:"tel",name:"tel",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"zyuhacchuSouhusaki",id:"zyuhacchuSouhusaki",name:"zyuhacchuSouhusaki",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_suppliers_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
 {tag:"table",id:"tbl_suppliers_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",rowSpan:"14",elems:[
     {tag:"label",text:"基本情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"suppliersName",text:"取引先名",id:"suppliersName",name:"suppliersName",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersNo",id:"suppliersNo",name:"suppliersNo"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"取引期間",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",elems:[
       {tag:"label",text:"開始日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"startDate",id:"startDate",name:"startDate",placeholder:"開始日"}
      ]}
     ,{tag:"div",className:"ui-block-b",elems:[
       {tag:"label",text:"終了日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"endDate",id:"endDate",name:"endDate",placeholder:"終了日"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"取引状態",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"suppliersStatus",id:"selSuppliersStatus",name:"selSuppliersStatus"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表者",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"pepresentative",id:"pepresentative",name:"pepresentative",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"郵便番号",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:calc(100% - 40px);",elems:[
       {tag:"input",type:"text","data-db-key":"postalCode",name:"postalCode",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:40px;",elems:[
       {tag:"a",id:"a_post",name:"a_post",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"住所（都道府県）",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"address1",id:"address1",name:"address1",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"住所（市区町村）",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"address2",id:"address2",name:"address2",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"住所（番地以降）",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"address3",id:"address3",name:"address3",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ビル名／部屋",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"address4",id:"address4",name:"address4"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"最寄り駅",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"station",id:"station",name:"station",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表電話",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"tel",id:"tel",name:"tel",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表FAX",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"fax",id:"fax",name:"fax",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表メール",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"email","data-db-key":"mail",id:"mail",name:"mail",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"受発注送付先",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"ul",id:"zyuhacchu_souh_list",name:"zyuhacchu_souh_list",list_id:"zyuhacchu_souh_list",elems:[
      {tag:"li",elems:[
       {tag:"label","data-db-key":"zyuhacchuSouhName",name:"zyuhacchuSouhName",for:"zyuhacchuSouhusaki",elems:[
        {tag:"input",type:"radio","data-db-key":"zyuhacchuSouhusaki",id:"zyuhacchuSouhusaki",name:"zyuhacchuSouhusaki",style:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
       ]}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",rowSpan:"3",elems:[
     {tag:"label",text:"総務情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"総務担当",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"somuStaffName",id:"somuStaffName",name:"somuStaffName"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"総務担当TEL.",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"somuStaffTel",id:"somuStaffTel",name:"somuStaffTel"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"総務担当メール",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"email","data-db-key":"somuStaffMail",id:"somuStaffMail",name:"somuStaffMail"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",rowSpan:"3",elems:[
     {tag:"label",text:"営業情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"営業担当",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"salesStaffName",id:"salesStaffName",name:"salesStaffName"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"営業担当TEL.",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"salesStaffTel",id:"salesStaffTel",name:"salesStaffTel"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"営業担当メール",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"email","data-db-key":"salesStaffMail",id:"salesStaffMail",name:"salesStaffMail"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",rowSpan:"4",elems:[
     {tag:"label",text:"銀行情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"銀行コード",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:100px;",elems:[
       {tag:"input",type:"text","data-db-key":"ginkoCd",id:"ginkoCd",name:"ginkoCd",placeholder:"銀行コード"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 100px);",elems:[
       {tag:"input",type:"text","data-db-key":"ginkoMei",id:"ginkoMei",name:"ginkoMei",placeholder:"銀行名"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"支店",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:100px;",elems:[
       {tag:"input",type:"text","data-db-key":"shitenNo",id:"shitenNo",name:"shitenNo",placeholder:"支店番号"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 100px);",elems:[
       {tag:"input",type:"text","data-db-key":"shitenMei",id:"shitenMei",name:"shitenMei",placeholder:"支店名"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",rowSpan:"2",elems:[
     {tag:"label",text:"口座種別",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:100px;",elems:[
       {tag:"select","data-db-key":"kouzaType",id:"selKouzaType",name:"selKouzaType"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 100px);",elems:[
       {tag:"input",type:"text","data-db-key":"kouzaNo",id:"kouzaNo",name:"kouzaNo",placeholder:"口座番号"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"kouzaMei",id:"kouzaMei",name:"kouzaMei",placeholder:"口座名"}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-top:10px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"廃止",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",name:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"master_postal",style:"display:none;",elems:[
 {tag:"table",id:"tbl_postal_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_postal_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"郵便番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"住所",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selPostalTr",name:"selPostalTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_postal",name:"a_sel_postal",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"zipCd",name:"zipCd",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"todoufukenKanji",name:"todoufukenKanji",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"sikutyousonKanji",name:"sikutyousonKanji",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"tyouikiKanji",name:"tyouikiKanji",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
];

