//作成日時：2019/08/26 23:34:10
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_password_reminder",className:"sa-form-container-wide",elems:[
  {tag:"div",className:"sa-form-container-wide",style:"padding: 1em; color: #666666; background-color: #f7f7f7; border: 2px solid #ccc; border-radius: 8px;",elems:[
   {tag:"label",text:"パスワードを忘れた場合のパスワード再通知を行います。",style:"font-size: 12px;margin-bottom:20px;"}
  ,{tag:"label",text:"入社年月日と英字の姓名を入力し、【送 信】ボタンをクリックしてください。",style:"font-size: 12px;"}
  ,{tag:"label",text:"会社から付与されているメールアドレス宛に「パスワード再通知」を送信します。",style:"font-size: 12px;"}
  ,{tag:"label",text:"※ メールが送信されない場合は、管理者にお問い合わせ下さい。",style:"font-size: 12px;margin-top:20px;"}
  ]}
 ,{tag:"table",id:"tbl_password_reminder_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"入社年月日",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"date","data-db-key":"nyusyaYmd",id:"nyusyaYmd",name:"nyusyaYmd",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"姓（英字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"eijiSei",id:"eijiSei",name:"eijiSei",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"名（英字）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"eijiMei",id:"eijiMei",name:"eijiMei",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-a",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"送 信",id:"a_mail",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"ログインへ",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
];

