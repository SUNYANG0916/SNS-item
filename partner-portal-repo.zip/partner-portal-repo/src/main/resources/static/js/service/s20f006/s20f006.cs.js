/*************************
 * s20f006-スキル情報
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s20f006 = new s20f006_util();
        $("#h_title").text("個人情報保護");

        // 画面表示
        $s.s20f006._search();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f006_util = function(){
    if ((this instanceof s20f006_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    this.mode = "list";
};
/**
 * イベントの初期化
 * */
s20f006_util.prototype.event_init = function(e) {
    $(document).on('click', '#btn_new', function(e){ $s.s20f006._ctrlEditView(this);});
    // クリック_実施リンク
    $(document).on('click', '[name=a_exec]', function(e){ $s.s20f006._ctrlEditView(this); });
    // クリック_戻るリンク
    $(document).on('click', '#btn_list', function(e){ $s.s20f006._ctrlEditView(this); });
    // クリック_次へリンク
    $(document).on('click', '#btn_next', function(e){ $s.s20f006._ctrlEditView(this); });
    // クリック_前へリンク
    $(document).on('click', '#btn_back', function(e){ $s.s20f006._ctrlEditView(this); });
};

/**
 * スキル一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s20f006_util.prototype._search = function(el) {
    $s.com.ajax("GET", "_search", {}, {
		done : function(data,status,xhr){
            $s.com.set_val($("#div_question_info_edit"), data);
            var totalCnt = 0;
            var totalPoint = 0;
            var totalWrong = 0;
            $("#tbl_question_list tbody tr").each(function(index, el) {
            	var $tr = $(el).closest("tr");
            	if ($tr.find("[data-db-key=detailsCnt]").text() == "0") {
            		$tr.find("[name=a_exec]").css("display","none");
            	}
            	totalCnt += Number($tr.find("[data-db-key=detailsCnt]").text());
            	totalPoint += Number($tr.find("[data-db-key=point]").text());
            	totalWrong += Number($tr.find("[data-db-key=wrongCnt]").text());
            });
            $("#tbl_question_list tfoot").find("[data-db-key=totalCnt]").text(totalCnt);
            $("#tbl_question_list tfoot").find("[data-db-key=totalPoint]").text(totalPoint);
            $("#tbl_question_list tfoot").find("[data-db-key=totalWrong]").text(totalWrong);
		}
    });
};

/**
 * 質問詳細取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f006_util.prototype._details = function(el, questionId, detailsNo) {
	if (questionId == undefined) {
		var $tr = $(el).closest("tr");
		questionId = $tr.find("[data-db-key=questionId]").val();
		if (detailsNo == undefined) {
			detailsNo = "1";
			$("#div_question_info label[data-db-key=questionName]").text($tr.find("[data-db-key=questionName]").text());
			$("#div_question_info input[data-db-key=detailsCnt]").text($tr.find("[data-db-key=detailsCnt]").text());
		}
	}

    // 送信データオブジェクト初期化
    var send_data = {
    	questionId : questionId,
    	detailsNo : detailsNo
    };
	var callback = {
		done : function(data,status,xhr){
            // 取得データ設定
            $s.com.set_val($("#div_question_info"), data);
            $("#tbl_question_dtl_list tbody tr").each(function(index, elem) {
            	var $elem = $(elem);
            	var choicesType = $elem.find("[data-db-key=choicesType]").val();
        		var $choicesInfo = $elem.find("[data-db-key=choicesInfo]");
        		var questionId = $elem.find("[data-db-key=questionId]").val();
        		var detailsNo = $elem.find("[data-db-key=detailsNo]").val();
            	if (choicesType != "text") {
        			if (choicesType == "radio") {
                		$elem.find("input:" + choicesType).css("display", "block");
        				$elem.find(".radio").css("display", "block");
        			} else if (choicesType == "check")  {
                		$elem.find("input:" + choicesType).css("display", "block");
        				$elem.find(".check").css("display", "block");
        			} else if (choicesType == "view") {
        				var imgUrl = $s.context + "/images/question/" + questionId + "/" + questionId + "_" + detailsNo + ".JPG";
        				$elem.find("[name=choicesImg]")
        					.attr("src", imgUrl)
        					.css("display", "block")
        					.click(function(){
        						//クリック後の処理
        						window.open(imgUrl);
        					});
        			}
            		$choicesInfo.on('click',function(){
            			var tmp;
            			if (choicesType == "radio") {
            				tmp = $choicesInfo.closest("tr").find("[name=questionRadio]");
            				if (!tmp.prop('checked')) {
                    			$(tmp).prop('checked', true).checkboxradio('refresh');
            				}
            			} else if (choicesType == "check")  {
            				tmp = $choicesInfo.closest("tr").find("[name=questionCheck]");
                			$(tmp).prop('checked', !tmp.prop('checked')).checkboxradio('refresh');
            			}
            		});
            	} else {
            		$elem.find("textarea").css("display", "block");
            	}
            });
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 実施結果登録.
 *
 * @param el イベント発火エレメント
 *  */
s20f006_util.prototype._update = function(el, questionId, detailsNo, detailsCnt) {

    var send_data = {questionId : questionId, detailsNo : detailsNo};
    // 送信データ取得
	var status = false;
	$("table#tbl_question_dtl_list tbody tr").each(function(index, tr){
    	$s.com.getSendData(send_data, el);
    	var choicesType = $(tr).find("[data-db-key=choicesType]").val();
    	var choicesInfo = $(tr).find("[name=choicesInfo]").val();
    	var checkd = false;
    	if (choicesType == "radio") {
    		checkd = $(tr).find("[name=questionRadio]").prop("checked");
    	} else if (choicesType == "checkbox") {
    		checkd = $(tr).find("[name=questionCheck]").prop("checked");
    	} else {
        	send_data.commentary = choicesInfo;
    		if ( choicesInfo == "") {
    			status = false;
    		} else {
            	status = true;
    		}
        	return false;
    	}

		if ($(tr).find("[data-db-key=correct]").val() == "1" && checkd == true) {
			status = true;
        } else if ($(tr).find("[data-db-key=correct]").val() == "0" && checkd == false){
        	status = true;
        } else {
        	status = false;
        	return false;
        }
    });
	send_data.status = status;
	var callback = {
    	done : function(data, status, xhr){
    		if (detailsNo == detailsCnt) {
    			// 実施結果を表示
    			$s.s20f006.mode = "reslut";
    			$s.s20f006._results(el, $("#div_question_info").find("[data-db-key=questionId]").val());
    		} else {
        		// 次を表示
        		$s.s20f006._details(el
                		, questionId
                		, Number(detailsNo) + 1);
    		}
    	}
    };
    // 更新処理実施
    $s.com.ajax("POST", "_update", send_data, callback);
};

/**
 * 実施結果取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f006_util.prototype._results = function(el, questionId) {
	var questionName = $("#div_question_info label[data-db-key=questionName]").text() + "　実施結果";
	var detailsCnt = $("#div_question_info input[data-db-key=detailsCnt]").text();
	$("#div_question_result").find("[data-db-key=questionName]").text(questionName);
	$("#div_question_result").find("[data-db-key=detailsCnt]").text();
    // 送信データオブジェクト初期化
    var send_data = {
    	questionId : questionId
    };
	var callback = {
		done : function(data,status,xhr){
            // 取得データ設定
            $s.com.set_val($("#div_question_result"), data);
            $("#tbl_question_result_list tbody tr").each(function(index, elem) {
            	$(elem).find("[data-db-key=detailsTotal]").text(detailsCnt);
            	var status = $(elem).find("[data-db-key=status]");
            	if (status.text() == "不正解") {
            		status.css("color","red");
            	} else {
            		status.css("color","green");
            	}
            });
		}
    };
    $s.com.ajax("GET", "_results", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f006_util.prototype._ctrlEditView = function(el) {
	var detailsNo = $("#tbl_question_dtl_list").find("[data-db-key=detailsNo]").eq(0).text();
	var detailsCnt = $("#div_question_info").find("[data-db-key=detailsCnt]").text();
    if (el.name == "a_exec") {
        // 実施モード
    	$s.s20f006.mode = "exec";
        this._details(el);
    } else if (el.id == "btn_next") {
		// 回答更新
		this._update(el, $("#div_question_info").find("[data-db-key=questionId]").val(), detailsNo, detailsCnt);
        if (detailsCnt == detailsNo) {
            $s.s20f006.mode = "reslut";
        }
    } else if (el.id == "btn_back" && detailsNo != 1) {
        this._details(el
        		, $("#div_question_info").find("[data-db-key=questionId]").val()
        		, Number(detailsNo) - 1);
    } else if (el.id == "btn_list" || el.id == "btn_new") {
    	// 一覧再表示
    	$s.s20f006.mode = "list";
        $s.s20f006._search();
    }

    // 表示制御
    if ($s.s20f006.mode == "list") {
        $("#div_question_list").css("display","");
        $("#div_question_info").css("display","none");
        $("#div_question_result").css("display","none");
        $("#h_title").text("質問一覧");
    } else if ($s.s20f006.mode == "reslut") {
        $("#div_question_list").css("display","none");
        $("#div_question_info").css("display","none");
        $("#div_question_result").css("display","");
        $("#h_title").text("実施結果");
    } else {
        $("#div_question_list").css("display","none");
        $("#div_question_info").css("display","");
        $("#div_question_result").css("display","none");
        $("#h_title").text("質問回答実施");
    }
};
