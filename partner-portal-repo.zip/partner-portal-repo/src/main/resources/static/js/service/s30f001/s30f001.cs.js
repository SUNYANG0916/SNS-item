/*************************
 * S30F001-見積書マスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s30f001 = new s30f001_util();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s30f001_util = function(){
    if ((this instanceof s30f001_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    this.mode = "update";
    // 対象取引先
    this.suppliersTarget = {};
    // 対象プロジェクト
    this.projectTarget = {};
    // タイトル
    $("#h_title").text("見積書一覧");
    // イベント
    this.event_init();
    // 一覧初期化
    $("#tbl_estimate_list").get(0).tBodies[0].innerHTML = "";

    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_estimate_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s30f001_util.prototype.event_init = function(e) {

	$(document).on('click', '#h_title', function(e){ $s.s30f001._ctrlEditView(this); });
    // クリック_検索ボタン
	$(document).on('click', '#btn_search', function(e){ $s.s30f001._search(this); });
    // クリック_新規
    $(document).on('click', '[name=a_add]', function(e){ $s.s30f001._ctrlEditView(this); });
    // クリック_編集リンク
    $(document).on('click', '[name=a_edit]', function(e){ $s.s30f001._ctrlEditView(this); });
    // クリック_行選択
    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s30f001._selTr(e, this); });
    // クリック_登録・更新ボタン
    $(document).on('click', '#btn_update', function(e){ $s.s30f001._update(this); });
    // クリック_廃止リンク
    $(document).on('click', '#btn_delete', function(e){ $s.s30f001._delete(this); });
    // クリック_戻るボタン

    $(document).on('click', '#btn_return', function(e){ $s.s30f001._ctrlEditView(this); });
    // クリック_請求先取引先検索リンク
    $(document).on('click', '#aSuppliersTo', function(e){ $s.s30f001._master_suppliers(this); });
    // クリック_請求元取引先検索リンク
    $(document).on('click', '#aSuppliersFrom', function(e){ $s.s30f001._master_suppliers(this); });
    // クリック_取引先検索
    $(document).on("click", "[name=btn_master_suppliers_search]", function(e) {$s.s30f001._master_suppliers_search(this);});
    // クリック_取引先行選択
    $(document).on('click', '[data-db-key=selSuppliersTr]', function(e){ $s.s30f001._selSuppliersTr(this); });

    // クリック_住所（郵便番号）検索ボタン
    $(document).on("click", "#postalSearch", function(e){ $s.s30f001._master_address(this); });
    // クリック_住所一覧行選択
    $(document).on("click", "[data-db-key=selPostalTr]", function(e){ $s.s30f001._sel_address(this); });

    // クリック_金額再計算
    $(document).on('click', '#calculation', function(e){ $s.s30f001.calculation(this);});

};


s30f001_util.prototype.calculation = function(el) {
    var totalAmount = 0;
    $("table#tbl_working_list").find("[data-db-key=unitAmount]").each(function(index, el){
    	var unitAmount = $(el).val();
    	var quantity = $(el).closest("tr").find("[data-db-key=quantity]").val();
    	var amount = Number(unitAmount) * Number(quantity);
    	$(el).closest("tr").find("[data-db-key=amount]").text(amount);
    	totalAmount += Number(amount);
    });
    totalAmount = totalAmount * 0.08 + totalAmount;
    $("table#tbl_working_list").find("#amountTotal").text(totalAmount);
    return totalAmount;
};


s30f001_util.prototype._selTr = function(e, el) {
	if (e.target.name == "output") {
		// 請求書出力
		$s.s30f001._print($(el).find("#a_edit"));
	} else if (e.target.name == "output2") {
		// 請求書出力
		$s.s30f001._print2($(el).find("#a_edit"));
	} else if (e.target.name == "copy") {
		$s.s30f001._ctrlEditView(e.target);
	} else if (e.target.name == "a_edit") {
		$s.s30f001._ctrlEditView(e.target);
	}
};

/**
 * 見積書一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s30f001_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var send_data = {cond:$("#cond").val(),selDelete:$("#selDelete").val()};

	var callback = {
		done : function(data, status, xhr){
			if (data.tbl_estimate_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            $s.com.set_val($("#div_estimate_info"), data);
		}
    };
    $s.com.ajax("GET", "_search", send_data, callback);
};
/**
 * 見積書情報取得
 *
 * @param el イベント発火エレメント
 *  */
s30f001_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {estimateNo : $(el).closest("tr").find("[data-db-key=estimateNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#div_estimate_edit"), data.tbl_estimate_list);
			$s.com.set_val($("#div_estimate_edit"), {tbl_working_list : data.tbl_working_list});
			if ($s.s30f001.mode == "create") {
				$("#estimateNo").val("");
			}
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s30f001_util.prototype._ctrlEditView = function(el) {
    // プロジェクト情報クリア
    $s.com.inputClear($("table#tbl_estimate_info"));
    if (el.id == "a_edit") {
    	// 編集モード
        this.mode = "update";
        // 明細情報取得
        this._details(el);
        $("#btn_delete").css("display","");
    } else if (el.id == "a_add") {
    	// 新規モード
        this.mode = "create";
        // 明細情報クリア
        $("#tbl_working_list tbody").html("");
        // デフォルト請求元
        $s.s30f001._default_suppliers();
        // 開始日
        $("#periodS").val($s.dat.fmt("YYYY-MM-", new Date()) + "01");
        var sysDate = new Date();
        // 終了日
        var lastDate = new Date(sysDate.getFullYear(), sysDate.getMonth() + 1, 0);
        $("#periodE").val($s.dat.fmt("YYYY-MM-", new Date()) + lastDate.getDate());
        $("#btn_delete").css("display","none");
    } else if (el.name == "copy") {
    	// コピー新規モード
    	this.mode = "create";
        // 明細情報取得
    	this._details(el);
        $("#btn_delete").css("display","none");
    } else {
    	// 一覧表示
    	this.mode = "list";
    }

    // 表示制御
    if (this.mode == "create" || this.mode == "update") {
        $("#h_title").text("見積書詳細");
        $("#div_estimate_list").css("display","none");
        $("#div_estimate_edit").css("display","block");
        $("#div_estimate_data").css("display","none");
        $("#conditions").css("display","none");
    } else {
        $("#h_title").text("見積書一覧");
    	$("#div_estimate_list").css("display","block");
        $("#div_estimate_edit").css("display","none");
        $("#div_estimate_data").css("display","block");
        $("#conditions").css("display","");
    }
};


/**
 * 見積書情報登録更新
 * */
s30f001_util.prototype._update = function(el) {
	var educCheckList = [];

	var checkWorkingInfo = $("table#tbl_working_list [name=workingInfo]")[0];
	var checkQuantity = $("table#tbl_working_list [name=quantity]")[0];
	var checkUnitAmount = $("table#tbl_working_list [name=unitAmount]")[0];
	$(checkWorkingInfo).val("OK");
	$(checkQuantity).val("1");
	$(checkUnitAmount).val("1");
	$("table#tbl_working_list [data-db-key]").each(function(index, el){
		if ($(el).prop("name") == "workingInfo" && $(el).val() == "") {
			$(checkWorkingInfo).val("");
		} else if ($(el).prop("name") == "quantity") {
			if ($(el).val() == "" || $(el).val() < 0) {
				$(checkQuantity).val($(el).val());
			}
		} else if ($(el).prop("name") == "unitAmount") {
			if ($(el).val() == "" || $(el).val() < 0) {
				$(checkUnitAmount).val($(el).val());
			}
		}
	});

	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) educCheckList[educCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(educCheckList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_estimate_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 合計金額再計算
        send_data.amountTotal = $s.s30f001.calculation($('#calculation'));
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
        		var send_detail = [];
        		var $tr = $("table#tbl_working_list tBody tr");
        		var rowNumber = 0;
        		for(var i = 0; i < $tr.size(); i++) {
        			if (i % 2 == 0) {
        				send_detail[send_detail.length] = { estimateNo : data.estimateNo, rowNumber : rowNumber++ };
        			}
        			$($tr[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_detail[send_detail.length - 1], el); });
        		}

        		$s.com.ajax("POST", "_updateDetails", send_detail, {
                	done : function(data, status, xhr){
                		if (data.msg) {
                            $s.s30f001._search();
                            $s.s30f001._ctrlEditView($("#btn_return")[0]);
                        }
                	}
        		});
        	}
        };
	    $s.com.ajax("POST", "_update", send_data, callback);
    }
    $s.apply._showPopup(opt);
};

/**
 * 請求書情報登録廃止
 * */
s30f001_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"廃止します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_estimate_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s30f001._search();
                    $s.s30f001._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

s30f001_util.prototype._default_suppliers = function(el) {
	var send_data = {cond : "T9999"};
	var callback = {
		done : function(data, status, xhr){
	        $("#tbl_estimate_info #suppliersFromNo").val("T9999");
			$("#tbl_estimate_info #suppliersFromName").val(data.tbl_suppliers_list[0].suppliersName);
			$("#tbl_estimate_info #suppliersFromPostalCode").val(data.tbl_suppliers_list[0].postalCode);
			$("#tbl_estimate_info #suppliersFromAddress1").val(data.tbl_suppliers_list[0].address1);
			$("#tbl_estimate_info #suppliersFromAddress2").val(data.tbl_suppliers_list[0].address2);
			$("#tbl_estimate_info #suppliersFromAddress3").val(data.tbl_suppliers_list[0].address3);
			$("#tbl_estimate_info #suppliersFromAddress4").val(data.tbl_suppliers_list[0].address4);
			$("#tbl_estimate_info #suppliersFromPepresentative").val(data.tbl_suppliers_list[0].pepresentative);
			$("#tbl_estimate_info #suppliersFromTel").val(data.tbl_suppliers_list[0].tel);
			$("#tbl_estimate_info #suppliersFromFax").val(data.tbl_suppliers_list[0].fax);
        }
	};
	$s.com.ajax("GET", "_master_suppliers", {cond : "T9999"}, callback);
};

s30f001_util.prototype._master_suppliers = function(el) {
	this.suppliersTarget = el;

	var cond = "";
	if (el.id == "aSuppliersTo") {
		cond = $(el).closest("tr").find("[data-db-key=suppliersToName]").val();
	} else {
		cond = $(el).closest("tr").find("[data-db-key^=suppliersFromName]").val();
	}
	var opt = {title: "取引先検索", type:"master"};
	opt.html = $("#master_suppliers").clone().css("display","").html();
	$(opt.html).find("#master_suppliers_cond").val(cond);
	$s.apply._showPopup(opt);
	$s.s30f001._master_suppliers_search($("#btn_master_suppliers_search")[0]);
};


s30f001_util.prototype._master_suppliers_search = function(el) {

	var send_data = {cond : $(el).closest("p").find("#master_suppliers_cond").val()};
	if (send_data.cond == "") {
		$(el).closest("p").find("#master_suppliers_cond").after("<div for='master_suppliers_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}
	var callback = {
			done : function(data, status, xhr){
				$s.com.set_val($(el).closest("#popup_msg").find("#popupMsg"), data);
				var opt = {title: "取引先検索", type:"master"};
				opt.html = $("#master_suppliers").clone().css("display","").html();
				$(opt.html).find("#master_suppliers_cond").val(send_data.cond);
				$s.apply._showPopup(opt);
	        }
		};
	$s.com.ajax("GET", "_master_suppliers", send_data, callback);
};

s30f001_util.prototype._selSuppliersTr = function(el) {
	var suppliersObj = JSON.parse($(el).find("[data-db-key=suppliersJson]").val());
	var $tr = $(this.suppliersTarget).closest("tr");
	if ($(this.suppliersTarget).attr("id") == "aSuppliersFrom") {
		$tr.find("[data-db-key=suppliersFromName]").val(suppliersObj.suppliersName);
		$tr.find("[data-db-key=suppliersFromNo]").val(suppliersObj.suppliersNo);
		$("#tbl_estimate_info #suppliersFromPostalCode").val(suppliersObj.postalCode);
		$("#tbl_estimate_info #suppliersFromAddress1").val(suppliersObj.address1);
		$("#tbl_estimate_info #suppliersFromAddress2").val(suppliersObj.address2);
		$("#tbl_estimate_info #suppliersFromAddress3").val(suppliersObj.address3);
		$("#tbl_estimate_info #suppliersFromAddress4").val(suppliersObj.address4);
	    $("#tbl_estimate_info #suppliersFromPepresentative").val(suppliersObj.pepresentative);
		$("#tbl_estimate_info #suppliersFromTel").val(suppliersObj.tel);
		$("#tbl_estimate_info #suppliersFromFax").val(suppliersObj.fax);
	} else 	{
		$tr.find("[data-db-key=suppliersToName]").val(suppliersObj.suppliersName);
		$tr.find("[data-db-key=suppliersToNo]").val(suppliersObj.suppliersNo);
		$("#tbl_estimate_info #suppliersToPostalCode").val(suppliersObj.postalCode);
	    $("#tbl_estimate_info #suppliersToAddress1").val(suppliersObj.address1);
	    $("#tbl_estimate_info #suppliersToAddress2").val(suppliersObj.address2);
	    $("#tbl_estimate_info #suppliersToAddress3").val(suppliersObj.address3);
	    $("#tbl_estimate_info #suppliersToAddress4").val(suppliersObj.address4);
	    $("#tbl_estimate_info #suppliersToPepresentative").val(suppliersObj.pepresentative);
	    $("#tbl_estimate_info #suppliersToTel").val(suppliersObj.tel);
	    $("#tbl_estimate_info #suppliersToFax").val(suppliersObj.fax);
    }

	$("#popup_ok").click();
};

/**
 * 請求書印刷画面開く
 *
 * @param el イベント発火エレメント
 *  */
s30f001_util.prototype._print = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {estimateNo : $(el).closest("tr").find("[data-db-key=estimateNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			data.tbl_estimate_list.amountSum = data.amountSum;
			data.tbl_estimate_list.amountTax = data.amountTax;
			$s.com.set_val($("#div_estimate_print"), data);
			$s.com.set_val($("#div_estimate_print"), data.tbl_estimate_list);
			$s.com.set_val($("#div_estimate_print"), {tbl_working_list_print : data.tbl_working_list});
			$("#div_estimate_print #companyStamp").attr('src',$s.context + '/css/images/print/company_stamp.png');

			var printWindow = {};
			if ($s.com.clientType == "sp") {
                // iOs対応
				$("#div_estimate_print").css("display","block");
            } else {
    			printWindow = window.open("","PrintWindow" , '_blank');
    			printWindow.document.open();

    			var title = $("#div_estimate_print #suppliersNameTo").text() + "_" + $("#div_estimate_print #matterName").text();

    			printWindow.document.write("<HTML><HEAD><title>" + title + "</title><style>@media print{.no_print{display:none;}}</style><HEAD><BODY style='max-width:900px;margin-bottom:100px;'><input type='button' class='no_print' style='position: absolute;top:5px;' value='印刷' onclick='window.print();' />" + $("#div_estimate_print").html() + "</BODY></HTML>");
            }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 請求書印刷画面開く
 *
 * @param el イベント発火エレメント
 *  */
s30f001_util.prototype._print2 = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {estimateNo : $(el).closest("tr").find("[data-db-key=estimateNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			data.tbl_estimate_list.amountSum = data.amountSum;
			data.tbl_estimate_list.amountTax = data.amountTax;
			$s.com.set_val($("#div_estimate_print2"), data);
			$s.com.set_val($("#div_estimate_print2"), data.tbl_estimate_list);
			$s.com.set_val($("#div_estimate_print2"), {"tbl_working_list_print2" : data.tbl_working_list});

			var printWindow = {};
			if ($s.com.clientType == "sp") {
                // iOs対応
				$("#div_estimate_print2").css("display","block");
            } else {
    			printWindow = window.open("","PrintWindow" , '_blank');
    			printWindow.document.open();

    			var title = $("#div_estimate_print2 #suppliersToName").text() + "_" + $("#div_estimate_print2 #matterName").text();

    			printWindow.document.write("<HTML><HEAD><title>" + title + "</title><style>@media print{.no_print{display:none;}}</style><HEAD><BODY style='max-width:900px;margin-bottom:100px;'><input type='button' class='no_print' style='position: absolute;top:5px;' value='印刷' onclick='window.print();' />" + $("#div_estimate_print2").html() + "</BODY></HTML>");
            }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};