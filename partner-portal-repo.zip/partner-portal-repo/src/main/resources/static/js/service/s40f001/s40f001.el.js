//作成日時：2019/10/23 22:14:58
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_estimate_info_edit",className:"sa-form-container",elems:[
 {tag:"div",id:"conditions",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(75% - 110px);",elems:[
   {tag:"input",type:"text",id:"cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:110px;padding-top:2px;",elems:[
   {tag:"select",id:"selDelete",name:"selDelete"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_travel_estimate_list",style:"margin-top:0px;",elems:[
 {tag:"table",id:"tbl_travel_estimate_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_travel_estimate_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"コース名",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"期間",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"社名",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"見積書",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"行程表",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"コピー",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ,{tag:"input",type:"hidden","data-db-key":"travelNo",name:"travelNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"courseName",name:"courseName",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"label","data-db-key":"periodS",name:"periodS",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"periodE",name:"periodE",className:"FMT_YYYYMMDD",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersToName",name:"suppliersToName",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"outputEstimate",name:"outputEstimate",className:"ui-btn ui-icon-action ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"outputSchedule",name:"outputSchedule",className:"ui-btn ui-icon-action ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"copy",name:"copy",className:"ui-btn ui-icon-recycle ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_travel_estimate_edit",style:"display:none;",elems:[
 {tag:"table",id:"tbl_travel_estimate_info",name:"tbl_travel_estimate_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40%;",elems:[
     {tag:"label",text:"旅程番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:60%;",elems:[
     {tag:"input",type:"text","data-db-key":"travelNo",id:"travelNo",name:"travelNo",style:"width:100%;background-color:#ddd;",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"コース名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"courseName",id:"courseName",name:"courseName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"期間",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"label",text:"開始日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"periodS",id:"periodS",name:"periodS",style:"font-size: 10px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"label",text:"終了日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"periodE",id:"periodE",name:"periodE",style:"font-size: 10px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"人数",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"number","data-db-key":"quantity",id:"quantity",name:"quantity",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"取引先",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50px;",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToNo",id:"suppliersToNo",name:"suppliersToNo",style:"background-color:#ddd;",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 90px);",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aSuppliersTo",name:"aSuppliersTo",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"請求元",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50px;",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersFromNo",id:"suppliersFromNo",name:"suppliersFromNo",style:"background-color:#ddd;",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 90px);",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersFromName",id:"suppliersFromName",name:"suppliersFromName"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aSuppliersFrom",name:"aSuppliersFrom",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ,{tag:"div",style:"display:none;",elems:[
      {tag:"input",type:"text","data-db-key":"suppliersToPostalCode",id:"suppliersToPostalCode",name:"suppliersToPostalCode",readOnly:"True"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToAddress1",id:"suppliersToAddress1",name:"suppliersToAddress1",readOnly:"True",placeholder:"都道府県"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToAddress2",id:"suppliersToAddress2",name:"suppliersToAddress2",readOnly:"True",placeholder:"市区町村"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToAddress3",id:"suppliersToAddress3",name:"suppliersToAddress3",readOnly:"True",placeholder:"番地以降"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToAddress4",id:"suppliersToAddress4",name:"suppliersToAddress4",readOnly:"True",placeholder:"ビル名／部屋"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToPepresentative",id:"suppliersToPepresentative",name:"suppliersToPepresentative",readOnly:"True"}
     ,{tag:"input",type:"tel","data-db-key":"suppliersToTel",id:"suppliersToTel",name:"suppliersToTel",readOnly:"True"}
     ,{tag:"input",type:"tel","data-db-key":"suppliersToFax",id:"suppliersToFax",name:"suppliersToFax",readOnly:"True"}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"担当者",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"staffName",id:"staffName",name:"staffName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"携帯",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"mobileNumber",id:"mobileNumber",name:"mobileNumber",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ]}
 ]}
,{tag:"label",text:"旅程明細",style:"font-size: 12px;"}
,{tag:"table",id:"tbl_itinerary_list",name:"tbl_itinerary_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_itinerary_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_itinerary_list_add",name:"tbl_itinerary_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"年月日",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"時刻(開始-終了)",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"内容",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"移動手段",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"食事",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_itinerary_list_del",name:"tbl_itinerary_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"date","data-db-key":"travelDay",id:"travelDay",name:"travelDay",style:"width:125px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:75px;",elems:[
       {tag:"input",type:"time","data-db-key":"travelTimeS",id:"travelTimeS",name:"travelTimeS",style:"font-size: 12px;width:75px;"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:75px;",elems:[
       {tag:"input",type:"time","data-db-key":"travelTimeE",id:"travelTimeE",name:"travelTimeE",style:"font-size: 12px;width:75px;"}
      ]}
     ]}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"travelInfo",id:"travelInfo",name:"travelInfo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"travelType",id:"selTravelType",name:"selTravelType",style:"font-size: 12px;text-align:right;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"travelMeal",id:"selTravelMeal",name:"selTravelMeal",style:"font-size: 12px;text-align:center;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_itinerary_list_add",name:"tbl_itinerary_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"5"}
   ]}
  ]}
 ]}
,{tag:"label",text:"宿泊費明細",style:"font-size: 12px;"}
,{tag:"table",id:"tbl_lodging_list",name:"tbl_lodging_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_lodging_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_lodging_list_add",name:"tbl_lodging_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"宿泊先",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"項目",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"オプション",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"割引",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"料金",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_lodging_list_del",name:"tbl_lodging_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"lodgingLocation",name:"lodgingLocation"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"lodgingItem",name:"lodgingItem",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"option",name:"option",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"number","data-db-key":"discount",name:"discount",style:"font-size: 12px;margin-right:5px;text-align:right;width:80px;",value:"0"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"number","data-db-key":"amount",name:"amount",style:"font-size: 12px;margin-right:5px;text-align:right;width:80px;",value:"0"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_lodging_list_add",name:"tbl_lodging_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"3",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ,{tag:"textarea","data-db-key":"note1",id:"note1",name:"note1",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;text-align:center;",elems:[
     {tag:"label",text:"小計①",style:"font-size: 12px;text-align:center;",value:"0"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"0",id:"amountSum1",name:"amountSum1",style:"font-size: 12px;text-align:center;",value:"0"}
    ]}
   ]}
  ]}
 ]}
,{tag:"label",text:"交通費明細",style:"font-size: 12px;"}
,{tag:"table",id:"tbl_expenses_list",name:"tbl_expenses_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_expenses_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_expenses_list_add",name:"tbl_expenses_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:200px;",elems:[
     {tag:"label",text:"種別",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"項目",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"単価",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"税区分",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"金額",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_expenses_list_del",name:"tbl_expenses_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"expensesType",name:"selExpensesType"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"expensesInfo",name:"expensesInfo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"number","data-db-key":"unitAmount",name:"unitAmount",style:"font-size: 12px;margin-right:5px;text-align:right;",value:"0"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"taxType",name:"selTaxType",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"amount",name:"amount",style:"font-size: 12px;margin-right:5px;text-align:right;width:80px;",readOnly:"True"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_expenses_list_add",name:"tbl_expenses_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"text-align:center;",colSpan:"3",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ,{tag:"textarea","data-db-key":"note2",id:"note2",name:"note2",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;text-align:center;",elems:[
     {tag:"label",text:"小計②",style:"font-size: 12px;text-align:center;",value:"0"}
    ]}
   ,{tag:"th",style:"width:80px;text-align:center;",elems:[
     {tag:"label",text:"0",id:"amountSum2",name:"amountSum2",style:"font-size: 12px;text-align:center;",value:"0"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_travel_total_info",name:"tbl_travel_total_info",className:"scroll_table",style:"width:100%;margin-bottom:25px;",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:30%;",elems:[
     {tag:"a",id:"calculation",name:"calculation",style:"margin:auto;cursor: hand; cursor:pointer;",elems:[
      {tag:"label",text:"再計算",style:"font-size: 12px;text-align:center;cursor: hand; cursor:pointer;"}
     ]}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"旅行代金総額集計（①＋②）",style:"font-size: 12px;text-center:right;"}
    ]}
   ,{tag:"td",style:"width:85px;",elems:[
     {tag:"label","data-db-key":"amountTotal",id:"amountTotal",name:"amountTotal",style:"font-size: 12px;text-align:center;",placeholder:"口座番号"}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-bottom:50px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"廃止",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"master_suppliers",style:"display:none;",elems:[
 {tag:"div",id:"master_suppliers_cont",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_suppliers_cond",name:"master_suppliers_cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_suppliers_search",name:"btn_master_suppliers_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_suppliers_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_suppliers_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selSuppliersTr",name:"selSuppliersTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_suppliers",name:"a_sel_suppliers",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersNo",name:"suppliersNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersName",name:"suppliersName",style:"font-size: 12px;"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersJson",name:"suppliersJson",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",style:"display:none;",elems:[
 {tag:"div",id:"div_estimate_print",elems:[
  {tag:"div",style:"width:100%;margin-top:10px;margin-bottom:10px;padding-top:10px;padding-bottom:10px;text-align:center;",elems:[
   {tag:"label",text:"ご旅行行程表",style:"font-size: 24px;"}
  ]}
 ,{tag:"table",style:"width:100%;margin-bottom:20px;",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",colSpan:"2",elems:[
      {tag:"label","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName",style:"border-bottom: 1px solid black;padding-right:20px;"}
     ,{tag:"label",text:"様",style:"border-bottom: 1px solid black;padding-right:20px;"}
     ]}
    ,{tag:"td",style:"width:300px;font-size: 11px;text-align:center;border: 1px solid black;",rowSpan:"3",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"東京都知事登録旅行業第3－7740号"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"国内旅行業務取扱管理者：金子　依奈"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"株式会社アフロシー（スピードアートラベル）"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"〒101-0031　東京都千代田区東神田2－2－1ＮＭビル2階"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"TEL03(5817)8244　FAX03(5817)8245"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"担当：",style:"display:inline;"}
      ,{tag:"label","data-db-key":"staffName",name:"staffName",style:"display:inline;margin-left:10px;"}
      ,{tag:"label",text:"[",style:"display:inline;"}
      ,{tag:"label","data-db-key":"mobileNumber",name:"mobileNumber",style:"display:inline;margin-left:10px;"}
      ,{tag:"label",text:"]",style:"display:inline;"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",colSpan:"2",elems:[
      {tag:"label",text:"コース名",style:"display:inline;margin-right:20px;"}
     ,{tag:"label","data-db-key":"courseName",id:"courseName",name:"courseName",style:"display:inline;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"期間",style:"display:inline;margin-right:10px;"}
     ,{tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMMDD",style:"display:inline;font-size: 12px;"}
     ,{tag:"label",text:"～",style:"display:inline;"}
     ,{tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMMDD",style:"display:inline;font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label",text:"人数",style:"display:inline;"}
     ,{tag:"label","data-db-key":"quantity",id:"quantity",name:"quantity",style:"display:inline;"}
     ,{tag:"label",text:"名",style:"display:inline;"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",id:"tbl_itinerary_list_print",name:"tbl_itinerary_list_print",style:"width:100%;border-collapse: collapse;",list_id:"tbl_itinerary_list_print",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:100px;text-align:center;border: 1px solid black;",elems:[
      {tag:"label",text:"月日",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"border: 1px solid black;",elems:[
      {tag:"label",text:"日程",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"食事",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",style:"border: 1px solid black;",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:100px;text-align:center;",elems:[
      {tag:"label","data-db-key":"travelDay",name:"travelDay",className:"FMT_MMDD_JA"}
     ]}
    ,{tag:"td",style:"border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"travelTimeS",name:"travelTimeS",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ,{tag:"label","data-db-key":"travelTimeMark",name:"travelTimeMark",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ,{tag:"label","data-db-key":"travelTimeE",name:"travelTimeE",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ,{tag:"label","data-db-key":"travelInfo",name:"travelInfo",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ,{tag:"label","data-db-key":"travelTypeView",name:"selTravelType",style:"display:inline;font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:80px;text-align:center;border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"travelMealView",name:"selTravelMeal",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"border: 1px solid black;",colSpan:"3",elems:[
      {tag:"label",text:"バス　＝＝＝＝",style:"display:inline;margin-right:20px;font-size: 12px;"}
     ,{tag:"label",text:"ＪＲ　●〇●〇",style:"display:inline;margin-right:20px;font-size: 12px;"}
     ,{tag:"label",text:"電車・ケーブルカー・ロープウェイ　＋＋＋＋",style:"display:inline;margin-right:20px;font-size: 12px;"}
     ,{tag:"label",text:"タクシー・自家用車　－－－－",style:"display:inline;margin-right:20px;font-size: 12px;"}
     ,{tag:"label",text:"徒歩　・・・・",style:"display:inline;font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",style:"display:none;",elems:[
 {tag:"div",id:"div_estimate_print2",elems:[
  {tag:"div",style:"width:100%;margin-top:10px;margin-bottom:10px;padding-top:10px;padding-bottom:10px;text-align:center;",elems:[
   {tag:"label",text:"お見積書",style:"font-size: 24px;"}
  ]}
 ,{tag:"table",style:"width:100%;margin-bottom:20px;",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",colSpan:"2",elems:[
      {tag:"label","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName",style:"display:inline;border-bottom: 1px solid black;padding-right:20px;"}
     ,{tag:"label",text:"様",style:"display:inline;border-bottom: 1px solid black;padding-right:20px;"}
     ]}
    ,{tag:"td",style:"width:300px;font-size: 11px;text-align:center;border: 1px solid black;",rowSpan:"3",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"東京都知事登録旅行業第3－7740号"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"国内旅行業務取扱管理者：金子　依奈"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"株式会社アフロシー（スピードアートラベル）"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"〒101-0031　東京都千代田区東神田2－2－1ＮＭビル2階"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"TEL03(5817)8244　FAX03(5817)8245"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"担当：",style:"display:inline;"}
      ,{tag:"label","data-db-key":"staffName",name:"staffName",style:"margin-left:10px;display:inline;"}
      ,{tag:"label",text:"[",style:"display:inline;"}
      ,{tag:"label","data-db-key":"mobileNumber",name:"mobileNumber",style:"margin-left:10px;display:inline;"}
      ,{tag:"label",text:"]",style:"display:inline;"}
      ]}
     ,{tag:"div",style:"text-align:right;",elems:[
       {tag:"img",id:"companyStamp",style:"width:20%;position:relative;margin-top:-95px;"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",colSpan:"2",elems:[
      {tag:"label",text:"コース名",style:"display:inline;margin-right:20px;"}
     ,{tag:"label","data-db-key":"courseName",id:"courseName",name:"courseName",style:"display:inline;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"期間",style:"display:inline;margin-right:10px;"}
     ,{tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMMDD",style:"display:inline;font-size: 12px;"}
     ,{tag:"label",text:"～",style:"display:inline;"}
     ,{tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMMDD",style:"display:inline;font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label",text:"人数",style:"display:inline;"}
     ,{tag:"label","data-db-key":"quantity",id:"quantity",name:"quantity",style:"display:inline;"}
     ,{tag:"label",text:"名",style:"display:inline;"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",id:"tbl_lodging_list_print",name:"tbl_lodging_list_print",style:"width:100%;border-collapse: collapse;margin-bottom:20px;",list_id:"tbl_lodging_list_print",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"text-align:center;border: 1px solid black;",elems:[
      {tag:"label",text:"宿泊地名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"border: 1px solid black;",elems:[
      {tag:"label",text:"項目",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"料金",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"割引",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"料金（税込）",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"オプション",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",style:"border: 1px solid black;",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"lodgingLocation",name:"lodgingLocation"}
     ]}
    ,{tag:"td",style:"border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"lodgingItem",name:"lodgingItem",style:"font-size: 12px;margin-right:10px;"}
     ]}
    ,{tag:"td",style:"width:80px;text-align:center;border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"amountCost",name:"amountCost",className:"FMT_AMOUNT",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:80px;text-align:center;border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"discount",name:"discount",className:"FMT_AMOUNT",style:"font-size: 12px;color:red;"}
     ]}
    ,{tag:"td",style:"width:80px;text-align:center;border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"amount",name:"amount",className:"FMT_AMOUNT",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:80px;text-align:center;border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"option",name:"option",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"border: 1px solid black;text-align:left;padding-left:10px;height: 250px;vertical-align: top;",colSpan:"6",elems:[
      {tag:"label",text:"備考",style:"margin-right:20px;font-size: 12px;"}
     ,{tag:"div",elems:[
       {tag:"label","data-db-key":"note1",name:"note1",style:"margin-right:20px;font-size: 12px;"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",style:"text-align:left;border-top: 1px solid black;border-left: 1px solid black;border-right: 1px solid black;",colSpan:"6",elems:[
      {tag:"label",text:"小計①",style:"margin-left:10px;font-size: 12px;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",style:"text-align:right;border-bottom: 1px solid black;border-left: 1px solid black;border-right: 1px solid black;",colSpan:"6",elems:[
      {tag:"div",elems:[
       {tag:"label","data-db-key":"amountSum1",name:"amountSum1",className:"FMT_AMOUNT",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ,{tag:"label",text:"＊",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ,{tag:"label","data-db-key":"quantity",name:"quantity",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ,{tag:"label",text:"＝",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ,{tag:"label","data-db-key":"amountSumTotal1",name:"amountSumTotal",className:"FMT_AMOUNT",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ,{tag:"label",text:"（宿泊代金）",style:"display:inline;margin-right:20px;font-size: 12px;"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",id:"tbl_expenses_list_print",name:"tbl_expenses_list_print",style:"width:100%;border-collapse: collapse;margin-bottom:20px;",list_id:"tbl_expenses_list_print",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:100px;text-align:center;border: 1px solid black;",elems:[
      {tag:"label",text:"種別",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"border: 1px solid black;",elems:[
      {tag:"label",text:"項目",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"内容",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",style:"width:80px;border: 1px solid black;",elems:[
      {tag:"label",text:"料金",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",style:"border: 1px solid black;",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:100px;text-align:center;",elems:[
      {tag:"label","data-db-key":"expensesTypeView",name:"expensesTypeView"}
     ]}
    ,{tag:"td",style:"border-left: 1px solid black;",elems:[
      {tag:"label","data-db-key":"expensesInfo",name:"expensesInfo",style:"font-size: 12px;margin-right:10px;"}
     ]}
    ,{tag:"td",style:"width:160px;border-left: 1px solid black;text-align:right;",elems:[
      {tag:"label","data-db-key":"unitAmount",name:"unitAmount",className:"FMT_AMOUNT",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ,{tag:"label","data-db-key":"taxTypeView",name:"taxTypeView",style:"display:inline;font-size: 12px;margin-right:10px;"}
     ]}
    ,{tag:"td",style:"border-right: 1px solid black;width:80px;border-left: 1px solid black;text-align:right;",elems:[
      {tag:"label","data-db-key":"amount",name:"amount",className:"FMT_AMOUNT",style:"font-size: 12px;margin-right:10px;"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"border: 1px solid black;text-align:left;",colSpan:"2",elems:[
      {tag:"label",text:"その他",style:"margin-left:10px;font-size: 12px;"}
     ,{tag:"div",elems:[
       {tag:"label","data-db-key":"note2",name:"note2",style:"margin-left:10px;font-size: 12px;"}
      ]}
     ]}
    ,{tag:"th",style:"border: 1px solid black;text-align:left;",colSpan:"2",elems:[
      {tag:"label",text:"小計②",style:"margin-left:10px;font-size: 12px;"}
     ,{tag:"div",elems:[
       {tag:"label","data-db-key":"amountSum2",className:"FMT_AMOUNT",style:"display:inline;margin-left:60px;font-size: 12px;"}
      ,{tag:"label",text:"（交通代金）",style:"display:inline;margin-left:20px;font-size: 12px;"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",style:"width:100%;border-collapse: collapse;border: 1px solid black;",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"padding:15px;",elems:[
      {tag:"label",text:"旅行代金総額"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"小計①＋小計②",style:"margin-left:25px;font-size: 20px;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",style:"text-align:right;font-size: 20px;color:orange;padding:15px;",elems:[
      {tag:"label",text:"＝",style:"display:inline;border-bottom: 1px solid black;padding-right:20px;font-size: 20px;"}
     ,{tag:"label","data-db-key":"amountTotal",className:"FMT_AMOUNT",style:"display:inline;border-bottom: 1px solid black;padding-right:20px;margin-right:25px;font-size: 20px;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",style:"padding:15px;",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"・見積書作成時の料金であり、空き状況及び予約などはしておりません。"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"　正式に旅行のお申込及び行程が決定後の手配となりますので、手配後"}
      ]}
     ,{tag:"div",elems:[
       {tag:"label",text:"　上記見積額と料金改訂などの事情により異なる場合もございます。"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

