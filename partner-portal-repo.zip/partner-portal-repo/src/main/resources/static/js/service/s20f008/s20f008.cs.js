/*************************
 * s20f008-申請情報
 * 画面初期ロード
 *************************/
function _init() {
    // 初期化
    $s.s20f008 = new s20f008_util();
    $("#h_title").text("申請一覧");
    var sysdate = new Date();
    $("#inp_apply_ym").val(sysdate.getFullYear() + "/" + ("0" + (sysdate.getMonth() + 1)).slice(-2));
    // 画面表示
    $s.s20f008._search();
    // 画面制御
    if ($s._objs.canEdit == false) {
    	$("#divUser").css("display","");
    	$("#btn_update").css("display","none");
    	$("#btn_delete").css("display","none");
        $s.com.view_mode($("#tbl_apply_info")[0]);
    }
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f008_util = function(){
    if ((this instanceof s20f008_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    this.mode = "list";
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_apply_edit")[0]);
    }
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }
};
/**
 * イベントの初期化
 * */
s20f008_util.prototype.event_init = function(e) {
    try {
        // クリック_前月へ
        $(document).on('click', '[name=a_apply_back]', function(e){ $s.s20f008._chgMonth(this); });
        // クリック_翌月へ
        $(document).on('click', '[name=a_apply_next]', function(e){ $s.s20f008._chgMonth(this); });
        // 検索対象変更
        $(document).on('change', '#selSearchType', function(e){ $s.s20f008._search(this); });
	    // 一覧へ戻る
	    $(document).on('click', '#a_rtn_list', function(e){
	    	location.href=$s.context + "/user/apply?applyId=s00f004";
	    });
        // クリック_新規
        $(document).on('click', '[name=a_add]', function(e){ $s.s20f008._ctrlEditView(this); });
        // クリック_更新
        $(document).on('click', '[name=a_edit]', function(e){ $s.s20f008._ctrlEditView(this); });
        // クリック_行選択
        $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s20f008._selTr(this); });

        // チェンジ_経費・交通費選択制御
        $(document).on('change', '[name=settleType]', function(e){ $s.s20f008._ctrlSettleType(this); });
        // チェンジ_交通費往復制御
        $(document).on('change', '[name=roundTrip]', function(e){ $s.s20f008._chgRoundTrip(this); });
        // チェンジ_金額変更
        $(document).on('change', '#tripAmount', function(e){ $s.s20f008._chgRoundTrip($("#roundTrip")); });

        // クリック_領収書ファイル指定
        $(document).on('click', '#btn_tp_file', function(e){
            if ($s._objs.canEdit == true) {
            	$("#tmpfile").trigger("click");
            }
        });
        // チェンジ_領収書ファイル指定変更
        $(document).on('change', '#tmpfile', function(e){ $s.s20f008._tmpFileChange(this); });
        // クリック_領収書アップロード
        $(document).on('click', '#btn_tp_upload', function(e){ $s.s20f008._tmpFileUpLoad(this); });
        // クリック_領収書ダウンロード
        $(document).on('click', '[name=tmpFileName]', function(e){ $s.s20f008._tmpFileDownload(this); });
        // クリック_領収書削除
        $(document).on('click', '[name=tmpFileDelete]', function(e){ $s.s20f008._tmpFileDelete(this); });

        // クリック_勤務表ファイル指定
        $(document).on('click', '#btn_wk_file', function(e){
            if ($s._objs.canEdit == true) {
            	$("#wkFile").trigger("click");
            }
        });
        // チェンジ_勤務表ファイル指定変更
        $(document).on('change', '#wkFile', function(e){ $s.s20f008._wkFileChange(this); });
        // クリック_勤務表アップロード
        $(document).on('click', '#btn_wk_upload', function(e){ $s.s20f008._wkFileUpload(this); });
        // クリック_勤務表ダウンロード
        $(document).on('click', '#btn_wk_download', function(e){ $s.s20f008._wkFileDownload(this); });
        // クリック_勤務表削除
        $(document).on('click', '#btn_wk_delete', function(e){ $s.s20f008._wkFileDelete(this); });


        // クリック_登録ボタン
        $(document).on('click', '#btn_update', function(e){ $s.s20f008._update(this); });
        // クリック_削除ボタン
        $(document).on('click', '#btn_delete', function(e){ $s.s20f008._delete(this); });
        // クリック_戻るボタン
        $(document).on('click', '#btn_return', function(e){ $s.s20f008._ctrlEditView(this); });

    } catch (e) {
        setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 100);
        jQuery.mobile.loading('hide');
    }
};

/**
 * 経費・交通費一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s20f008_util.prototype._search = function(el) {
    var send_data = {};
    send_data.occurYm = $("#inp_apply_ym").val();
    send_data.settleType = $("#selSearchType").val();
    $s.com.ajax("GET", "_search", send_data, {
        done : function(data, status, xhr){
            $s.com.set_val($("#div_apply"), data);
            var amountSum = 0;
            $("#tbl_apply_list tr").each(function(index, tr){
                var $tr = $(tr);
                var amount = $tr.find("label[data-db-key=settleAmount]").text();
                amountSum += Number(amount);
                var settleType = $tr.find("input[data-db-key=settleType]").val();
                if (settleType == "30024-001") {
                    // 交通費の場合
                    $tr.find("label[data-db-key=transRootStart]").css("display", "inline-block");
                    $tr.find("label[data-db-key=transSymbol]").css("display", "inline-block");
                    $tr.find("label[data-db-key=transRootEnd]").css("display", "inline-block");
                } else if (settleType == "30024-002") {
                    // 経費の場合
                    $tr.find("label[data-db-key=expType]").css("display", "inline-block");
                }
            });
            // 合計金額
            $("#amountSum").text(amountSum);
            $("#btn_wk_download").text(data.wkFileName);
            if (data.isWkFile) {
                $("#divWkUpload").css("display", "none");
                $("#divWkDownload").css("display", "block");
            } else {
            	$("#wkFile").val("").trigger("change");
                $("#divWkUpload").css("display", "block");
                $("#divWkDownload").css("display", "none");
                // 勤務表ファイル選択をクリア
                $("#wkFile").val("").trigger("change");
            }
        }
    });
};

s20f008_util.prototype._chgRoundTrip = function(el) {
    var $el = $(el);
    var amount = Number($("#tripAmount").val());
    if ($el.prop("checked") == true) {
        $("#settleAmount").val(amount * 2);
    } else {
        $("#settleAmount").val(amount);
    }
};

s20f008_util.prototype._ctrlSettleType = function(el) {
    var $el = $(el);
    if ($el.prop("checked") == true) {
        if ($el.val() == "30024-002") {
            // 経費の場合
            $("#trExpType").css("display","");
            $("#trTransRoot").css("display","none");
            $("#trTransAmount").val("1").css("display","none");
            $("#RoundTrip").prop("checked", false).checkboxradio('refresh');
            $("#settleAmount").attr('readonly',false);
            $("#tripAmount").val(0);
        } else {
            // 交通費の場合
            $("select#selExpType option").attr("selected",false)
            $("#trExpType").css("display","none");
            $("#trTransRoot").css("display","");
            $("#trTransAmount").css("display","");
            $("#settleAmount").attr('readonly',true);
        }
    }
};

s20f008_util.prototype._chgMonth = function(el) {
    var terget_date = new Date();
    var ym = $("#inp_apply_ym").val().split("/");
    if (ym.length > 1) {
        if ($(el).attr("name") == 'a_apply_back') {
            terget_date = new Date(ym[0], Number(ym[1]) - 2, 1);
        } else if ($(el).attr("name") == 'a_apply_next') {
            terget_date = new Date(ym[0], Number(ym[1]), 1);
        }
    }
    $("#inp_apply_ym").val(terget_date.getFullYear() + "/" + ("0" + (terget_date.getMonth() + 1)).slice(-2));
    //
    // 画面表示
    $s.s20f008._search();
};
/**
 * 経費・交通費詳細取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f008_util.prototype._details = function(sequence) {
    $s.com.ajax("GET", "_details",
        {// 送信データオブジェクト初期化
            sequence : sequence,
            occurYm : $("#inp_apply_ym").val()
        },
        {// コールバック関数
            done : function(data,status,xhr){
                // 取得データ設定
                $s.com.set_val($("#tbl_apply_info"), data.tbl_apply_list);
                if ($("#settleType_1").prop("checked") == true) {
                    if ($("#roundTrip").prop("checked") == true) {
                        $("#tripAmount").val(Number($("#settleAmount").val())/2);
                    } else {
                        $("#tripAmount").val($("#settleAmount").val());
                    }
                    $s.s20f008._ctrlSettleType($("#settleType_1"));
                } else {
                    $s.s20f008._ctrlSettleType($("#settleType_2"));
                    $("#tripAmount").val(1);
                }
                $s.com.set_val($("#tbl_tmp_list"), {tbl_tmp_list:data.tbl_tmp_list});
            }
        }
    );
};

/**
 * 経費・交通費情報登録更新.
 * */
s20f008_util.prototype._update = function(el) {
    var skillCheckList = [];
    $("#updateForm :input").each(function(index, el) {
        if ($(el).prop("validate"))skillCheckList[skillCheckList.length] = el.name;
    });
    // 標準入力チェック
    if ($s.com.get_validate(skillCheckList, "#updateForm") == true) {
        var opt = {title: "確認",msg:"登録します。よろいですか？", type:"confirm"};
        opt.fnc_ok = function(el) {
            // 送信データ取得
            var send_data = {};
            $("table#tbl_apply_info [data-db-key]").each(function(index, el){
                $s.com.getSendData(send_data, el);
            });
            send_data.occurYm = $("#inp_apply_ym").val();
            var callback = {
                done : function(data,status,xhr){
                    $s.s20f008._search();
                    $s.s20f008._ctrlEditView($("#btn_return")[0]);
                }
            };
            // 更新処理実施
            $s.com.ajax("POST", "_update", send_data, callback);
        };
        $s.apply._showPopup(opt);
    } else {
        $s.apply._showInputErrPopup();
    }
};
/**
 * 経費・交通費申請削除
 * */
s20f008_util.prototype._delete = function(el) {
    if ($s.s20f008.mode == "create") return;
    var opt = {title: "確認",msg:"削除します。よろいですか？", type:"confirm"};
    opt.fnc_ok = function(el) {
        $s.com.ajax("POST", "_delete",
            {
                occurYm : $("#inp_apply_ym").val(),
                sequence : $("table#tbl_apply_info [data-db-key=sequence]").val()
            },
            {
                done : function(data,status,xhr){
                    $s.s20f008._search();
                    $s.s20f008._ctrlEditView($("#btn_return")[0]);
                }
            }
        );
    };
    $s.apply._showPopup(opt);
};

s20f008_util.prototype._selTr = function(el) {
    var edit = $(el).find("#a_edit");
    if (edit) {
        $s.s20f008._ctrlEditView(edit[0]);
    }
};
/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f008_util.prototype._ctrlEditView = function(el) {
    // 入力情報クリア
    $s.com.inputClear($("#div_apply_edit"));
    if ($(el).attr("name") == "a_add" && $s._objs.canEdit == true) {
        // 新規モード
        $s.s20f008.mode = "create";
        $("#settleType_1").prop("checked","true").checkboxradio('refresh');
        $s.s20f008._ctrlSettleType($("#settleType_1"));
        // 行クリア
        $("#tbl_tmp_list tr").html("");
        $("input:radio[name=settleType]").prop('disabled',false).checkboxradio('refresh');
    } else if ($(el).attr("name") == "a_edit") {
        // 編集モード
        $s.s20f008.mode = "edit";
        $("input:radio[name=settleType]").prop('disabled',true).checkboxradio('refresh');
        // 対象従業員の申請情報取得
        var sequence = $(el).closest("tr").find("[data-db-key=sequence]").val();
        this._details(sequence);
    } else if (el.id == "btn_return") {
        // 一覧再表示
        $s.s20f008.mode = "list";
        $("[data-db-key=tmpfile]").val("").trigger("change");
        $s.s20f008._search();
    }

    // 表示制御
    if ($s.s20f008.mode == "list") {
        $("#a_apply_back").css("display","");
        $("#inp_apply_ym").css("display","");
        $("#a_apply_next").css("display","");
        $("#div_ctrl").css("display","");
        $("#div_apply_list").css("display","block");
        $("#div_apply_edit").css("display","none");
        $("#h_title").text("申請一覧");
    } else {
        $("#a_apply_back").css("display","none");
        $("#inp_apply_ym").css("display","none");
        $("#a_apply_next").css("display","none");
        $("#div_ctrl").css("display","none");
        $("#div_apply_list").css("display","none");
        $("#div_apply_edit").css("display","block");
        $("#divWkUpload").css("display","none");
        $("#divWkDownload").css("display","none");
        $("#h_title").text("申請情報");
    }
};
/**
 * チェンジ_領収書ファイルの指定変更
 *
 * @param el イベント発火エレメント
 *  */
s20f008_util.prototype._tmpFileChange = function(el) {
    if ($s._objs.canEdit == false) {
    	return;
    }
	if ($(el).val() == "") {
		$("#btn_tp_file").text("ファイル選択");
	} else {
		var file_name = el.files[0].name;
		var extension = $s.com.getExtension(file_name);
		if (file_name.length - extension.length > 10) {
			file_name = file_name.substring(0, 10) + "・・・." + extension;
		}
		$("#btn_tp_file").text(file_name);
	}
};
/**
 * クリック_領収書のアップロード
 *
 * @param el イベント発火エレメント
 *  */
s20f008_util.prototype._tmpFileUpLoad = function(el){
    if ($("[data-db-key=tmpfile]").val() == "") {
    	return;
    }
    if ($("#tbl_apply_info #sequence").val() == "") {
        setTimeout($s.apply._showPopup({
            title : "メッセージ",
            msg : "申請登録してから、ファイルアップロードはしてください。"
        }), 100);
        return;
    }
    var file = $("[data-db-key=tmpfile]")[0].files[0];
    // ファイルサイズチェック
    if (file && file.size > 1048576) {
        setTimeout($s.apply._showPopup({
            title : "メッセージ",
            msg : "ファイルサイズが転送上限（1M）超えているため、転送できません。"
        }), 100);
        return;
    }
//        var extension = $s.com.getExtension(file.name);
//        if (extension == "jpg" || extension == "png" || extension == "gif" || extension == "bmp") {
//            $s.com.compressionImage(file, function(blob) {
//                $s.s20f008._tmpFileUpLoad1();
//            });
//        } else {
//            $s.s20f008._tmpFileUpLoad1();
//        }
    if (window.FormData) {
        var $form = $("#formTmpFile");
        $form.attr("enctype", "multipart/form-data");
        $form.attr("method", "post");
        var settleType = $("input:radio[name=settleType]").val();
        var sequence = $("#tbl_apply_info [name=sequence]").val();
        var ajaxUrl = $s.context + "/user/" + $s._objs.applyId + "_upload" +
            "?targerDate=" + $("[name=occurDate]").val() +
            "&sequence=" + sequence +
            "&settleType=" + settleType;

        $.ajax({
            type : "POST",
            url  : ajaxUrl,
            data : new FormData($form[0]),
            processData : false,
            contentType: false,
        }).done(function(data) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが完了しました。"
            });
            $s.s20f008._details(sequence);
        }).fail(function(XMLHttpRequest, textStatus, errorThrown) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが失敗しました。"
            });
        });
    } else {
        $s.apply._showPopup({
            title : "メッセージ",
            msg : "アップロードに対応できていないブラウザです。"
        });
    }
};

/**
 * クリック_領収書ダウンロード
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._tmpFileDownload = function(el) {
    var applyId = "";
    jQuery.mobile.loading('show');
    var filename = $(el).text();
    var occurDate = $("[name=occurDate]").val();
    var settleType = $("input:radio[name=settleType]").val();
    var sequence = $("#tbl_apply_info [name=sequence]").val();
    var ajaxUrl = $s.context + "/user/" + $s._objs.applyId + "_download" +
        "?targerDate=" + occurDate +
        "&file_name=" + filename +
        "&settleType=" + settleType +
        "&sequence=" + sequence;

    var xhr = new XMLHttpRequest();
    xhr.open("GET", ajaxUrl, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function(e) {
        if (xhr.status === 200) {
            var downloadData = new Blob([ this.response ], {
                type : 'application/octet-stream'
            });
            if (window.navigator.msSaveBlob) {
                window.navigator.msSaveBlob(downloadData, filename); // IE用
            } else {
                var _url = $s.context + "/js/report/" + $s._objs.userCd + "/" + occurDate.replace(/-/gi, "") + "/" + filename;
                if ($s.com.clientType == "sp") {
                    // iOs対応
                    window.open(_url, "_self");
                } else {
                    window.open(_url, "_blank");
                }
            }
        } else {
            var msg = "エラー発生しました。（" + xhr.status + "）";
            var html = "";
            try {
                html = xhr.responseText;
            } catch (e) {
            }
            setTimeout($s.apply._showPopup({
                title : "メッセージ",
                msg : msg,
                html : html,
                type : "エラー発生"
            }), 200);
        }
        jQuery.mobile.loading('hide');
    };
    xhr.send();
};
/**
 * クリック_領収書削除
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._tmpFileDelete = function(el) {
    var opt = {title: "確認",msg:"削除します。よろいですか？", type:"confirm"};
    opt.fnc_ok = function(e) {
        // 送信データ取得
        var send_data = {};
        var sequence = $("#tbl_apply_info [name=sequence]").val();
        var settleType = $("input:radio[name=settleType]").val();
        send_data.targerDate = $("[name=occurDate]").val();
        send_data.sequence = sequence;
        send_data.settleType = settleType;
        send_data.fileName = $(el).closest("tr").find("[name=tmpFileName]").text();
        var callback = {
            done : function(data,status,xhr){
                $s.apply._showPopup({
                    title : "メッセージ",
                    msg : "削除しました。"
                });
                $s.s20f008._details(sequence);
            }
        };
        // 更新処理実施
        $s.com.ajax("GET", "_tmpFileDelete", send_data, callback);
    };
    $s.apply._showPopup(opt);
};
/**
 * チェンジ_勤務表ファイル選択
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._wkFileChange = function(el) {
	if ($(el).val() == "") {
		$("#btn_wk_file").text("ファイル選択");
	} else {
		var file_name = el.files[0].name;
		var extension = $s.com.getExtension(file_name);
		if (file_name.length - extension.length > 10) {
			file_name = file_name.substring(0, 10) + "・・・." + extension;
		}
		$("#btn_wk_file").text(file_name);
	}
};
/**
 * クリック_勤務表アップロード
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._wkFileUpload = function(el) {
    if ($("#wkFile").val() == "") {
    	return;
    }
    var file = $("#wkFile")[0].files[0];
    $("#btn_wk_file").text(file.name);
    // サイズチェック
    if (file.size > 1048576) {
        setTimeout($s.apply._showPopup({
            title : "メッセージ",
            msg : "ファイルサイズが転送上限（1M）超えているため、転送できません。"
        }), 100);
        return;
    }
//  var extension = $s.com.getExtension(file.name);
//  if (extension == "jpg" || extension == "png" || extension == "gif" || extension == "bmp") {
//      $s.com.compressionImage(file, function(blob) {
//          $s.s20f008._wkFileUpload1(blob);
//      });
//  } else {
//      $s.s20f008._wkFileUpload1();
//  }
    //FormData送信
    if(window.FormData){
        var $form = $("#formWkFile");
        $form.attr("enctype", "multipart/form-data");
        $form.attr("method", "post");
        $.ajax({
            type : "POST",
            url  : $s.context + "/user/" + $s._objs.applyId + "_wkupload" + "?targerYm=" + $("#inp_apply_ym").val().replace("/",""),
            dataType: 'json',
            data : new FormData($form[0]),
            processData : false,
            contentType: false,
        }).done(function(data) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが完了しました。"
            });
            $("#divWkUpload").css("display", "none");
            $("#divWkDownload").css("display", "block");
        }).fail(function(XMLHttpRequest, textStatus, errorThrown) {
            $s.apply._showPopup({
                title : "メッセージ",
                msg : "アップロードが失敗しました。"
            });
        });
    } else {
        $s.apply._showPopup({
            title : "メッセージ",
            msg : "アップロードに対応できていないブラウザです。"
        });
    }
};

/**
 * クリック_勤務表ダウンロード
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._wkFileDownload = function(el) {
    jQuery.mobile.loading('show');
    //var filename = $(el).text();
    var targerYm = $("#inp_apply_ym").val().replace("/","");
    var ajaxUrl = $s.context + "/user/" + $s._objs.applyId + "_wk_download" + "?targerYm=" + targerYm;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", ajaxUrl, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function(e) {
        if (xhr.status === 200) {
            var filename = xhr.getResponseHeader('fileName');
            var downloadData = new Blob([ this.response ], {
                type : 'application/octet-stream'
            });
            var url = $s.context + "/js/report/" + $s._objs.userCd + "/" + filename;
            if (window.navigator.msSaveBlob) {
                window.navigator.msSaveBlob(downloadData, filename); // IE用
            } else {
                if ($s.com.clientType == "sp") {
                    // iOs対応
                    window.open(url, "_self");
                } else {
                    window.open(url, "_blank");
                }
            }
        } else {
            var msg = "エラー発生しました。（" + xhr.status + "）";
            var html = "";
            try {
                html = xhr.responseText;
            } catch (e) {
            }
            setTimeout($s.apply._showPopup({
                title : "メッセージ",
                msg : msg,
                html : html,
                type : "エラー発生"
            }), 100);
        }
        jQuery.mobile.loading('hide');
    };
    xhr.send();
};

/**
 * クリック_勤務表削除
 *
 * @param el イベント発火エレメント
 * */
s20f008_util.prototype._wkFileDelete = function(el) {
    if ($s._objs.canEdit == false) {
    	return;
    }
    var opt = {title: "確認", msg:"削除します。よろいですか？", type:"confirm"};
    opt.fnc_ok = function(e) {
        // 更新処理実施
        $s.com.ajax("GET", "_wkFileDelete",
            {fileName : $("#btn_wk_download").text()},
            {
                done : function(data,status,xhr){
                    $s.apply._showPopup({
                        title : "メッセージ",
                        msg : "削除しました。"
                    });
                    // 削除後画面制御
                    $("#divWkUpload").css("display", "block");
                    $("#divWkDownload").css("display", "none");
                }
            }
        );
    };
    $s.apply._showPopup(opt);
};
