//作成日時：2019/07/06 0:22:59
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",className:"ui-grid-a",elems:[
  {tag:"div",id:"div_conditions",className:"ui-block-a",style:"width:60%;",elems:[
   {tag:"input",type:"text",id:"conditions",style:"margin:4px;",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:40%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;"}
  ]}
 ]}
,{tag:"div",id:"div_item_type_info",elems:[
  {tag:"table",id:"tbl_item_type_list",name:"tbl_item_type_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_item_type_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:20px;",elems:[
      {tag:"label",text:"編集",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"分類コード",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"分類名称",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:40px;text-align:center;",elems:[
      {tag:"a",id:"a_edit",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"itemType",name:"itemType",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"itemTypeName",name:"itemTypeName"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_item_type_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
  {tag:"table",id:"tbl_item_type_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"項目分類",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"itemType",name:"itemType",style:"width:95%;font-size: 12px;"}
     ,{tag:"label","data-db-key":"itemTypeName",name:"itemTypeName",style:"width:95%;font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",id:"div_item_edit",className:"sa-form-container-wide",elems:[
   {tag:"table",id:"tbl_item_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_item_list",even_color:"#F1F4FF",elems:[
    {tag:"tHead",elems:[
     {tag:"tr",elems:[
      {tag:"th",elems:[
       {tag:"label",text:"コード",style:"font-size: 12px;"}
      ]}
     ,{tag:"th",elems:[
       {tag:"label",text:"テキスト",style:"font-size: 12px;"}
      ]}
     ,{tag:"th",style:"width:50px;",elems:[
       {tag:"label",text:"ソート",style:"font-size: 12px;"}
      ]}
     ,{tag:"th",style:"width:50px;",elems:[
       {tag:"label",text:"無効",style:"font-size: 12px;"}
      ]}
     ]}
    ]}
   ,{tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"td",style:"text-align:center;",elems:[
       {tag:"a",id:"tbl_item_list_del",name:"tbl_item_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;display:none;"}
      ,{tag:"label","data-db-key":"itemCd",name:"itemCd",style:"font-size: 12px;"}
      ,{tag:"input",type:"hidden","data-db-key":"itemType",name:"itemType"}
      ,{tag:"input",type:"hidden","data-db-key":"itemVal",name:"itemVal"}
      ]}
     ,{tag:"td",elems:[
       {tag:"input",type:"text","data-db-key":"itemTxt",name:"itemTxt",style:"width:95%;font-size: 12px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"input",type:"number","data-db-key":"itemSort",name:"itemSort",style:"width:95%;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",for:"deleteFlag",elems:[
        {tag:"input",type:"checkbox","data-db-key":"deleteFlag",id:"deleteFlag",name:"deleteFlag"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tFoot",elems:[
     {tag:"tr",elems:[
      {tag:"th",style:"width:100px;",elems:[
       {tag:"a",id:"tbl_item_list_add",name:"tbl_item_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
      ]}
     ,{tag:"th",colSpan:"3"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-a",style:"margin-top:20px;",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
];

