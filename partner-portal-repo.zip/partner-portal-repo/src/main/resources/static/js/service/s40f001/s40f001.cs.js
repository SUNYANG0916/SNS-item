/*************************
 * S40F001-旅行見積書
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s40f001 = new s40f001_util();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s40f001_util = function(){
    if ((this instanceof s40f001_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    this.mode = "update";
    // 対象取引先
    this.suppliersTarget = {};
    // 対象プロジェクト
    this.projectTarget = {};
    // タイトル
    $("#h_title").text("旅行一覧");
    // イベント
    this.event_init();
    // 一覧初期化
    $("#tbl_travel_estimate_list").get(0).tBodies[0].innerHTML = "";

    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_travel_estimate_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s40f001_util.prototype.event_init = function(e) {

	$(document).on('click', '#h_title', function(e){ $s.s40f001._ctrlEditView(this); });
    // クリック_検索ボタン
	$(document).on('click', '#btn_search', function(e){ $s.s40f001._search(this); });
    // クリック_新規
    $(document).on('click', '[name=a_add]', function(e){ $s.s40f001._ctrlEditView(this); });
    // クリック_行選択
    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s40f001._selTr(e, this); });
    // クリック_登録・更新ボタン
    $(document).on('click', '#btn_update', function(e){ $s.s40f001._update(this); });
    // クリック_廃止リンク
    $(document).on('click', '#btn_delete', function(e){ $s.s40f001._delete(this); });
    // クリック_戻るボタン
    $(document).on('click', '#btn_return', function(e){ $s.s40f001._ctrlEditView(this); });


    $(document).on('click', '[name=tbl_itinerary_list_add]', function(e){ $s.s40f001._travelDaySet(this); });


    // クリック_請求先取引先検索リンク
    $(document).on('click', '#aSuppliersTo', function(e){ $s.s40f001._master_suppliers(this); });
    // クリック_請求元取引先検索リンク
    $(document).on('click', '#aSuppliersFrom', function(e){ $s.s40f001._master_suppliers(this); });
    // クリック_取引先検索
    $(document).on("click", "[name=btn_master_suppliers_search]", function(e) {$s.s40f001._master_suppliers_search(this);});
    // クリック_取引先行選択
    $(document).on('click', '[data-db-key=selSuppliersTr]', function(e){ $s.s40f001._selSuppliersTr(this); });

    // クリック_住所（郵便番号）検索ボタン
    $(document).on("click", "#postalSearch", function(e){ $s.s40f001._master_address(this); });
    // クリック_住所一覧行選択
    $(document).on("click", "[data-db-key=selPostalTr]", function(e){ $s.s40f001._sel_address(this); });

    // クリック_金額再計算
    $(document).on('click', '#calculation', function(e){ $s.s40f001.calculation(this);});



};

s40f001_util.prototype._travelDaySet = function(el) {
	var $tr = $("table#tbl_itinerary_list tBody tr");
	$($tr[$tr.length - 1]).find("[data-db-key=travelDay]").val($("#tbl_travel_estimate_info #periodS").val());
};

s40f001_util.prototype.calculation = function(el) {
    var totalAmount = 0;
    var amountSum1 = 0;
    $("table#tbl_lodging_list").find("[data-db-key=amount]").each(function(index, el){
    	amountSum1 += Number($(el).val());
    });
    $("table#tbl_lodging_list").find("#amountSum1").text(amountSum1);

    var amountSum2 = 0;
    $("table#tbl_expenses_list").find("[data-db-key=unitAmount]").each(function(index, el){
    	var amount = Number($(el).val());
    	if ($(el).closest("tr").find("[data-db-key=taxType]").val() == "30039-002") {
    		amount = amount + (amount * 0.1);
    	}
    	$(el).closest("tr").find("[data-db-key=amount]").val(amount);
    	amountSum2 += amount;
    });
    $("table#tbl_expenses_list").find("#amountSum2").text(amountSum2);
    totalAmount = amountSum1 + amountSum2;
    $("table#tbl_travel_total_info").find("#amountTotal").text(totalAmount);
    return totalAmount;
};


s40f001_util.prototype._selTr = function(e, el) {
	if (e.target.name == "outputSchedule") {
		// 行程表出力
		$s.s40f001._print($(el).find("#a_edit"));
	} else if (e.target.name == "outputEstimate") {
		// 見積書出力
		$s.s40f001._print2($(el).find("#a_edit"));
	} else if (e.target.name == "copy") {
		$s.s40f001._ctrlEditView(e.target);
	} else if (e.target.name == "a_edit") {
		$s.s40f001._ctrlEditView(e.target);
	}
};

/**
 * 見積書一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s40f001_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var send_data = {cond:$("#cond").val(),selDelete:$("#selDelete").val()};

	var callback = {
		done : function(data, status, xhr){
			if (data.tbl_travel_estimate_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            $s.com.set_val($("#div_travel_estimate_list"), data);
		}
    };
    $s.com.ajax("GET", "_search", send_data, callback);
};
/**
 * 見積書情報取得
 *
 * @param el イベント発火エレメント
 *  */
s40f001_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {travelNo : $(el).closest("tr").find("[data-db-key=travelNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			// 旅行詳細
			$s.com.set_val($("#tbl_travel_estimate_info"), data.tbl_travel_estimate_info);
	        $("#note1").val(data.tbl_travel_estimate_info.note1);
	        $("#note2").val(data.tbl_travel_estimate_info.note2);
	        $("#amountTotal").text(data.tbl_travel_estimate_info.amountTotal);

			// 各明細
			$s.com.set_val($("#div_travel_estimate_edit"), data);
			if ($s.s40f001.mode == "create") {
				$("#travelNo").val("");
			}
			// 再計算
			$s.s40f001.calculation();
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s40f001_util.prototype._ctrlEditView = function(el) {
    // プロジェクト情報クリア
    $s.com.inputClear($("table#tbl_travel_estimate_info"));
    if (el.id == "a_edit") {
    	// 編集モード
        this.mode = "update";
        // 明細情報取得
        this._details(el);
        $("#btn_delete").css("display","");
    } else if (el.id == "a_add") {
    	// 新規モード
        this.mode = "create";
        // 明細情報クリア
        $("#tbl_itinerary_list tbody").html("");
        $("#tbl_lodging_list tbody").html("");
        $("#tbl_expenses_list tbody").html("");
        // デフォルト請求元
        $s.s40f001._default_suppliers();
        // 開始日
        $("#periodS").val($s.dat.fmt("YYYY-MM-", $s.dat.sysDate) + "01");
        // 終了日
        var lastDate = new Date($s.dat.sysDate.getFullYear(), $s.dat.sysDate.getMonth() + 1, 0);
        $("#periodE").val($s.dat.fmt("YYYY-MM-", $s.dat.sysDate) + lastDate.getDate());
        $("#btn_delete").css("display","none");
    } else if (el.name == "copy") {
    	// コピー新規モード
    	this.mode = "create";
        // 明細情報取得
    	this._details(el);
        $("#btn_delete").css("display","none");
    } else {
    	// 一覧表示
    	this.mode = "list";
		$("#div_estimate_print").parent("div").css("display","none");
		$("#div_estimate_print2").parent("div").css("display","none");
    }

    // 表示制御
    if (this.mode == "create" || this.mode == "update") {
        $("#h_title").text("旅行詳細");
        $("#div_travel_estimate_list").css("display","none");
        $("#div_travel_estimate_edit").css("display","block");
        $("#div_travel_estimate_data").css("display","none");
        $("#conditions").css("display","none");
    } else {
        $("#h_title").text("旅行一覧");
    	$("#div_travel_estimate_list").css("display","block");
        $("#div_travel_estimate_edit").css("display","none");
        $("#div_travel_estimate_data").css("display","block");
        $("#conditions").css("display","");
    }
};


/**
 * 見積書情報登録更新
 * */
s40f001_util.prototype._update = function(el) {
	// 再計算
	$s.s40f001.calculation();
    var checkList = [];
    $("#applycationForm :input").each(function(index, el) {
        if ($(el).prop("validate"))checkList[checkList.length] = el.name;
    });
    // 標準入力チェック
	if ($s.com.get_validate(checkList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_travel_estimate_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        send_data.note1 = $("#note1").val();
        send_data.note2 = $("#note2").val();
        send_data.amountTotal = $("#amountTotal").text();

        send_data.tbl_itinerary_list = [];
   		var $tr = $("table#tbl_itinerary_list tBody tr");
		for(var i = 0; i < $tr.size(); i++) {
	   		send_data.tbl_itinerary_list[send_data.tbl_itinerary_list.length] = { rowNumber : i };
			$($tr[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_data.tbl_itinerary_list[send_data.tbl_itinerary_list.length - 1], el); });
		}

        send_data.tbl_lodging_list = [];
   		var $trLodging = $("table#tbl_lodging_list tBody tr");
		for(var i = 0; i < $trLodging.size(); i++) {
	   		send_data.tbl_lodging_list[send_data.tbl_lodging_list.length] = { rowNumber : i };
			$($trLodging[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_data.tbl_lodging_list[send_data.tbl_lodging_list.length - 1], el); });
		}

        send_data.tbl_expenses_list = [];
   		var $trExpenses = $("table#tbl_expenses_list tBody tr");
		for(var i = 0; i < $trExpenses.size(); i++) {
	   		send_data.tbl_expenses_list[send_data.tbl_expenses_list.length] = { rowNumber : i };
	        $($trExpenses[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_data.tbl_expenses_list[send_data.tbl_expenses_list.length - 1], el); });
		}

        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
        	}
        };
	    $s.com.ajax("POST", "_update", send_data, callback);
    }
    $s.apply._showPopup(opt);
};

/**
 * 請求書情報登録廃止
 * */
s40f001_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"廃止します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_estimate_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s40f001._search();
                    $s.s40f001._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

s40f001_util.prototype._default_suppliers = function(el) {
	var send_data = {cond : "T9999"};
	var callback = {
		done : function(data, status, xhr){
	        $("#tbl_travel_estimate_info #suppliersFromNo").val("T9999");
			$("#tbl_travel_estimate_info #suppliersFromName").val(data.tbl_suppliers_list[0].suppliersName);
			$("#tbl_travel_estimate_info #suppliersFromPostalCode").val(data.tbl_suppliers_list[0].postalCode);
			$("#tbl_travel_estimate_info #suppliersFromAddress1").val(data.tbl_suppliers_list[0].address1);
			$("#tbl_travel_estimate_info #suppliersFromAddress2").val(data.tbl_suppliers_list[0].address2);
			$("#tbl_travel_estimate_info #suppliersFromAddress3").val(data.tbl_suppliers_list[0].address3);
			$("#tbl_travel_estimate_info #suppliersFromAddress4").val(data.tbl_suppliers_list[0].address4);
			$("#tbl_travel_estimate_info #suppliersFromPepresentative").val(data.tbl_suppliers_list[0].pepresentative);
			$("#tbl_travel_estimate_info #suppliersFromTel").val(data.tbl_suppliers_list[0].tel);
			$("#tbl_travel_estimate_info #suppliersFromFax").val(data.tbl_suppliers_list[0].fax);
        }
	};
	$s.com.ajax("GET", "_master_suppliers", {cond : "T9999"}, callback);
};

s40f001_util.prototype._master_suppliers = function(el) {
	this.suppliersTarget = el;

	var cond = "";
	if (el.id == "aSuppliersTo") {
		cond = $(el).closest("tr").find("[data-db-key=suppliersToName]").val();
	} else {
		cond = $(el).closest("tr").find("[data-db-key^=suppliersFromName]").val();
	}
	var opt = {title: "取引先検索", type:"master"};
	opt.html = $("#master_suppliers").clone().css("display","").html();
	$(opt.html).find("#master_suppliers_cond").val(cond);
	$s.apply._showPopup(opt);
	$s.s40f001._master_suppliers_search($("#btn_master_suppliers_search")[0]);
};


s40f001_util.prototype._master_suppliers_search = function(el) {

	var send_data = {cond : $(el).closest("p").find("#master_suppliers_cond").val()};
	if (send_data.cond == "") {
		$(el).closest("p").find("#master_suppliers_cond").after("<div for='master_suppliers_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}
	var callback = {
			done : function(data, status, xhr){
				$s.com.set_val($(el).closest("#popup_msg").find("#popupMsg"), data);
				var opt = {title: "取引先検索", type:"master"};
				opt.html = $("#master_suppliers").clone().css("display","").html();
				$(opt.html).find("#master_suppliers_cond").val(send_data.cond);
				$s.apply._showPopup(opt);
	        }
		};
	$s.com.ajax("GET", "_master_suppliers", send_data, callback);
};

s40f001_util.prototype._selSuppliersTr = function(el) {
	var suppliersObj = JSON.parse($(el).find("[data-db-key=suppliersJson]").val());
	var $tr = $(this.suppliersTarget).closest("tr");
	if ($(this.suppliersTarget).attr("id") == "aSuppliersFrom") {
		$tr.find("[data-db-key=suppliersFromName]").val(suppliersObj.suppliersName);
		$tr.find("[data-db-key=suppliersFromNo]").val(suppliersObj.suppliersNo);
		$("#tbl_estimate_info #suppliersFromPostalCode").val(suppliersObj.postalCode);
		$("#tbl_estimate_info #suppliersFromAddress1").val(suppliersObj.address1);
		$("#tbl_estimate_info #suppliersFromAddress2").val(suppliersObj.address2);
		$("#tbl_estimate_info #suppliersFromAddress3").val(suppliersObj.address3);
		$("#tbl_estimate_info #suppliersFromAddress4").val(suppliersObj.address4);
	    $("#tbl_estimate_info #suppliersFromPepresentative").val(suppliersObj.pepresentative);
		$("#tbl_estimate_info #suppliersFromTel").val(suppliersObj.tel);
		$("#tbl_estimate_info #suppliersFromFax").val(suppliersObj.fax);
	} else 	{
		$tr.find("[data-db-key=suppliersToName]").val(suppliersObj.suppliersName);
		$tr.find("[data-db-key=suppliersToNo]").val(suppliersObj.suppliersNo);
		$("#tbl_estimate_info #suppliersToPostalCode").val(suppliersObj.postalCode);
	    $("#tbl_estimate_info #suppliersToAddress1").val(suppliersObj.address1);
	    $("#tbl_estimate_info #suppliersToAddress2").val(suppliersObj.address2);
	    $("#tbl_estimate_info #suppliersToAddress3").val(suppliersObj.address3);
	    $("#tbl_estimate_info #suppliersToAddress4").val(suppliersObj.address4);
	    $("#tbl_estimate_info #suppliersToPepresentative").val(suppliersObj.pepresentative);
	    $("#tbl_estimate_info #suppliersToTel").val(suppliersObj.tel);
	    $("#tbl_estimate_info #suppliersToFax").val(suppliersObj.fax);
    }

	$("#popup_ok").click();
};

/**
 * 旅程表印刷画面開く
 *
 * @param el イベント発火エレメント
 *  */
s40f001_util.prototype._print = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {travelNo : $(el).closest("tr").find("[data-db-key=travelNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#div_estimate_print"), data);
			$s.com.set_val($("#div_estimate_print"), data.tbl_travel_estimate_info);
			$s.com.set_val($("#div_estimate_print"), {tbl_itinerary_list_print : data.tbl_itinerary_list});
			var printWindow = {};
			if ($s.com.clientType == "sp") {
                // iOs対応
				$("#div_estimate_print").parent("div").css("display","block");
		        $("#div_travel_estimate_list").css("display","none");
		        $("#div_travel_estimate_edit").css("display","none");
		        $("#div_travel_estimate_data").css("display","none");
		        $("#conditions").css("display","none");
            } else {
    			printWindow = window.open("","PrintWindow" , '_blank');
    			printWindow.document.open();

    			var title = $("#div_estimate_print #suppliersNameTo").text() + "_" + $("#div_estimate_print #courseName").text();

    			printWindow.document.write("<HTML><HEAD><title>" + title + "</title><style>@media print{.no_print{display:none;}}</style><HEAD><BODY style='max-width:900px;margin-bottom:10px;'><input type='button' class='no_print' style='position: absolute;top:5px;' value='印刷' onclick='window.print();' />" + $("#div_estimate_print").html() + "</BODY></HTML>");
            }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * 見積書印刷画面開く
 *
 * @param el イベント発火エレメント
 *  */
s40f001_util.prototype._print2 = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {travelNo : $(el).closest("tr").find("[data-db-key=travelNo]").val()};
	var callback = {
		done : function(data, status, xhr){
			data.tbl_travel_estimate_info.amountSum1 = data.amountSum1;
			data.tbl_travel_estimate_info.amountSumTotal1 = data.amountSumTotal1;
			data.tbl_travel_estimate_info.amountSum2 = data.amountSum2;
			data.tbl_travel_estimate_info.amountTotal = data.amountTotal;
//			$s.com.set_val($("#div_estimate_print2"), data);
			$("#div_estimate_print2 #companyStamp").attr('src',$s.context + '/css/images/print/company_stamp.png');
			$s.com.set_val($("#div_estimate_print2"), data.tbl_travel_estimate_info);
			$s.com.set_val($("#div_estimate_print2"), {"tbl_lodging_list_print" : data.tbl_lodging_list});
			$s.com.set_val($("#div_estimate_print2"), {"tbl_expenses_list_print" : data.tbl_expenses_list});
			var printWindow = {};
			if ($s.com.clientType == "sp") {
                // iOs対応
				$("#div_estimate_print2").parent("div").css("display","block");
		        $("#div_travel_estimate_list").css("display","none");
		        $("#div_travel_estimate_edit").css("display","none");
		        $("#div_travel_estimate_data").css("display","none");
		        $("#conditions").css("display","none");
            } else {
    			printWindow = window.open("","PrintWindow" , '_blank');
    			printWindow.document.open();

    			var title = $("#div_estimate_print2 #suppliersToName").text() + "_" + $("#div_estimate_print2 #matterName").text();

    			printWindow.document.write("<HTML><HEAD><title>" + title + "</title><style>@media print{.no_print{display:none;}}</style><HEAD><BODY style='max-width:900px;margin-bottom:10px;'><input type='button' class='no_print' style='position: absolute;top:5px;' value='印刷' onclick='window.print();' />" + $("#div_estimate_print2").html() + "</BODY></HTML>");
            }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};