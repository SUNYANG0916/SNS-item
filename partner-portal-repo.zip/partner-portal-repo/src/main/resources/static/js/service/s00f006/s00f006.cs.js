/*************************
 * s00f006-ユーザパスワードリマインド.
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f006 = new s00f006_util();
        $("#h_title").text("パスワードリマインド");
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f006_util = function(){
    if ((this instanceof s00f006_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
};

/**
 * イベントの初期化.
 * */
s00f006_util.prototype.event_init = function(e) {
    // クリック_更新ボタン
    $("#a_mail").on('click', function(e){ $s.s00f006._mail(this); });
    // クリック_更新ボタン
    $("#btn_return").on('click', function(e){
    	window.location.href = $s.context + "/user/login";
    });
};

/**
 * パスワードリマインド.
 *
 * @param el イベント発火エレメント
 *  */
s00f006_util.prototype._mail = function(el) {
	var passwordCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) passwordCheckList[passwordCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(passwordCheckList, "#applycationForm") == true) {
		var opt = {title: "確認",msg:"送信します。よろいですか？", type:"confirm"};
		opt.fnc_ok = function(el) {
		    var send_data = {};
		    $("table#tbl_password_reminder_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
		    $s.com.ajax("POST", "/passwordReset_mail", send_data, null, "/passwordReset_mail");
		}
	    $s.apply._showPopup(opt);
	} else {
		$s.apply._showInputErrPopup();
	}
};

