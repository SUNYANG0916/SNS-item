//作成日時：2019/09/10 23:10:50
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_conditions",className:"sa-form-container",elems:[
 {tag:"div",id:"conditions",className:"ui-grid-b ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(75% - 110px);",elems:[
   {tag:"input",type:"text",id:"cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:110px;padding-top:2px;",elems:[
   {tag:"select",id:"selDelete",name:"selDelete"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-c",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_project_data",elems:[
 {tag:"table",id:"tbl_project_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_project_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:150px;",elems:[
     {tag:"label",text:"プロジェクト",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:150px;",elems:[
     {tag:"label",text:"期間",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"種別",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"契約形態",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"コピー",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",style:"height:475px;",elems:[
   {tag:"tr","data-db-key":"selTr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",style:"font-size: 12px;",elems:[
      {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
     ]}
    ]}
   ,{tag:"td",style:"width:150px;",elems:[
     {tag:"label","data-db-key":"pjCd",id:"pjCd",name:"pjCd",style:"display:none;"}
    ,{tag:"label","data-db-key":"pjNm",id:"pjNm",name:"pjNm",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMM",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"periodE",id:"periodE",name:"periodE",className:"FMT_YYYYMM",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"pjType",id:"pjType",name:"pjType",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:100px;text-align:center;",elems:[
     {tag:"label","data-db-key":"agreeType",id:"agreeType",name:"agreeType",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"copy",name:"copy",className:"ui-btn ui-icon-recycle ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"text-align:center;background-color:#ddd;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"padding-right:10px;",colSpan:"5",elems:[
     {tag:"a",text:"CSVアップロード",id:"btn_csv_upload",name:"btn_csv_upload",style:"margin:auto;cursor: hand; cursor:pointer;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_project_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
 {tag:"form",id:"form_projest",elems:[
  {tag:"table",id:"tbl_project_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"プロジェクト",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"pjNm",text:"プロジェクト名",id:"pjNm",name:"pjNm",style:"width:95%;",placeholder:"××システム開発",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"pjCd",id:"pjCd",name:"pjCd"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"期間",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
        {tag:"label",text:"開始日",style:"font-size: 12px;"}
       ,{tag:"input",type:"date","data-db-key":"periodS",id:"periodS",name:"periodS",style:"font-size: 10px;"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
        {tag:"label",text:"終了日",style:"font-size: 12px;"}
       ,{tag:"input",type:"date","data-db-key":"periodE",id:"periodE",name:"periodE",style:"font-size: 10px;"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"プロジェクト種別",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"pjType",id:"selPjType",name:"selPjType"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"契約形態",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"agreeType",id:"selAgreeType",name:"selAgreeType"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"取引先",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-b",elems:[
       {tag:"div",className:"ui-block-a",style:"width:50px;",elems:[
        {tag:"input",type:"text","data-db-key":"suppliersNo",id:"suppliersNo",name:"suppliersNo",style:"background-color:#ddd;",readOnly:"True"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 90px);",elems:[
        {tag:"input",type:"text","data-db-key":"suppliersName",id:"suppliersName",name:"suppliersName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
       ]}
      ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
        {tag:"a",id:"a_suppliers",name:"a_suppliers",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"時間",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
        {tag:"label",text:"下限",style:"font-size: 12px;"}
       ,{tag:"input",type:"number","data-db-key":"pjTimesMin",id:"pjTimesMin",name:"pjTimesMin"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
        {tag:"label",text:"上限",style:"font-size: 12px;"}
       ,{tag:"input",type:"number","data-db-key":"pjTimesMax",id:"pjTimesMax",name:"pjTimesMax"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"作業場所",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"pjWorkLot",id:"pjWorkLot",name:"pjWorkLot",style:"width:95%;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"数量",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
        {tag:"input",type:"number","data-db-key":"quantity",name:"quantity",style:"font-size: 12px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"1"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
        {tag:"select","data-db-key":"unitPrice",name:"selUnitPrice"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"金額",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
        {tag:"input",type:"number","data-db-key":"amount",name:"amount",style:"font-size: 12px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"1"}
       ]}
      ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
        {tag:"select","data-db-key":"taxType",name:"selTaxType"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"備考",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"pjNote",id:"pjNote",name:"pjNote",style:"width:100%;"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-b",style:"margin-top:10px;",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"廃止",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-c",elems:[
    {tag:"a",text:"戻る",id:"btn_return",name:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"master_suppliers",style:"display:none;",elems:[
 {tag:"div",id:"master_suppliers_cont",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_suppliers_cond",name:"master_suppliers_cond"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_suppliers_search",name:"btn_master_suppliers_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_suppliers_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_suppliers_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selSuppliersTr",name:"selSuppliersTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_suppliers",name:"a_sel_suppliers",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersNo",name:"suppliersNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersName",name:"suppliersName",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"form",id:"formCsvFile",style:"display:none;",elems:[
 {tag:"input",type:"file","data-db-key":"csvfile",id:"csvfile",name:"csvfile"}
]}
];

