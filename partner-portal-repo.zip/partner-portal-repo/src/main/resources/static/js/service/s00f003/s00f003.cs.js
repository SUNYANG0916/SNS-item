/*************************
 * s00f003-ユーザパスワード更新.
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f003 = new s00f003_util();
        $("#h_title").text("パスワード変更");
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f003_util = function(){
    if ((this instanceof s00f003_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    // デフォルトチェック
    $("#inp_cond_flg").prop("checked",true);
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_pass_edit")[0]);
    }
};

/**
 * イベントの初期化.
 * */
s00f003_util.prototype.event_init = function(e) {
    // クリック_更新ボタン
    $("#a_update").on('click', function(e){ $s.s00f003._update(this); });
};

/**
 * パスワード登録更新.
 *
 * @param el イベント発火エレメント
 *  */
s00f003_util.prototype._update = function(el) {
	var educCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) educCheckList[educCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(educCheckList, "#applycationForm") == true) {
		var opt = {title: "確認",msg:"登録します。よろいですか？", type:"confirm"};
		opt.fnc_ok = function(el) {
		    var send_data = {};
		    $("table#tbl_pass_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
		    $s.com.ajax("GET", "_update", send_data, {});
		}
	    $s.apply._showPopup(opt);
	} else {
		$s.apply._showInputErrPopup();
	}
};

