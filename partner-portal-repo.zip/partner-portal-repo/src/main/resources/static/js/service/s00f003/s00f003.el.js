//作成日時：2019/07/06 0:24:13
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_pass_edit",className:"sa-form-container-wide",elems:[
  {tag:"table",id:"tbl_pass_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"パスワード（現在）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"password","data-db-key":"password",id:"password",name:"password",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"パスワード（新）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"password","data-db-key":"passwordNew",id:"passwordNew",name:"passwordNew",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"パスワード（確認）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"password",id:"passwordConfir",name:"passwordConfir",style:"width:95%;",validate:"{\"rules\":{\"equalTo\":\"#passwordNew\"},\"message\":{\"equalTo\":\"確認パスワード不一致。\"}}"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",elems:[
   {tag:"a",text:"登録",id:"a_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ]}
]}
];

