//作成日時：2019/09/09 11:02:21
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
 {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
  {tag:"label","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn",style:"padding:7px;margin:0px;"}
 ]}
,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
  {tag:"a",text:"戻る",id:"a_rtn_list",name:"a_rtn_list",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
 ]}
]}
,{tag:"div",id:"div_apply",className:"sa-form-container",elems:[
 {tag:"div",id:"div_ctrl",className:"ui-grid-b ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:50%;","data-role":"navbar",elems:[
   {tag:"div",className:"ui-grid-b",elems:[
    {tag:"div",className:"ui-block-a",style:"width:25%;margin-top:10px;",elems:[
     {tag:"a",text:"<",id:"a_apply_back",name:"a_apply_back",className:"afr_upd ui-btn ui-corner-all",style:"padding:7px;"}
    ]}
   ,{tag:"div",className:"ui-block-b",style:"width:40%;margin-top:5px;",elems:[
     {tag:"input",type:"text",id:"inp_apply_ym",name:"inp_apply_ym",className:"ui-btn ui-corner-all",style:"padding:8px;text-align:center;font-size: 12px;"}
    ]}
   ,{tag:"div",className:"ui-block-c",style:"width:25%;margin-top:10px;",elems:[
     {tag:"a",text:">",id:"a_apply_next",name:"a_apply_next",className:"afr_upd ui-btn ui-corner-all",style:"padding:7px;"}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:50%;margin-top:6px;",elems:[
   {tag:"select",id:"selSearchType",name:"selSearchType"}
  ]}
 ]}
]}
,{tag:"div",id:"div_apply_list",elems:[
 {tag:"table",id:"tbl_apply_list",className:"scroll_table",style:"width:100%;margin-top:5px;margin-bottom:20px;",list_id:"tbl_apply_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",text:"追加",name:"a_add",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"対象日",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"申請内容",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"金額",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:0px;"}
    ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
    ,{tag:"input",type:"hidden","data-db-key":"settleType",name:"settleType"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"occurDate",name:"occurDate",className:"FMT_DD",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"transRootStart",name:"transRootStart",style:"float:left;margin-left:5px;font-size: 12px;display:none;"}
    ,{tag:"label","data-db-key":"transSymbol",text:"‐",name:"transSymbol",style:"float:left;margin-left:5px;font-size: 12px;display:none;"}
    ,{tag:"label","data-db-key":"transRootEnd",name:"transRootEnd",style:"float:left;margin-left:5px;font-size: 12px;display:none;"}
    ,{tag:"label","data-db-key":"expType",name:"expType",style:"float:left;margin-left:5px;font-size: 12px;display:none;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"label","data-db-key":"settleAmount",name:"settleAmount",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"note",name:"note",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",text:"追加",name:"a_add",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"text-align:center;",colSpan:"2"}
   ,{tag:"th",style:"text-align:center;",elems:[
     {tag:"label",id:"amountSum",name:"amountSum",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"text-align:center;"}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_apply_edit",style:"display:none;margin:auto;",elems:[
 {tag:"form",id:"updateForm",elems:[
  {tag:"table",id:"tbl_apply_info",className:"sa-form",style:"margin-top:10px;",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:30%;",elems:[
      {tag:"label",text:"対象日",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:65%;",elems:[
      {tag:"input",type:"date","data-db-key":"occurDate",name:"occurDate",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",id:"sequence",name:"sequence"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"経費・交通費",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"label",text:"交通費",for:"settleType_1",className:"radio",elems:[
         {tag:"input",type:"radio","data-db-key":"settleType",id:"settleType_1",name:"settleType",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"30024-001"}
        ]}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"経費",for:"settleType_2",elems:[
         {tag:"input",type:"radio","data-db-key":"settleType",id:"settleType_2",name:"settleType",className:"radio",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"30024-002"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",id:"trExpType",style:"display:none;",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"経費種類",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"expType",id:"selExpType",name:"selExpType",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",id:"trTransRoot",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"対象ルート",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"input",type:"text","data-db-key":"transRootStart",name:"transRootStart",placeholder:"出発地"}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"input",type:"text","data-db-key":"transRootEnd",name:"transRootEnd",placeholder:"到着地"}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",id:"trTransAmount",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"金額(片道)",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"div",className:"ui-grid-a",elems:[
       {tag:"div",className:"ui-block-a",elems:[
        {tag:"input",type:"number","data-db-key":"tripAmount",id:"tripAmount",name:"tripAmount",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"1"}
       ]}
      ,{tag:"div",className:"ui-block-b",elems:[
        {tag:"label",text:"往復",for:"roundTrip",elems:[
         {tag:"input",type:"checkbox","data-db-key":"roundTrip",id:"roundTrip",name:"roundTrip",value:"1"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"金額",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"number","data-db-key":"settleAmount",id:"settleAmount",name:"settleAmount",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"0"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"備考（理由）",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"note",name:"note",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",className:"sa-form",style:"margin-bottom:20px;",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:30%;",elems:[
     {tag:"label",text:"領収書（申請情報を登録してからアップロードしてください）",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",elems:[
     {tag:"table",id:"tbl_tmp_list",style:"width:100%;",list_id:"tbl_tmp_list",elems:[
      {tag:"tBody",elems:[
       {tag:"tr",elems:[
        {tag:"td",style:"width:60%;",elems:[
         {tag:"a","data-db-key":"tmpFileName",name:"tmpFileName",className:"ui-btn ui-corner-all",style:"text-decoration: underline;color: blue;"}
        ]}
       ,{tag:"td",style:"width:35%;",elems:[
         {tag:"a",text:"削除",name:"tmpFileDelete",className:"ui-btn ui-corner-all",style:"background-color: tomato;color: #fff"}
        ]}
       ]}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",elems:[
     {tag:"table",style:"width:100%;",elems:[
      {tag:"tBody",elems:[
       {tag:"tr",elems:[
        {tag:"td",style:"width:60%;",elems:[
         {tag:"a",text:"ファイル選択",id:"btn_tp_file",name:"btn_tp_file",className:"ui-btn ui-corner-all"}
        ]}
       ,{tag:"td",style:"width:35%;",elems:[
         {tag:"a",text:"＋upload",id:"btn_tp_upload",name:"btn_tp_upload",className:"ui-btn ui-corner-all",style:"background-color: #38c;color: #fff"}
        ,{tag:"form",id:"formTmpFile",style:"display:none;",elems:[
          {tag:"input",type:"file","data-db-key":"tmpfile",id:"tmpfile",name:"tmpfile"}
         ]}
        ]}
       ]}
      ]}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-top:10px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"削除",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",name:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"divWkUpload",className:"ui-grid-a",elems:[
 {tag:"div",className:"ui-block-a",style:"width:50%;margin-top:6px;",elems:[
  {tag:"a",text:"ファイル選択",id:"btn_wk_file",name:"btn_wk_file",className:"ui-btn ui-corner-all"}
 ]}
,{tag:"div",className:"ui-block-b",style:"width:50%;margin-top:6px;",elems:[
  {tag:"a",text:"アップロード",id:"btn_wk_upload",name:"wk_file_name",className:"ui-btn ui-corner-all",style:"background-color: #38c;color: #fff"}
 ,{tag:"form",id:"formWkFile",style:"display:none;",elems:[
   {tag:"input",type:"file",id:"wkFile",name:"wkFile"}
  ]}
 ]}
]}
,{tag:"div",id:"divWkDownload",className:"ui-grid-a",style:"display:none;",elems:[
 {tag:"div",className:"ui-block-a",style:"width:50%;margin-top:6px;",elems:[
  {tag:"a",text:"ダウンロード",id:"btn_wk_download",name:"btn_wk_download",className:"ui-btn ui-corner-all",style:"text-decoration: underline;color: blue;"}
 ]}
,{tag:"div",className:"ui-block-b",style:"width:50%;margin-top:6px;",elems:[
  {tag:"a",text:"削除",id:"btn_wk_delete",name:"btn_wk_delete",className:"ui-btn ui-corner-all",style:"background-color: tomato;color: #fff"}
 ]}
]}
];

