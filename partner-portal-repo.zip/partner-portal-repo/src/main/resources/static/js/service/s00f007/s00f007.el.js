//作成日時：2019/09/22 23:03:41
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_rolegrp_list",elems:[
 {tag:"table",id:"tbl_rolegrp_list",name:"tbl_rolegrp_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_rolegrp_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;"}
   ,{tag:"th",elems:[
     {tag:"label",text:"ロールグループ",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"aEdit",name:"aEdit",style:"font-size: 12px;",elems:[
      {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
     ]}
    ,{tag:"input",type:"hidden","data-db-key":"itemVal",name:"roleGrpId"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"label","data-db-key":"itemTxt",name:"roleGrpNm",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_role_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
 {tag:"table",id:"tbl_role_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ロールグループ",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"roleGrp",id:"roleGrp",name:"roleGrp",style:"width:95%;font-size: 12px;",readOnly:"True"}
    ,{tag:"input",type:"hidden","data-db-key":"roleGrpId",id:"roleGrpId",name:"roleGrpId",style:"background-color:#ddd;",readOnly:"True"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_role_list",name:"tbl_role_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_role_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_role_list_add",name:"tbl_role_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"ロール",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",name:"tbl_role_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:80px;",elems:[
       {tag:"input",type:"text","data-db-key":"roleId",name:"roleId",style:"background-color:#ddd;",readOnly:"True"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 120px);",elems:[
       {tag:"input",type:"text","data-db-key":"roleNm",name:"roleNm",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aRole",name:"aRole",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_role_list_add",name:"tbl_role_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th"}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-a",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"master_roles",style:"display:none;",elems:[
 {tag:"div",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_roles_cond",name:"master_roles_cond",maxlength:"キーワード検索"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_roles_search",name:"btn_master_roles_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_master_roles_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_master_roles_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"ロールID",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"ロール名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selRolesTr",name:"selRolesTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_role",name:"a_sel_role",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"roleId",name:"roleId",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"roleNm",name:"roleNm",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
];

