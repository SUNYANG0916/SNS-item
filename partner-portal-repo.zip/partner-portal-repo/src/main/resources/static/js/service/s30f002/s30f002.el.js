//作成日時：2019/09/29 23:14:05
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_estimate_info_edit",className:"sa-form-container",elems:[
 {tag:"div",id:"conditions",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(75% - 110px);",elems:[
   {tag:"input",type:"text",id:"cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:110px;padding-top:2px;",elems:[
   {tag:"select",id:"selDelete",name:"selDelete"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_order_list",style:"margin-top:0px;",elems:[
 {tag:"table",id:"tbl_order_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_order_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"件名",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"期間",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"注文書",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"コピー",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ,{tag:"input",type:"hidden","data-db-key":"orderNo",name:"orderNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"matterName",name:"matterName",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"label","data-db-key":"periodS",name:"periodS",className:"FMT_YYYYMM",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"periodE",name:"periodE",className:"FMT_YYYYMM",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"output",name:"output",className:"ui-btn ui-icon-action ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"copy",name:"copy",className:"ui-btn ui-icon-recycle ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_order_edit",style:"display:none;",elems:[
 {tag:"table",id:"tbl_order_info",name:"tbl_order_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40%;",colSpan:"2",elems:[
     {tag:"label",text:"注文書番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:60%;",elems:[
     {tag:"input",type:"text","data-db-key":"orderNo",id:"orderNo",name:"orderNo",style:"width:100%;background-color:#ddd;",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",colSpan:"2",elems:[
     {tag:"label",text:"件名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"matterName",id:"matterName",name:"matterName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"期間",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"label",text:"開始日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"periodS",id:"periodS",name:"periodS",style:"font-size: 10px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"label",text:"終了日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"periodE",id:"periodE",name:"periodE",style:"font-size: 10px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"契約形態",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"agreementType",id:"selAgreementType",name:"selAgreementType"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"納品日",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"date","data-db-key":"releaseDate",id:"releaseDate",name:"releaseDate",style:"width:90%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"納品場所",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"releaseLot",id:"releaseLot",name:"releaseLot",style:"width:95%;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",colSpan:"2",elems:[
     {tag:"label",text:"御支払条件",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"paymentTime",id:"selPaymentTime",name:"selPaymentTime",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:100px;",colSpan:"2",elems:[
     {tag:"label",text:"支払手数料",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"commissionType",id:"selCommissionType",name:"selCommissionType",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"発注先",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"社名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50px;",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToNo",id:"suppliersToNo",name:"suppliersToNo",style:"background-color:#ddd;",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 90px);",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aSuppliersTo",name:"aSuppliersTo",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",style:"display:none;",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"住所",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"suppliersToPostalCode",id:"suppliersToPostalCode",name:"suppliersToPostalCode",readOnly:"True"}
    ,{tag:"input",type:"text","data-db-key":"suppliersToAddress1",id:"suppliersToAddress1",name:"suppliersToAddress1",readOnly:"True",placeholder:"都道府県"}
    ,{tag:"input",type:"text","data-db-key":"suppliersToAddress2",id:"suppliersToAddress2",name:"suppliersToAddress2",readOnly:"True",placeholder:"市区町村"}
    ,{tag:"input",type:"text","data-db-key":"suppliersToAddress3",id:"suppliersToAddress3",name:"suppliersToAddress3",readOnly:"True",placeholder:"番地以降"}
    ,{tag:"input",type:"text","data-db-key":"suppliersToAddress4",id:"suppliersToAddress4",name:"suppliersToAddress4",readOnly:"True",placeholder:"ビル名／部屋"}
    ]}
   ]}
  ,{tag:"tr",style:"display:none;",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表者",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"suppliersToPepresentative",id:"suppliersToPepresentative",name:"suppliersToPepresentative",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",style:"display:none;",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"TEL",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"suppliersToTel",id:"suppliersToTel",name:"suppliersToTel",readOnly:"True"}
    ,{tag:"input",type:"tel","data-db-key":"suppliersToFax",id:"suppliersToFax",name:"suppliersToFax",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",rowSpan:"9",elems:[
     {tag:"label",text:"発注元",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"社名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50px;",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersFromNo",id:"suppliersFromNo",name:"suppliersFromNo",style:"background-color:#ddd;",readOnly:"True"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 90px);",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersFromName",id:"suppliersFromName",name:"suppliersFromName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aSuppliersFrom",name:"aSuppliersFrom",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"住所",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"suppliersFromPostalCode",id:"suppliersFromPostalCode",name:"suppliersFromPostalCode",readOnly:"True"}
    ,{tag:"input",type:"text","data-db-key":"suppliersFromAddress1",id:"suppliersFromAddress1",name:"suppliersFromAddress1",readOnly:"True",placeholder:"都道府県"}
    ,{tag:"input",type:"text","data-db-key":"suppliersFromAddress2",id:"suppliersFromAddress2",name:"suppliersFromAddress2",readOnly:"True",placeholder:"市区町村"}
    ,{tag:"input",type:"text","data-db-key":"suppliersFromAddress3",id:"suppliersFromAddress3",name:"suppliersFromAddress3",readOnly:"True",placeholder:"番地以降"}
    ,{tag:"input",type:"text","data-db-key":"suppliersFromAddress4",id:"suppliersFromAddress4",name:"suppliersFromAddress4",readOnly:"True",placeholder:"ビル名／部屋"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"代表者",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"suppliersFromPepresentative",id:"suppliersFromPepresentative",name:"suppliersFromPepresentative",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"TEL",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"tel","data-db-key":"suppliersFromTel",id:"suppliersFromTel",name:"suppliersFromTel",readOnly:"True"}
    ,{tag:"input",type:"tel","data-db-key":"suppliersFromFax",id:"suppliersFromFax",name:"suppliersFromFax",readOnly:"True"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_working_list",name:"tbl_working_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_working_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",id:"tbl_working_list_add",name:"tbl_working_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"項目",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text",name:"workingInfo",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ,{tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",style:"width:60px;",elems:[
     {tag:"label",text:"数量",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"number",name:"quantity",style:"display:none;",validate:"{\"rules\":{\"required\":true,\"min\":0},\"message\":{\"required\":\"必須項目です。\",\"min\":\"0以上入力してください。\"}}",value:"1"}
    ]}
   ,{tag:"th",style:"width:90px;",elems:[
     {tag:"label",text:"単価",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"number",name:"unitAmount",style:"display:none;",validate:"{\"rules\":{\"required\":true,\"min\":0},\"message\":{\"required\":\"必須項目です。\",\"min\":\"0以上入力してください。\"}}",value:"0",step:"50000"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"金額",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:100px;",elems:[
     {tag:"label",text:"稼働日・営業日",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"number",name:"workingDays",style:"display:none;",validate:"{\"rules\":{\"required\":true,\"min\":0},\"message\":{\"required\":\"必須項目です。\",\"min\":\"0以上入力してください。\"}}",value:"0",step:"10"}
    ,{tag:"input",type:"number",name:"businessDays",style:"display:none;",validate:"{\"rules\":{\"required\":true,\"min\":0},\"message\":{\"required\":\"必須項目です。\",\"min\":\"0以上入力してください。\"}}",value:"0",step:"10"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",name:"tbl_working_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",colSpan:"2",elems:[
     {tag:"input",type:"text","data-db-key":"workingInfo",name:"workingInfo"}
    ]}
   ,{tag:"td",colSpan:"2",elems:[
     {tag:"input",type:"text","data-db-key":"note",name:"note",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",style:"width:40px;",elems:[
     {tag:"input",type:"number","data-db-key":"quantity",name:"quantity",style:"font-size: 12px;margin-left:5px;text-align:right;",value:"1"}
    ]}
   ,{tag:"td",style:"width:50px;",elems:[
     {tag:"input",type:"number","data-db-key":"unitAmount",name:"unitAmount",style:"font-size: 12px;text-align:center;",value:"0",step:"50000"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"amount",name:"amount",style:"font-size: 12px;text-align:center;",value:"0"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:40px;",elems:[
       {tag:"input",type:"number","data-db-key":"workingDays",name:"workingDays",style:"font-size: 12px;text-align:right;",value:"0",step:"10"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:40px;",elems:[
       {tag:"input",type:"number","data-db-key":"businessDays",name:"businessDays",style:"font-size: 12px;text-align:right;",value:"0",step:"10"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_working_list_add",name:"tbl_working_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"calculation",name:"calculation",style:"margin:auto;cursor: hand; cursor:pointer;",elems:[
      {tag:"label",text:"再計算",style:"font-size: 12px;text-align:center;cursor: hand; cursor:pointer;"}
     ]}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"総額(税込)",style:"font-size: 12px;text-align:center;"}
    ]}
   ,{tag:"th",colSpan:"2",elems:[
     {tag:"label","data-db-key":"amountTotal",id:"amountTotal",name:"amountTotal",style:"font-size: 12px;text-align:left;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"口座番号"}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-bottom:50px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"廃止",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"master_suppliers",style:"display:none;",elems:[
 {tag:"div",id:"master_suppliers_cont",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_suppliers_cond",name:"master_suppliers_cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_suppliers_search",name:"btn_master_suppliers_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_suppliers_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_suppliers_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"取引先名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selSuppliersTr",name:"selSuppliersTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_suppliers",name:"a_sel_suppliers",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersNo",name:"suppliersNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"suppliersName",name:"suppliersName",style:"font-size: 12px;"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersJson",name:"suppliersJson"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"master_postal",style:"display:none;",elems:[
 {tag:"table",id:"tbl_postal_list",className:"scroll_table",style:"margin-left:auto;margin-right:0px;",list_id:"tbl_postal_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"郵便番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"住所",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selPostalTr",name:"selPostalTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_postal",name:"a_sel_postal",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"zipCd",name:"zipCd",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"todoufukenKanji",name:"todoufukenKanji",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"sikutyousonKanji",name:"sikutyousonKanji",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"tyouikiKanji",name:"tyouikiKanji",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",style:"display:none;",elems:[
 {tag:"div",id:"div_order_print",elems:[
  {tag:"div",style:"text-align:right;",elems:[
   {tag:"label",text:"注文番号."}
  ,{tag:"label","data-db-key":"orderNo",id:"orderNo",name:"orderNo",style:"margin-left:10px;"}
  ]}
 ,{tag:"div",style:"width:100%;margin-top:20px;margin-bottom:20px;padding-top:10px;padding-bottom:10px;text-align:center;border-style:double; border-width:3px;border-left:none;border-right:none;",elems:[
   {tag:"label",text:"注　　文　  書",style:"font-size: 24px;"}
  ]}
 ,{tag:"div",elems:[
   {tag:"label","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName",style:"border-bottom: 1px solid black;padding-right:20px;"}
  ,{tag:"label",text:"殿",style:"border-bottom: 1px solid black;"}
  ]}
 ,{tag:"div",elems:[
   {tag:"table",style:"max-width:50%;margin-left:auto;margin-right:0px;",elems:[
    {tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label","data-db-key":"suppliersFromName",id:"suppliersFromName",name:"suppliersFromName"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"〒",style:"margin-right:5px;"}
      ,{tag:"label","data-db-key":"suppliersFromPostalCode",name:"suppliersFromPostalCode",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"suppliersFromAddress1",name:"suppliersFromAddress1"}
      ,{tag:"label","data-db-key":"suppliersFromAddress2",name:"suppliersFromAddress2"}
      ,{tag:"label","data-db-key":"suppliersFromAddress3",name:"suppliersFromAddress3"}
      ,{tag:"label","data-db-key":"suppliersFromAddress4",name:"suppliersFromAddress4"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label","data-db-key":"suppliersFromPepresentative",name:"suppliersFromPepresentative"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"TEL",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"suppliersFromTel",id:"suppliersFromTel",name:"suppliersFromTel",style:"margin-right:20px;"}
      ,{tag:"label",text:"FAX",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"suppliersFromFax",id:"suppliersFromFax",name:"suppliersFromFax"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",id:"tbl_order_info_print",name:"tbl_order_info_print",style:"width:100%;margin-bottom:10px;",list_id:"tbl_estimate_info_print",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",style:"background-color:#ddd;",elems:[
     {tag:"td",style:"width:150px;",elems:[
      {tag:"label",text:"件名"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"matterName",id:"matterName",name:"matterName"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"作業期間"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"periodS",id:"periodS",name:"periodS",className:"FMT_YYYYMMDD"}
     ,{tag:"label",text:"～"}
     ,{tag:"label","data-db-key":"periodE",id:"periodE",name:"periodE",className:"FMT_YYYYMMDD"}
     ]}
    ]}
   ,{tag:"tr",style:"background-color:#ddd;",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"契約形態"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"agreementTypeName",name:"agreementTypeName"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",style:"vertical-align:top;",elems:[
      {tag:"label",text:"納品日"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"releaseDate",name:"releaseDate",className:"FMT_YYYYMMDD",style:"margin-right:10px;"}
     ]}
    ]}
   ,{tag:"tr",style:"background-color:#ddd;",elems:[
     {tag:"td",style:"vertical-align:top;",elems:[
      {tag:"label",text:"納品場所"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"releaseLot",name:"releaseLot",style:"margin-right:10px;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"御支払条件",style:"margin-right:10px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"paymentTimeName",name:"paymentTimeName",style:"margin-right:10px;"}
     ,{tag:"label",text:"(該当日が休日の場合、金融機関の翌営業日)",name:"paymentTimeComment",style:"margin-right:10px;"}
     ]}
    ]}
   ,{tag:"tr",style:"background-color:#ddd;",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"振込手数料"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"commissionTypeName",name:"commissionTypeName"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"業務委託責任者"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"company",name:"company"}
     ,{tag:"label","data-db-key":"suppliersToPepresentative",name:"suppliersToPepresentative"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",style:"font-size:20px;margin-top:20px;margin-bottom:30px;padding-top:10px;padding-bottom:10px;text-align:center;",elems:[
   {tag:"label",text:"注文金額",style:"padding-right:10px;border-bottom: 1px solid black;"}
  ,{tag:"label","data-db-key":"amountTotal",id:"amountTotal",name:"amountTotal",className:"FMT_AMOUNT",style:"border-bottom: 1px solid black;"}
  ,{tag:"label",text:"円  (消費税含む)",style:"border-bottom: 1px solid black;"}
  ]}
 ,{tag:"table",id:"tbl_working_list_print",style:"width:100%;border:1px gray;",list_id:"tbl_working_list_print",rules:"all",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"NO"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"項目"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"稼働日"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"営業日"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"単  価"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"数 量(人月)"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"金額"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"備考"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:40px;text-align:right;",elems:[
      {tag:"label","data-db-key":"row_no",name:"row_no",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"padding-right:10px;",elems:[
      {tag:"label","data-db-key":"workingInfo",name:"workingInfo",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"text-align:center;padding-right:10px;width:70px;",elems:[
      {tag:"label","data-db-key":"workingDays",name:"workingDays",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"text-align:center;padding-right:10px;width:70px;",elems:[
      {tag:"label","data-db-key":"businessDays",name:"businessDays",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"text-align:right;width:100px;padding-right:10px;",elems:[
      {tag:"label","data-db-key":"unitAmount",name:"unitAmount",className:"FMT_AMOUNT",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"text-align:center;width:100px;",elems:[
      {tag:"label","data-db-key":"quantity",name:"quantity",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"text-align:right;width:100px;padding-right:10px;",elems:[
      {tag:"label","data-db-key":"amount",name:"amount",className:"FMT_AMOUNT",style:"font-size: 14px;"}
     ]}
    ,{tag:"td",style:"padding-right:10px;",elems:[
      {tag:"label","data-db-key":"note",name:"note",style:"font-size: 14px;"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"text-align:center;background-color:#ddd;",colSpan:"4",elems:[
      {tag:"label",text:"合　計"}
     ]}
    ,{tag:"td",style:"padding-right:10px;",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"税　抜"}
      ]}
     ,{tag:"div",style:"text-align:right;",elems:[
       {tag:"label","data-db-key":"amountSum",name:"amountSum",className:"FMT_AMOUNT",style:"font-size: 14px;",value:"0"}
      ]}
     ]}
    ,{tag:"td",style:"padding-right:10px;",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"消 費 税"}
      ]}
     ,{tag:"div",style:"text-align:right;",elems:[
       {tag:"label","data-db-key":"amountTax",name:"amountTax",className:"FMT_AMOUNT",style:"font-size: 14px;",value:"0"}
      ]}
     ]}
    ,{tag:"td",style:"padding-right:10px;",elems:[
      {tag:"div",elems:[
       {tag:"label",text:"総　額"}
      ]}
     ,{tag:"div",style:"text-align:right;",elems:[
       {tag:"label","data-db-key":"amountTotal",name:"amountTotal",className:"FMT_AMOUNT",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"td"}
    ]}
   ]}
  ]}
 ,{tag:"div",style:"margin-top:20px;",elems:[
   {tag:"table",style:"width:100%;border: solid 1px gray;border-collapse: collapse;",elems:[
    {tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"td",style:"width:50px;border: solid 1px gray;border-collapse: collapse;font-size: 12px;",colSpan:"2",elems:[
       {tag:"label",text:"※その他条件"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"１",style:"margin-right:5px;font-size: 14px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",text:"貴社と締結した業務委託契約、個別契約に従うものとします。",style:"margin-right:10px;font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"２",style:"margin-right:5px;font-size: 14px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",text:"注文書受領後5日以内に受諾拒否の申し出がないときは、契約は成立したものとします。",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"３",style:"margin-right:5px;font-size: 14px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",text:"作業場所以外への出張費等が発生した場合は、別途調整とします。",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"４",style:"margin-right:5px;font-size: 14px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",text:"作業時間の控除、ご精算は15分単位。(10円単位切り捨て) ※備考欄を参照",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"５",style:"margin-right:5px;font-size: 14px;"}
      ]}
     ,{tag:"td",elems:[
       {tag:"label",text:"委託期間中に作業従事者に起因する理由(正当な理由なく月間3日以上の遅刻・欠勤、勤怠",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td"}
     ,{tag:"td",elems:[
       {tag:"label",text:"不良、スキル不良、セクハラ行為等)により、顧客先からの注意・減額・契約解除等を受けた場合、",style:"font-size: 14px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td"}
     ,{tag:"td",elems:[
       {tag:"label",text:"委託料・契約期間の相当分について注意・減額・契約解除等を行う場合があります。",style:"font-size: 14px;"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

