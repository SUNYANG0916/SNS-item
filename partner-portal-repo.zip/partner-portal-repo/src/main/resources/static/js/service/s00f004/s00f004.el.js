//作成日時：2019/09/24 23:14:46
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_conditions",className:"sa-form-container",elems:[
 {tag:"div",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:60%;",elems:[
   {tag:"input",type:"text",id:"conditions",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:40%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_user_list",elems:[
 {tag:"table",id:"tbl_user_list",name:"tbl_user_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_user_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:20px;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"社員",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"基本情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"稼働情報",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"作業報告",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"ｽｷﾙｼｰﾄ",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"申請書",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"hidden","data-db-key":"user_row",name:"user_row"}
    ,{tag:"input",type:"hidden","data-db-key":"user_initial",name:"user_initial",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"user_name",name:"user_name",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"hidden","data-db-key":"disp_detail1"}
    ,{tag:"a",elems:_els.getIconElems('document_16'),id:"a_detail1",name:"a_detail1",style:"display:none;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"hidden","data-db-key":"disp_detail8"}
    ,{tag:"a",elems:_els.getIconElems('document_16'),id:"a_detail8",name:"a_detail8",style:"display:none;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"hidden","data-db-key":"disp_detail9"}
    ,{tag:"a",elems:_els.getIconElems('document_16'),id:"a_detail9",name:"a_detail9",style:"display:none;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"hidden","data-db-key":"disp_detail6"}
    ,{tag:"a",elems:_els.getIconElems('file_excel_16'),id:"a_detail6",name:"a_detail6",style:"display:none;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"hidden","data-db-key":"disp_detail7"}
    ,{tag:"a",elems:_els.getIconElems('document_16'),id:"a_detail7",name:"a_detail7",style:"display:none;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_user_edit",className:"sa-form-container-wide",style:"display:none;",elems:[
 {tag:"table",id:"tbl_user_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ユーザコード",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"userCd",id:"userCd",name:"userCd",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ログインID",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"email","data-db-key":"loginId",id:"loginId",name:"loginId",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ログインユーザ名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"loginUserName",id:"loginUserName",name:"loginUserName",style:"width:95%;font-size: 12px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"パスワード",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"password","data-db-key":"password",id:"password",name:"password",style:"width:95%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"部署",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"busyoCd",id:"selBusyoCd",name:"selBusyoCd"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"雇用種類",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"employmentType",id:"selEmploymentType",name:"selEmploymentType"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"在籍状態",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"employmentStatus",id:"selEmploymentStatus",name:"selEmploymentStatus"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"アクセスキー",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"accessKey",id:"accessKey",name:"accessKey"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"アクセスキー有効期限",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"date","data-db-key":"accessKeyExpirDate",id:"accessKeyExpirDate",name:"accessKeyExpirDate"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"アカウントロック",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label",text:"アカウントロック",for:"acountLocked",elems:[
      {tag:"input",type:"checkbox","data-db-key":"acountLocked",id:"acountLocked",name:"acountLocked"}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"ログイン失敗回数",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"number","data-db-key":"loginFailureCount",id:"loginFailureCount",name:"loginFailureCount",maxlength:"2"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"備考",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"note",id:"note",name:"note",style:"width:95%;"}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_role_list",name:"tbl_role_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_role_list",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:50px;",elems:[
     {tag:"a",id:"tbl_role_list_add",name:"tbl_role_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;display:none;"}
    ]}
   ,{tag:"th",style:"width:120px;",elems:[
     {tag:"label",text:"ロール名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"a",name:"tbl_role_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;display:none;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"select","data-db-key":"roleGrpId",id:"selUserRole",name:"selUserRole",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"削除",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
];

