    /**
     * ローカル関数オブジェクト（コンストラクタ）.
     * */
    var apply_util = function(_url) {
        if ((this instanceof apply_util) == false) {
            throw new Error("インスタンス生成失敗しました。");
        }
        this.url = _url;
        this.top = 0;
    };

    /**
     * 編集画面表示制御
     *
     * @param el イベント発火エレメント
     *  */
     apply_util.prototype._init = function() {
        //event.preventDefault();
        $.ajax({
            type: "GET",
            url: this.url,
            dataType:"json",
            success: function(data, status, xhr){
                // 取得データ設定
                $.extend($s._objs, data);
                // 画面エレメント定義
                $s._els = _els;
                // 画面内容初期化
                $s.com.add_els("S_AREA_TITLE", $s._els.APPLY_TITLE);
                // ボディエリア作成
                $s.com.add_els("S_AREA_DATA", $s._els.APPLY_DATA);
                $("#a_user").text($s._objs.loginUser).css("display","");

                // クリック_メニューリンク
                $(document).on("click", "#a_user", function(e){ $s.apply._menu(this); });
                $(document).on("click", "#a_menu", function(e){ $s.apply._open_nume(this); });
                $(document).on("click", "#a_password", function(e){ $s.apply._open_nume(this); });
                $(document).on("click", "#a_logout", function(e){ $s.apply._logout(this); });
                $(document).on("click", "[name=a_list]", function(e){ $s.apply._open_nume(this); });
                $(document).on("click", "input:checkbox", function(e){ $s.apply._checkbox_chage(this); });
                $(document).on('change', 'input[type="checkbox"]', function() {
                	$s.apply._checkbox_chage(this);
                });
                $(document).on('click',  function(e) {
                    if (!$(e.target).closest('div #S_MENU').length && ($(e.target).attr("id")!= "a_user")) {
                        $("#S_MENU").hide(300);
                        $("#a_user").removeClass("ui-icon-minus").addClass("ui-icon-bullets");
                    }
                });
                $(document).on("click", "#popup_ok", function(e){ $s.apply._popup_ok(this); });
                $(document).on("click", "#popup_yes", function(e){ $s.apply._popup_ok(this); });
                $(document).on("click", "#popup_on", function(e){ $s.apply._popup_no(this); });
                $(document).on("click", "#popup_cancel", function(e){ $s.apply._popup_cancel(this); });
                $(document).on("click", "#popup_close", function(e){ $s.apply._popup_close(this); });
                $(document).on("click", ".list_disp", function(e){ $s.apply._list_disp(this); });
                $("#popup_data").scroll(function(e){
                	if($(this).scrollTop() > 0) {
                		$s.apply.top = $(this).scrollTop();
                	} else {
                		$(this).scrollTop($s.apply.top);
                	}
                });

                // 画面個別処理の初期化
                _init();

                // 画面内容初期化
                $s.com.add_els("S_MENU", _els_menu.DATA);
                // メニューリストリフレッシュ
                $("ul[data-role]").each(function(i, elem) {
                    $(elem).listview("refresh");
                });

            } ,
            error : function(XMLHttpRequest, textStatus, errorThrown) {
                alert("error:" + XMLHttpRequest + "/" + textStatus + "/" + errorThrown);
            }
        });
    };

    /**
     * イベント_メニュー
     * */
    apply_util.prototype._menu = function(e) {
    	if ($("#S_MENU").css("display") == "none") {
            $("#S_MENU").show(300);
            $("#a_user").removeClass("ui-icon-bullets").addClass("ui-icon-minus");
    	} else {
            $("#S_MENU").hide(300);
            $("#a_user").removeClass("ui-icon-minus").addClass("ui-icon-bullets");
    	}
    };

    /**
     * メニューオープン
     * */
     apply_util.prototype._open_nume = function(e) {
    	location.href=$s.context + "/user/apply?applyId=" + $(e).find("[name=applyId]").val();
    };

    /**
     * イベント_戻る
     * */
    apply_util.prototype._back = function(e) {
    	 $.mobile.page.prototype.options.addBackBtn = true;
    };

    /**
     * イベント_ログアウト
     * */
    apply_util.prototype._logout = function(e) {
    	$("#logoutForm").attr("action", $s.context + "/user/logout");
    	$("#logoutForm").attr("method", "POST");
    	$("#logoutForm").submit();
    };


    /**
     * イベント_メッセージ表示
     * */
    apply_util.prototype._showPopup = function(opt) {
    	if ($s.com.clientType == "pc") {
    		$("#popup-box").css("min-width","300px").css("max-width","700px");
    	}

        $("#popupTitle").text(opt.title);
        $("#popupMsg").text((opt.msg == undefined)? "" : opt.msg);
        if (opt.html) {
        	$("#popupMsg").html(opt.html);
        }

        $s.apply._popup_ok = ($s.com.isNotEmpty(opt.fnc_ok)) ? opt.fnc_ok : $s.apply._popup_ok = function() {};
        $s.apply._popup_on = ($s.com.isNotEmpty(opt.fnc_no)) ? opt.fnc_no : $s.apply._popup_on = function() {};
        $s.apply._popup_cancel = ($s.com.isNotEmpty(opt.fnc_cancel)) ? opt.fnc_cancel : $s.apply._popup_cancel = function() {};
        $s.apply._popup_close =  ($s.com.isNotEmpty(opt.fnc_close))  ? opt.fnc_close  : $s.apply._popup_close = function() {};
        if (opt.type == "confirm") {
            $("#popup_ok").css("display", "none");
            $("#popup_yes").css("display", "");
            $("#popup_no").css("display", "");
            $("#popup_close").css("display", "none");
        } else if (opt.type == "list") {
            $("#popup_data").html("");
        	$("#popup_ok").css("display", "");
            $("#popup_yes").css("display", "none");
            $("#popup_no").css("display", "none");
            $("#popup_cancel").css("display", "");
            $("#popup_close").css("display", "none");
            $("#popup_data").append(opt.target.css("display",""));
        } else if (opt.type == "master") {
            $("#popup_ok").css("display", "none");
            $("#popup_yes").css("display", "none");
            $("#popup_no").css("display", "none");
            $("#popup_close").css("display", "");
        } else {
            $("#popup_ok").css("display", "");
            $("#popup_yes").css("display", "none");
            $("#popup_no").css("display", "none");
            $("#popup_close").css("display", "none");
        }
        if ($("#popup_data").width() - $("#popup_data")[0].clientWidth < 12) {
        	$("#popup_data").css("width","100%");
        } else {
        	$("#popup_data").css("width","calc(100% + 12px)");
        }
        $("#popup_cancel").css("display", ((opt.cancel == "show") ? "": "none"));
        setTimeout(function(){$("#show_popup").click();}, 300);
    };

    apply_util.prototype._showInputErrPopup = function(){this._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"})};

    apply_util.prototype._list_disp = function (el){
    	var $target = $(el).next("ul");
    	var $target_clone = $(el).next("ul").clone(true);
    	var opt = {
    		title:"入力",
    		type:"list",
    		target : $(el).next("ul"),
    		cancel : "show",
    		fnc_ok : function () {
    			$("#popup_cancel").css("display", "none");
    			$(el).parent().append($target.css("display","none"));
    			var tmp = $target.find("label[for=" + $target.find("input:radio:checked").attr("id") + "]").text();
    			$target.find("input:checkbox:checked").each(function(index, elem) {
    				if (tmp != "") tmp += ", ";
    				tmp += $target.find("label[for=" + $(elem).attr("id") + "]").text();
    			});
    			if (tmp == "") tmp = "未指定";
    			$(el).text(tmp);
    		},
    		fnc_cancel : function () {
    			$("#popup_cancel").css("display", "none");
    			// 未対応
    			$target_clone.find("li input").each(function(index, elem){
    				var chk = $(elem).prop("checked");
    				$target.find("#" + $(elem).attr("id")).prop("checked", chk).checkboxradio('refresh');;
    			});
    			$(el).parent().append($target.css("display", "none"));
    		}
    	};
    	this._showPopup(opt);
    };

    apply_util.prototype._popup_ok = function(el) {};
    apply_util.prototype._popup_on = function(el) {};
    apply_util.prototype._popup_cancel = function(el) {};
    apply_util.prototype._popup_close = function(el) {};

    apply_util.prototype._checkbox_chage = function(el) {
    	if ($(el).closest("li").find("label").text() == "該当なし") {
    		var id = $(el).attr("id");
    		$(el).closest("ul").find("input:checkbox:checked").each(function(index, elem) {
    		    if ($(elem).attr("id") != id) {
    		        $(elem).prop("checked", false).checkboxradio('refresh');;
    		    }
    		});
    	} else {
    		$(el).closest("ul").find("input:checkbox:checked").each(function(index, elem) {
    		    if ($(elem).prev("label").text() == "該当なし") {
    		        $(elem).prop("checked", false).checkboxradio('refresh');;
    		    }
    		});
    	}
    };

