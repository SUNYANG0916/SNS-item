/*************************
 * S00F001-メニュー
 * 初期ロード
 *************************/
function _init() {
    try {
        $("#h_title").text("メニュー");
        // 画面表示
        if ($s._objs.list_menu_work_val.length > 0) {
            $s.com.set_val($("#div_menu_work #list_menu_work"), {list_menu_work:$s._objs.list_menu_work_val});
        } else {
        	$("#div_menu_work").css("display", "none");
        }

        if ($s._objs.list_menu_manager_val.length > 0) {
            $s.com.set_val($("#div_menu_manager #list_menu_manager"), {list_menu_manager:$s._objs.list_menu_manager_val});
        } else {
        	$("#div_menu_manager").css("display", "none");
        }

        if ($s._objs.list_menu_seikyu_val.length > 0) {
            $s.com.set_val($("#div_menu_seikyu #list_menu_seikyu"), {list_menu_seikyu:$s._objs.list_menu_seikyu_val});
        } else {
        	$("#div_menu_seikyu").css("display", "none");
        }
        // 初期化
        $s.s00f001 = new s00f001_util();

    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f001_util = function(){
    if ((this instanceof s00f001_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
};

/**
 * イベントの初期化
 * */
s00f001_util.prototype.event_init = function(e) {
    // クリック_編集リンク
    $(document).on('click', "[data-role=list-divider]", function(e){ $s.s00f001._ctlr_menu(this); });

};

/**
 * イベントの初期化
 * */
s00f001_util.prototype._ctlr_menu = function(el) {
    var $menu_list = $(el).closest("div").find(".menu_list");
    if ($menu_list.css("display") == "none") {
        $menu_list.css("display", "");
        $(el).removeClass("ui-icon-carat-d").addClass("ui-icon-carat-u");
    } else {
        $menu_list.css("display", "none");
        $(el).removeClass("ui-icon-carat-u").addClass("ui-icon-carat-d");
    }
};