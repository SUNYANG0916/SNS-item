/*************************
 * S10F002-取引先マスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s10f002 = new s10f002_util();

        $s.com.set_val($("#div_suppliers_info #zyuhacchu_souh_list")
            , {zyuhacchu_souh_list:$s._objs.zyuhacchu_souh_list_val}
        );
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s10f002_util = function(){
    if ((this instanceof s10f002_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    $("#h_title").text("取引先一覧");
    // イベント
    this.event_init();
    // 一覧初期化
    $("#tbl_suppliers_list").get(0).tBodies[0].innerHTML = "";
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_suppliers_edit")[0]);
    }
};
/**
 * イベントの初期化
 * */
s10f002_util.prototype.event_init = function(e) {
	try {
		$(document).on('click', '#h_title', function(e){ $s.s10f002._ctrlEditView(this); });
	    // クリック_検索ボタン
	    $('#btn_search').on('click', function(e){ $s.s10f002._search(this); });
	    // クリック_新規
	    $(document).on('click', '#a_add', function(e){ $s.s10f002._ctrlEditView(this); });
	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s10f002._selTr(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s10f002._ctrlEditView(this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s10f002._ctrlEditView(this); });
	    // クリック_登録・更新ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s10f002._update(this); });
	    // クリック_登録・更新ボタン
	    $(document).on('click', '#btn_delete', function(e){ $s.s10f002._delete(this); });
	    // クリック_郵便番号検索ボタン
	    $(document).on("click", "#a_post", function(e){ $s.s10f002._address(this); });
	    // クリック_住所選択リンク
	    $(document).on('click', "[name=a_sel_postal]", function(e){ $s.s10f002._sel_postal(this); });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};
s10f002_util.prototype._selTr = function(el) {
	var edit = $(el).find("#a_edit");
	if (edit) {
		$s.s10f002._ctrlEditView(edit[0]);
	}
};
/**
 * 取引先一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s10f002_util.prototype._search = function(el) {
	var send_data = {cond:$("#cond").val(),selDelete:$("#selDelete").val()};
	var callback = {
		done : function(data, status, xhr){
			if (data.tbl_suppliers_list.length == 0 && el) {
				setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
			}
            $s.com.set_val($("#div_suppliers_info"), data);
		}
    };
    $s.com.ajax("GET", "_search", send_data, callback);
};

/**
 * 取引先詳細情報取得.
 *
 * @param el イベント発火エレメント
 *  */
s10f002_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {suppliersNo : $(el).closest("tr").find("[data-db-key=suppliersNo]").text()};
	var callback = {
		done : function(data, status, xhr){
	        $s.com.set_val($("#div_suppliers_edit"), data.tbl_suppliers_list);
		}
	};
    $s.com.ajax("GET", "_details", send_data, callback);
};


/**
 * 編集画面表示制御.
 *
 * @param el イベント発火エレメント
 *  */
s10f002_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
    // 取引先情報クリア
    $s.com.inputClear($("table#tbl_suppliers_info"));
    if (el.id == "a_add") {
        // 新規モード
        isShowEdit = true;
    } else if (el.id == "a_edit") {
        // 編集モード
        isShowEdit = true;
        // 取引先情報取得
        $s.s10f002._details(el);
    } else {
    	// 一覧表示
    	isShowEdit = false;
    }

    // 表示制御
    if (isShowEdit == true) {
        $("#h_title").text("取引先詳細");
        $("#div_suppliers_list").css("display","none");
        $("#div_suppliers_edit").css("display","block");
        $("#div_suppliers_data").css("display","none");
        $("#conditions").css("display","none");
    } else {
        $("#h_title").text("取引先一覧");
        $("#div_suppliers_list").css("display","block");
        $("#div_suppliers_edit").css("display","none");
        $("#div_suppliers_data").css("display","block");
        $("#conditions").css("display","");
    }
};

/**
 * 取引先情報登録更新
 * */
s10f002_util.prototype._update = function(el) {
	var educCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) educCheckList[educCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(educCheckList, "#applycationForm") == true) {
		var opt = {title: "確認",msg:"登録します。よろいですか？", type:"confirm"};
		opt.fnc_ok = function(el) {
		    // 送信データ取得
	        var send_data = {userCd : $s._objs.tergetUserCd};
	        $("table#tbl_suppliers_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });

	    	var callback = {
	    		done : function(data, status, xhr){
	                $s.s10f002._search();
                    $s.s10f002._ctrlEditView($("#btn_return")[0]);
	    		}
	        };
	        $s.com.ajax("POST", "_update", send_data, callback);
		}
	    $s.apply._showPopup(opt);
	} else {
		$s.apply._showInputErrPopup();
	}
};
/**
 * 取引先情報削除
 * */
s10f002_util.prototype._delete = function(el) {
	var opt = {title: "確認",msg:"廃止します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
        var send_data = {suppliersNo:$("table#tbl_suppliers_info [data-db-key=suppliersNo]").val()};
    	var callback = {
	    	done : function(data, status, xhr){
	    		$s.s10f002._search();
	            $s.s10f002._ctrlEditView($("#btn_list")[0]);
	    	}
        };
        $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};


/**
 * 郵便番号検索
 * */
s10f002_util.prototype._address = function(el) {
	var send_data = {zipCd : $("[data-db-key=postalCode]").val().replace("-","")};
	var callback = {
		done : function(data, status, xhr){
			if (data.length == 1) {
		        $("table#tbl_suppliers_info [data-db-key=address1]").val(data[0].todoufukenKanji);
				$("table#tbl_suppliers_info [data-db-key=address2]").val(data[0].sikutyousonKanji);
				$("table#tbl_suppliers_info [data-db-key=address3]").val(data[0].tyouikiKanji);
		    } else if (data.length > 1) {
				$s.com.set_val($("#master_postal"), {tbl_postal_list:data});
				var opt = {title: "住所検索", type:"master"};
				opt.html = $("#master_postal").clone().css("display","").html();
				$s.apply._showPopup(opt);
		    } else {
				$s.apply._showPopup({title:"情報", msg:"入力された郵便番号の住所を見つかりませんでした。"});
		    }
		}
	};
    $s.com.ajax("GET", "_address", send_data, callback);
};


/**
 * 住所一覧から住所選択
 * */
s10f002_util.prototype._sel_postal = function(el) {
	var todoufukenKanji = $(el).closest("tr").find("[data-db-key=todoufukenKanji]").text();
	var sikutyousonKanji = $(el).closest("tr").find("[data-db-key=sikutyousonKanji]").text();
	var tyouikiKanji = $(el).closest("tr").find("[data-db-key=tyouikiKanji]").text();
	$("#address1").val(todoufukenKanji);
	$("#address2").val(sikutyousonKanji);
	$("#address3").val(tyouikiKanji);

	$("#popup_ok").click();
};

