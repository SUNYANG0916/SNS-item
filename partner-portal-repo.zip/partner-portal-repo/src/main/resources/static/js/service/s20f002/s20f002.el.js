//作成日時：2019/07/07 12:58:09
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_educ_info_edit",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",id:"div_educ_list",elems:[
  {tag:"table",id:"tbl_educ_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_educ_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:40px;",elems:[
      {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"学校名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"入学年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"卒業年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"ITスキル",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"文理区分",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
     {tag:"td",style:"text-align:center;",elems:[
      {tag:"a",id:"a_edit",name:"a_edit",style:"font-size: 12px;",elems:[
       {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
      ]}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"gakkouMei",name:"gakkouMei",style:"font-size: 12px;"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"nyugakuYm",name:"nyugakuYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"sotugyoYm",name:"sotugyoYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"itSkilKbn",name:"itSkilKbn",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"bunriKbn",name:"bunriKbn",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_educ_edit",style:"display:none;",elems:[
  {tag:"table",id:"tbl_educ_info",name:"tbl_educ_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:40%;",elems:[
      {tag:"label",text:"学校名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:60%;",elems:[
      {tag:"input",type:"text","data-db-key":"gakkouMei",name:"gakkouMei",style:"width:90%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"学部",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"gakubu",name:"gakubu",style:"width:100%;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"学科",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"text","data-db-key":"gakka",id:"gakka",name:"gakka",style:"width:100%;"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"入学年月",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"nyugakuYm",name:"nyugakuYm",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"卒業年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"sotugyoYm",name:"sotugyoYm"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"文理区分",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label",text:"文系",for:"bunriKbn_1",elems:[
       {tag:"input",type:"radio","data-db-key":"bunriKbn",id:"bunriKbn_1",name:"bunriKbn",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"0"}
      ]}
     ,{tag:"label",text:"理系",for:"bunriKbn_2",elems:[
       {tag:"input",type:"radio","data-db-key":"bunriKbn",id:"bunriKbn_2",name:"bunriKbn",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",value:"1"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"最終学歴",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label",text:"最終学歴",for:"saisyuGakurekiKbn",elems:[
       {tag:"input",type:"checkbox","data-db-key":"saisyuGakurekiKbn",id:"saisyuGakurekiKbn",name:"saisyuGakurekiKbn",value:"1"}
      ]}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",style:"width:100px;",elems:[
      {tag:"label",text:"ITスキル有無",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"itSkilKbn",id:"selItSkilKbn",name:"selItSkilKbn"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ITスキル詳細",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"textarea","data-db-key":"itSkilSyosai",name:"itSkilSyosai",style:"width:100%;height:80%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-b",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"削除",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-c",elems:[
    {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
];

