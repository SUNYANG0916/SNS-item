/*************************
 * S20F005-スキル情報
 * 画面初期ロード
 *************************/
function _init() {
    // 初期化
    $s.s20f005 = new s20f005_util();
    $("#h_title").text("スキル情報");
    // 画面表示
    $s.s20f005._search();
    // 画面制御
    if ($s._objs.isManager == false) {
        $("#btn_backUser").attr("disabled", true);
    }
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_skill_edit")[0]);
    }
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }

    // 取得データ設定
    setTimeout(function() {
      $s.com.set_val($("#div_skill #tbl_skill_list")
        , {list_gyokai:$s._objs.list_gyokai_val
          ,list_kotei:$s._objs.list_kotei_val
          ,list_kibo:$s._objs.list_kibo_val
          ,list_os:$s._objs.list_os_val
          ,list_db:$s._objs.list_db_val
          ,list_program_gengo:$s._objs.list_program_gengo_val
          ,list_java_lib:$s._objs.list_java_lib_val
          ,list_framework:$s._objs.list_framework_val
          ,list_midoruwea:$s._objs.list_midoruwea_val
          ,list_tool_kaihatu:$s._objs.list_tool_kaihatu_val
          ,list_tool_utility:$s._objs.list_tool_utility_val
          ,list_tool_cloud:$s._objs.list_tool_cloud_val
          ,list_tool_bisinesu:$s._objs.list_tool_bisinesu_val
          ,list_annken_kansou:$s._objs.list_annken_kansou_val
        }
      );}
    ,300);

};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f005_util = function(){
    if ((this instanceof s20f005_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    this.mode = "list";
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }
};
/**
 * イベントの初期化
 * */
s20f005_util.prototype.event_init = function(e) {
	try {

		$(document).on('click', '#h_title', function(e){ $s.s20f005._ctrlEditView(this); });
		// クリック_新規リンク
	    $(document).on('click', '#a_add', function(e){ $s.s20f005._ctrlEditView(this);});
	    // 登録
	    $(document).on('click', '#btn_crt', function(e){ $s.s20f005.projectUpdate(this); });
	    // 一覧へ戻る
	    $(document).on('click', '#a_rtn_list', function(e){
	    	location.href=$s.context + "/user/apply?applyId=s00f004";
	    });
	    // 戻るリンク
	    $(document).on('click', '#a_return', function(e){ $s.s20f005._ctrlEditView(this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s20f005._ctrlEditView(this); });
	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s20f005._selTr(this); });
	    // クリック_登録・更新ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s20f005._update(this); });
	    // クリック_登録・更新ボタン
	    $(document).on('click', '#btn_delete', function(e){ $s.s20f005._delete(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s20f005._ctrlEditView(this); });

	    // クリック_スキルシートダウンロードアイコンリンク
	    $(document).on('click', '#btn_dl', function(e){ $s.s20f005._skillDownload(this); });

	} catch (e) {
    	setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
    }
};

/**
 * スキル一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s20f005_util.prototype._search = function(el) {
    $s.com.ajax("GET", "_search", {}, {
		done : function(data,status,xhr){
            $s.com.set_val($("#div_skill"), data);
            if (data.tbl_skill_list.length > 0) {
            	$("#btn_dl").css("display","block");
            } else {
            	$("#btn_dl").css("display","none");
            }
		}
    });
};

/**
 * スキル詳細取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f005_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {
    	ankenMei : $(el).closest("tr").find("[data-db-key=ankenMei]").text(),
    	sequence : $(el).closest("tr").find("[data-db-key=sequence]").val()
    };
	var callback = {
		done : function(data,status,xhr){
            // 取得データ設定
            $s.com.set_val($("#tbl_skill_info"), data.tbl_skill_list);
            $(".list_disp").each(function(index, el) {
        	    var $target = $(el).next("ul");
    		    var tmp = $target.find("label[for="+$target.find("input:radio:checked").attr("id")+"]").text();
    		    $target.find("input:checkbox:checked").each(function(i, elem) {
    			    if (tmp != "") tmp += ", ";
    			    tmp += $target.find("label[for=" + $(elem).attr("id")+"]").text();
    		    });
    			if ($s.com.isEmpty(tmp)) tmp = "未指定";
    		    $(el).text(tmp);
            });
	        if ($s._objs.tergetUserCd != "" && $s._objs.tergetUserCd != $s._objs.loginUserCd) {
	            $s.com.view_mode($("#div_skill_edit")[0]);
	        }
		}
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * スキル情報登録更新.
 * */
s20f005_util.prototype._update = function(el) {
	var skillCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate"))skillCheckList[skillCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(skillCheckList, "#applycationForm") == true) {
		var opt = {title: "確認",msg:"登録します。よろいですか？", type:"confirm"};
		opt.fnc_ok = function(el) {
	        // 送信データ取得
	        var send_data = {};
	        $("table#tbl_skill_info [data-db-key]").each(function(index, el){
	        	$s.com.getSendData(send_data, el);
	        });
	    	var callback = {
	    		done : function(data,status,xhr){
	                $s.s20f005._search();
	    		}
	        };
	        // 更新処理実施
	        $s.com.ajax("POST", "_update", send_data, callback);
		};
	    $s.apply._showPopup(opt);
	} else {
		$s.apply._showInputErrPopup();
	}

};
/**
 * スキル情報削除
 * */
s20f005_util.prototype._delete = function(el) {
	if ($s.s20f005.mode == "create") return;
	var opt = {title: "確認",msg:"削除します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
        var send_data = {
            ankenMei : $("table#tbl_skill_info [data-db-key=ankenMei]").val(),
    		sequence : $("table#tbl_skill_info [data-db-key=sequence]").val()
        };
    	var callback = {
	    	done : function(data,status,xhr){
                $s.s20f005._search();
                $s.s20f005._ctrlEditView($("#btn_return")[0]);
	    	}
        };
        $s.com.ajax("POST", "_delete", send_data, callback);
	};
    $s.apply._showPopup(opt);
};

s20f005_util.prototype._selTr = function(el) {
	var edit = $(el).find("#a_edit");
	if (edit) {
		$s.s20f005._ctrlEditView(edit[0]);
	}
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f005_util.prototype._ctrlEditView = function(el) {
	// 入力情報クリア
	$s.com.inputClear($("#div_skill_edit"));
    if (el.id == "a_add") {
        // 新規モード
    	$s.s20f005.mode = "create";
        $(".list_disp").text("未指定");
    } else if (el.id == "a_edit") {
        // 編集モード
    	$s.s20f005.mode = "edit";
        // 対象従業員のスキル情報取得
        this._details(el);
    } else if (el.id == "btn_return" || el.id == "a_return") {
    	// 一覧再表示
    	$s.s20f005.mode = "list";
        $s.s20f005._search();
    }

    // 表示制御
    if ($s.s20f005.mode == "list") {
        $("#btn_dl").css("display","");
        $("#a_return").css("display","none");
        $("#li_creat").css("display","");
        $("#li_back_list").css("display","none");
        $("#li_closed").css("display","none");
        $("#div_skill_list").css("display","block");
        $("#div_skill_edit").css("display","none");
        $("#h_title").text("スキル一覧");
    } else {
        $("#btn_dl").css("display","none");
        $("#a_return").css("display","");
        $("#li_creat").css("display","none");
        $("#li_back_list").css("display","");
        $("#li_closed").css("display","");
        $("#div_skill_list").css("display","none");
        $("#div_skill_edit").css("display","block");
        $("#h_title").text("スキル詳細");
    }
};

/**
 * イベント_スキル帳票ダウンロード
 * */
s20f005_util.prototype._skillDownload = function(el) {
	var applyId = "";
	var userInitial = $s._objs.userInitial;
	if (userInitial == "未登録") {
		var opt = {
			title : "情報",
			msg : "基本情報未登録。",
			type : "ok"
		};
		$s.apply._showPopup(opt);
		return;
	}
	jQuery.mobile.loading('show');
	var xhr = new XMLHttpRequest();
	var userCd = "";
	xhr.open("GET", $s.context + "/user/download", true);
	xhr.responseType = 'arraybuffer';
	xhr.onload = function(e) {
		if (xhr.status === 200) {
			var downloadData = new Blob([ this.response ], {
				type : 'application/vnd.ms-excel'
			});
			var filename = "スキルシート（" + userInitial + "）.xlsx";
			if (window.navigator.msSaveBlob) {
				window.navigator.msSaveBlob(downloadData, filename); // IE用
			} else {
				var downloadUrl = (window.URL || window.webkitURL)
						.createObjectURL(downloadData);
				if ($s.com.clientType == "sp") {
					var _url = $s.context + "/js/report/" + filename;
					window.open(_url, '_self');
				} else {
					var link = document.createElement('a');
					link.href = downloadUrl;
					link.download = filename;
					link.click();
				}
			}
		} else {
			var msg = "エラー発生しました。（" + xhr.status + "）";
			var html = "";
			try {
				html = xhr.responseText;
		    } catch (e) {
		    }
			setTimeout($s.apply._showPopup({
				title : "メッセージ",
				msg : msg,
				html : html,
				type : "エラー発生"
			}), 200);
		}
		jQuery.mobile.loading('hide');
	};
	xhr.send();
};