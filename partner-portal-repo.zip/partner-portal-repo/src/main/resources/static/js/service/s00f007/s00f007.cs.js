/*************************
 * S00F004-アカウントマスタ
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s00f007 = new s00f007_util();
        $("#h_title").text("ロールグループ一覧");
        // 一覧初期表示
        $s.s00f007._search();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s00f007_util = function(){
    if ((this instanceof s00f007_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    // 更新権限がない場合
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_role_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s00f007_util.prototype.event_init = function(e) {
	try {
	    // クリック_検索ボタン
	    $('#btn_search').on('click', function(e){ $s.s00f007._search(this); });
	    // クリック_新規リンク
	    $("#a_add").on('click', function(e){ $s.s00f007._ctrlEditView(this); });
	    // クリック_一覧へ戻るリンク
	    $("#btn_return").on('click', function(e){ $s.s00f007._ctrlEditView(this); });
	    // クリック_更新ボタン
	    $("#btn_update").on('click', function(e){ $s.s00f007._update(this); });

	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s00f007._selTr(this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=aEdit]', function(e){ $s.s00f007._ctrlEditView(this); });

	    // クリック_権限ロール検索リンク
	    $(document).on('click', '#aRole', function(e){ $s.s00f007._master_role(this); });
	    // クリック_権限ロール行選択
	    $(document).on('click', '[data-db-key=selRolesTr]', function(e){ $s.s00f007._selRoleTr(this); });
	    // クリック_権限ロール検索
	    $(document).on("click", "[name=btn_master_roles_search]", function(e) {$s.s00f007._master_roles_search(this);});

	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};

s00f007_util.prototype._selTr = function(el) {
	var edit = $(el).find("#aEdit");
	if (edit) {
		$s.s00f007._ctrlEditView(edit[0]);
	}
};
/**
 * ユーザ一覧取得
 *
 * @param el イベント発火エレメント
 *  */
s00f007_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
	var ajaxOpt = $s.com.ajaxObj("GET", "_search", {conditions:$("#conditions").val()});
	ajaxOpt.success = function(data, status, xhr){
		if (data.tbl_rolegrp_list.length == 0 && el) {
			setTimeout($s.apply._showPopup({title:"メッセージ", msg:"該当データありません。"}), 100);
		}
        $s.com.set_val($("#div_role_info"), data);
    }
    // 送信データオブジェクト初期化
    $.ajax(ajaxOpt);
};

/**
 * ユーザ詳細情報取得
 *
 * @param el イベント発火エレメント
 *  */
s00f007_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {
    	roleGrpId : $(el).closest("tr").find("[name=roleGrpId]").val()
    };
    $("#tbl_role_info #roleGrp").val($(el).closest("tr").find("[data-db-key=itemTxt]").text());
    $("#tbl_role_info #roleGrpId").val($(el).closest("tr").find("[data-db-key=itemVal]").val());
	var callback = {
		done : function(data, status, xhr){
            $s.com.set_val($("#div_role_edit"), data);
        	if ($("#tbl_role_info #roleGrpId").val() == "30023-admin") {
        		$("#tbl_role_list .btn_row_del").each(function(index, el) {
        			$(el).css("display", "none");
        		});
        	}
		}
    };

    $s.com.ajax("GET", "_details", send_data, callback);
};

/**
 * ユーザ情報登録更新
 *
 * @param el イベント発火エレメント
 *  */
s00f007_util.prototype._update = function(el) {
	var empCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) empCheckList[empCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(empCheckList, "#applycationForm") == true) {
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){

        	}
        };
        var roleGrpId = $("#tbl_role_info #roleGrpId").val();
		var send_detail = [];
		var $tr = $("table#tbl_role_list tBody tr");
		for(var i = 0; i < $tr.size(); i++) {
			send_detail[send_detail.length] = {
				roleGrpId : roleGrpId ,
				roleId : $($tr[i]).find("[data-db-key=roleId]").val()
			};
		}

	    $s.com.ajax("POST", "_update", send_detail, callback);
	} else {
		$s.apply._showInputErrPopup();
	}
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s00f007_util.prototype._ctrlEditView = function(el) {
    var isShowEdit = false;
	// 入力情報クリア
	$s.com.inputClear($("table#tbl_role_info"));
    if (el.id == "a_add") {
        // 新規モード
        isShowEdit = true;
    } else if (el.name == "aEdit") {
        // 編集モード
        isShowEdit = true;
        // 対象ユーザ情報取得
        this._details(el);
        $("input#roleId").attr("readonly", true);
    } else if (el.id == "btn_return") {
        // 一覧表示
        isShowEdit = false;
    }

    // 表示制御
    if (isShowEdit == true) {
        $("#h_title").text("ロールグループ詳細");
        $("#div_rolegrp_list").css("display","none");
        $("#div_role_edit").css("display","block");
        $("#div_conditions").closest("div").css("display","none");
        $("#btn_search").css("display","none");
        $("#btn_return").css("display","");
    } else {
        $("#h_title").text("ロールグループ一覧");
    	$("#div_rolegrp_list").css("display","block");
        $("#div_role_edit").css("display","none");
        $("#div_conditions").closest("div").css("display","");
        $("#btn_search").css("display","");
        $("#btn_return").css("display","none");
    }
};

/**
 * ロール検索
 * */
s00f007_util.prototype._master_role = function(el) {
	if ($("#tbl_role_info #roleGrpId").val() == "30023-admin") {
		// 管理者の場合、変更不可
		return;
	}
	var opt = {title: "ロール検索", type:"master"};
	opt.html = $("#master_roles").clone().css("display","").html();
	$s.apply._showPopup(opt);
	$s.s00f007._master_roles_search($("#btn_master_roles_search")[0]);

	$s.s00f007.targetTr = $(el).closest("tr");
};

s00f007_util.prototype._master_roles_search = function(el) {
	var send_data = {cond : $(el).closest("p").find("#master_roles_cond").val()};
	if (send_data.cond == "") {
		// 警告メッセージ
		$(el).closest("p").find("#master_roles_cond").after("<div for='master_roles_cond' class='sa-validation-error'>検索条件を入力されていません。</div>")
		return;
	}
	var callback = {
		done : function(data, status, xhr){
			$s.com.set_val($("#master_roles"), data);
			var opt = {title: "ロール検索", type:"master"};
			opt.html = $("#master_roles").clone().css("display","").html();
			$s.apply._showPopup(opt);
        }
	};
	$s.com.ajax("GET", "_master_roles", send_data, callback);
};


/**
 * ロール一覧から選択
 * */
s00f007_util.prototype._selRoleTr = function(el) {
	var $selTr = $(el);

	$s.s00f007.targetTr.find("[data-db-key=roleId]").val($selTr.find("[data-db-key=roleId]").text());
	$s.s00f007.targetTr.find("[data-db-key=roleNm]").val($selTr.find("[data-db-key=roleNm]").text());

	$("#popup_ok").click();
};


