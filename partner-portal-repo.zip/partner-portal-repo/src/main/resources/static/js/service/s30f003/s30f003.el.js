//作成日時：2019/09/29 22:33:40
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",elems:[
 {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
]}
,{tag:"div",id:"div_invoice_info_edit",className:"sa-form-container",elems:[
 {tag:"div",id:"conditions",className:"ui-grid-a ui-btn",style:"margin-top:0px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(75% - 110px);",elems:[
   {tag:"input",type:"text",id:"cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:110px;padding-top:2px;",elems:[
   {tag:"select",id:"selDelete",name:"selDelete"}
  ]}
 ,{tag:"div",id:"div_ctrl",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_search",name:"btn_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
]}
,{tag:"div",id:"div_invoice_list",style:"margin-top:0px;",elems:[
 {tag:"table",id:"tbl_invoice_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_invoice_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"件名",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:80px;",elems:[
     {tag:"label",text:"注文金額",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"出力",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"コピー",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_edit",name:"a_edit",className:"ui-btn ui-icon-edit ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ,{tag:"input",type:"hidden","data-db-key":"invoiceNo",name:"invoiceNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"matterName",name:"matterName",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"text-align:right;",elems:[
     {tag:"label","data-db-key":"amountTotal",name:"amountTotal",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"output",name:"output",className:"ui-btn ui-icon-action ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"a","data-db-key":"copy",name:"copy",className:"ui-btn ui-icon-recycle ui-btn-icon-notext ui-corner-all",style:"font-size: 12px;margin:auto;"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"div_invoice_edit",style:"display:none;",elems:[
 {tag:"table",id:"tbl_invoice_info",name:"tbl_invoice_info",className:"sa-form",elems:[
  {tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:25%;",elems:[
     {tag:"label",text:"請求書番号",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",style:"width:75%;",elems:[
     {tag:"input",type:"text","data-db-key":"invoiceNo",id:"invoiceNo",name:"invoiceNo",style:"width:100%;background-color:#ddd;",readOnly:"True"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"件名",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"input",type:"text","data-db-key":"matterName",id:"matterName",name:"matterName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"作業内容",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"textarea","data-db-key":"matterInfo",id:"matterInfo",name:"matterInfo",style:"width:100%;height:80%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"見積書",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:70px;",elems:[
       {tag:"input",type:"text","data-db-key":"estimateNo",id:"estimateNo",name:"estimateNo",style:"background-color:#ddd;",readOnly:"True"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 110px);",elems:[
       {tag:"input",type:"text","data-db-key":"estimateName",id:"estimateName",name:"estimateName",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-c",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aEstimate",name:"aEstimate",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"請求先",className:"sa-required",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:70px;",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToNo",id:"suppliersToNo",name:"suppliersToNo",style:"background-color:#ddd;",readOnly:"True",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:calc(100% - 70px);",elems:[
       {tag:"input",type:"text","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName",style:"background-color:#ddd;",readOnly:"True"}
      ]}
     ]}
    ,{tag:"div",style:"display:none;",elems:[
      {tag:"input",type:"text","data-db-key":"suppliersToNo",id:"suppliersToNo",name:"suppliersToNo",style:"background-color:#ddd;",readOnly:"True"}
     ,{tag:"input",type:"text","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName"}
     ,{tag:"input",type:"text","data-db-key":"suppliersFromNo",id:"suppliersFromNo",name:"suppliersFromNo",style:"background-color:#ddd;",readOnly:"True"}
     ,{tag:"input",type:"text","data-db-key":"suppliersFromName",id:"suppliersFromName",name:"suppliersFromName"}
     ,{tag:"input",type:"text","data-db-key":"postalCode",id:"postalCode",name:"postalCode"}
     ,{tag:"input",type:"text","data-db-key":"address1",id:"address1",name:"address1",placeholder:"都道府県"}
     ,{tag:"input",type:"text","data-db-key":"address2",id:"address2",name:"address2",placeholder:"市区町村"}
     ,{tag:"input",type:"text","data-db-key":"address3",id:"address3",name:"address3",placeholder:"番地以降"}
     ,{tag:"input",type:"text","data-db-key":"address4",id:"address4",name:"address4",placeholder:"ビル名／部屋"}
     ,{tag:"input",type:"text","data-db-key":"pepresentative",id:"pepresentative",name:"pepresentative"}
     ,{tag:"input",type:"text","data-db-key":"tel",id:"tel",name:"tel"}
     ,{tag:"input",type:"text","data-db-key":"fax",id:"fax",name:"fax"}
     ,{tag:"input",type:"text","data-db-key":"ginkoCd",id:"ginkoCd",name:"ginkoCd",placeholder:"銀行コード",placeholder:"銀行コード"}
     ,{tag:"input",type:"text","data-db-key":"ginkoMei",id:"ginkoMei",name:"ginkoMei",placeholder:"銀行名",placeholder:"銀行名"}
     ,{tag:"input",type:"text","data-db-key":"shitenNo",id:"shitenNo",name:"shitenNo",placeholder:"支店番号",placeholder:"支店番号"}
     ,{tag:"input",type:"text","data-db-key":"shitenMei",id:"shitenMei",name:"shitenMei",placeholder:"支店名",placeholder:"支店名"}
     ,{tag:"input",type:"text","data-db-key":"kouzaType",id:"kouzaType",name:"kouzaType"}
     ,{tag:"input",type:"text","data-db-key":"kouzaNo",id:"kouzaNo",name:"kouzaNo",placeholder:"口座番号",placeholder:"口座番号"}
     ,{tag:"input",type:"text","data-db-key":"kouzaMei",id:"kouzaMei",name:"kouzaMei",placeholder:"口座名義",placeholder:"口座名"}
     ]}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"期間",className:"sa-required",style:"font-size: 12px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ,{tag:"td",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:50%;",elems:[
       {tag:"label",text:"開始日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"startDate",id:"startDate",name:"startDate",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:50%;",elems:[
       {tag:"label",text:"終了日",style:"font-size: 12px;"}
      ,{tag:"input",type:"date","data-db-key":"endDate",id:"endDate",name:"endDate",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"table",id:"tbl_working_list",name:"tbl_working_list",className:"scroll_table",style:"width:100%;margin-bottom:10px;",list_id:"tbl_working_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",id:"tbl_working_list_add",name:"tbl_working_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",colSpan:"2",elems:[
     {tag:"label",text:"プロジェクト",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text",name:"pjNm",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"納品日",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text",name:"deliveryDate",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ,{tag:"th",rowSpan:"2",elems:[
     {tag:"label",text:"納品物",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"th",elems:[
     {tag:"label",text:"数量",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"金額",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",style:"border-right:none;",elems:[
     {tag:"label",text:"支払日",className:"sa-required",style:"font-size: 12px;"}
    ,{tag:"input",type:"text",name:"dueDate",style:"display:none;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",rowSpan:"2",elems:[
     {tag:"a",name:"tbl_working_list_del",className:"btn_row_del ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"td",colSpan:"2",elems:[
     {tag:"div",className:"ui-grid-b",elems:[
      {tag:"div",className:"ui-block-a",style:"width:calc(100% - 40px);",elems:[
       {tag:"input",type:"text","data-db-key":"pjNm",name:"pjNm"}
      ,{tag:"input",type:"hidden","data-db-key":"pjCd",name:"pjCd",style:"background-color:#ddd;"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:40px;text-align:center;",elems:[
       {tag:"a",id:"aPj",name:"aPj",className:"ui-btn ui-icon-search ui-btn-icon-notext ui-corner-all",style:"margin:5px;"}
      ]}
     ]}
    ]}
   ,{tag:"td",style:"text-align:center;width:120px;",elems:[
     {tag:"input",type:"date","data-db-key":"deliveryDate",name:"deliveryDate",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",rowSpan:"2",elems:[
     {tag:"label","data-db-key":"workingInfo",name:"workingInfo",style:"font-size: 12px;"}
    ]}
   ]}
  ,{tag:"tr",elems:[
    {tag:"td",style:"width:40px;text-align:center;",elems:[
     {tag:"div",className:"ui-grid-a",elems:[
      {tag:"div",className:"ui-block-a",style:"width:calc(100% - 60px);",elems:[
       {tag:"label","data-db-key":"quantity",name:"quantity",style:"font-size: 12px;margin-left:5px;",value:"1"}
      ]}
     ,{tag:"div",className:"ui-block-b",style:"width:60px;",elems:[
       {tag:"label","data-db-key":"unitPriceNm",name:"unitPriceNm",style:"font-size: 12px;"}
      ,{tag:"input",type:"hidden","data-db-key":"unitPrice",name:"unitPrice"}
      ]}
     ]}
    ]}
   ,{tag:"td",style:"width:70px;text-align:right;",elems:[
     {tag:"label","data-db-key":"amount",name:"amount",style:"font-size: 12px;margin-right:5px;"}
    ]}
   ,{tag:"td",style:"text-align:center;",elems:[
     {tag:"input",type:"date","data-db-key":"dueDate",name:"dueDate",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tFoot",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;text-align:center;",elems:[
     {tag:"a",id:"tbl_working_list_add",name:"tbl_working_list_add",className:"btn_row_add ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"合計",style:"font-size: 12px;text-align:center;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label","data-db-key":"amountTotal",id:"amountTotal",name:"amountTotal",style:"font-size: 12px;text-align:right;margin-right:10px;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}",placeholder:"口座番号"}
    ]}
   ,{tag:"th",colSpan:"2"}
   ]}
  ]}
 ]}
,{tag:"div",className:"ui-grid-b",style:"margin-bottom:50px;",elems:[
  {tag:"div",className:"ui-block-a",elems:[
   {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-b",elems:[
   {tag:"a",text:"廃止",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
  ]}
 ,{tag:"div",className:"ui-block-c",elems:[
   {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
  ]}
 ]}
]}
,{tag:"div",id:"master_estimates",style:"display:none;",elems:[
 {tag:"div",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_estimates_cond",name:"master_estimates_cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_estimates_search",name:"btn_master_estimates_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_estimates_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_estimates_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"見積コード",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"見積名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selEstimatesTr",name:"selEstimatesTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_estimates",name:"a_sel_estimates",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"estimateNo",name:"estimateNo",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"estimateName",name:"estimateName",style:"font-size: 12px;"}
    ,{tag:"label","data-db-key":"startDate",name:"startDate",className:"FMT_YMD_VAL",style:"display:none;"}
    ,{tag:"label","data-db-key":"endDate",name:"endDate",className:"FMT_YMD_VAL",style:"display:none;"}
    ,{tag:"input",type:"hidden","data-db-key":"releaseLot",name:"releaseLot"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersToNo",name:"suppliersToNo"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersToName",name:"suppliersToName"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersFromNo",name:"suppliersFromNo"}
    ,{tag:"input",type:"hidden","data-db-key":"suppliersFromName",name:"suppliersFromName"}
    ,{tag:"input",type:"hidden","data-db-key":"postalCode",name:"postalCode"}
    ,{tag:"input",type:"hidden","data-db-key":"address1",name:"address1"}
    ,{tag:"input",type:"hidden","data-db-key":"address2",name:"address2"}
    ,{tag:"input",type:"hidden","data-db-key":"address3",name:"address3"}
    ,{tag:"input",type:"hidden","data-db-key":"address4",name:"address4"}
    ,{tag:"input",type:"hidden","data-db-key":"pepresentative",name:"pepresentative"}
    ,{tag:"input",type:"hidden","data-db-key":"tel",name:"tel"}
    ,{tag:"input",type:"hidden","data-db-key":"fax",name:"fax"}
    ,{tag:"input",type:"hidden","data-db-key":"ginkoCd",name:"ginkoCd"}
    ,{tag:"input",type:"hidden","data-db-key":"ginkoMei",name:"ginkoMei"}
    ,{tag:"input",type:"hidden","data-db-key":"shitenNo",name:"shitenNo"}
    ,{tag:"input",type:"hidden","data-db-key":"shitenMei",name:"shitenMei"}
    ,{tag:"input",type:"hidden","data-db-key":"kouzaType",name:"kouzaType"}
    ,{tag:"input",type:"hidden","data-db-key":"kouzaNo",name:"kouzaNo"}
    ,{tag:"input",type:"hidden","data-db-key":"kouzaMei",name:"kouzaMei"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",id:"master_projects",style:"display:none;",elems:[
 {tag:"div",className:"ui-grid-a ui-btn",style:"margin-top:0px;padding:5px;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:75%;",elems:[
   {tag:"input",type:"text",id:"master_projects_cond",name:"master_projects_cond",placeholder:"キーワード検索"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:25%;",elems:[
   {tag:"a",text:"検索",id:"btn_master_projects_search",name:"btn_master_projects_search",className:"ui-btn ui-corner-all",style:"padding:5px;margin-top:10px;"}
  ]}
 ]}
,{tag:"table",id:"tbl_project_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_project_list",even_color:"#F1F4FF",elems:[
  {tag:"tHead",elems:[
   {tag:"tr",elems:[
    {tag:"th",style:"width:40px;",elems:[
     {tag:"label",text:"選択",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"プロジェクトコード",style:"font-size: 12px;"}
    ]}
   ,{tag:"th",elems:[
     {tag:"label",text:"プロジェクト名",style:"font-size: 12px;"}
    ]}
   ]}
  ]}
 ,{tag:"tBody",elems:[
   {tag:"tr","data-db-key":"selProjectsTr",name:"selProjectsTr",elems:[
    {tag:"td",style:"text-align:center;",elems:[
     {tag:"a",id:"a_sel_project",name:"a_sel_project",className:"ui-btn ui-icon-check ui-btn-icon-notext ui-corner-all",style:"margin:auto"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"pjCd",name:"pjCd",style:"font-size: 12px;"}
    ]}
   ,{tag:"td",elems:[
     {tag:"label","data-db-key":"pjNm",name:"pjNm",style:"font-size: 12px;"}
    ,{tag:"input",type:"hidden","data-db-key":"quantity",name:"quantity"}
    ,{tag:"input",type:"hidden","data-db-key":"unitPrice",name:"unitPrice"}
    ,{tag:"input",type:"hidden","data-db-key":"unitPriceNm",name:"unitPriceNm"}
    ,{tag:"input",type:"hidden","data-db-key":"amount",name:"amount"}
    ,{tag:"input",type:"hidden","data-db-key":"taxType",name:"taxType"}
    ,{tag:"input",type:"hidden","data-db-key":"pjNote",name:"pjNote"}
    ]}
   ]}
  ]}
 ]}
]}
,{tag:"div",style:"display:none;",elems:[
 {tag:"div",id:"div_invoice_print",elems:[
  {tag:"div",style:"text-align:right;",elems:[
   {tag:"label",text:"No."}
  ,{tag:"label","data-db-key":"invoiceNo",id:"invoiceNo",name:"invoiceNo",style:"margin-left:10px;"}
  ]}
 ,{tag:"div",style:"width:100%;margin-top:30px;margin-bottom:30px;padding-top:10px;padding-bottom:10px;text-align:center;border-style:double; border-width:3px;border-left:none;border-right:none;",elems:[
   {tag:"label",text:"ご 請 求 書",style:"font-size: 24px;"}
  ]}
 ,{tag:"div",elems:[
   {tag:"label","data-db-key":"suppliersToName",id:"suppliersToName",name:"suppliersToName",style:"border-bottom: 1px solid black;padding-right:20px;"}
  ,{tag:"label",text:"御中",style:"border-bottom: 1px solid black;"}
  ]}
 ,{tag:"div",elems:[
   {tag:"table",style:"max-width:50%;margin-left:auto;margin-right:0px;",elems:[
    {tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label","data-db-key":"suppliersFromName",id:"suppliersFromName",name:"suppliersFromName"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"〒",style:"margin-right:5px;"}
      ,{tag:"label","data-db-key":"postalCode",name:"postalCode",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"address1",name:"address1"}
      ,{tag:"label","data-db-key":"address2",name:"address2"}
      ,{tag:"label","data-db-key":"address3",name:"address3"}
      ,{tag:"label","data-db-key":"address4",name:"address4"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label","data-db-key":"pepresentative",name:"pepresentative"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",elems:[
       {tag:"label",text:"TEL",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"tel",id:"tel",name:"tel",style:"margin-right:20px;"}
      ,{tag:"label",text:"FAX",style:"margin-right:10px;"}
      ,{tag:"label","data-db-key":"fax",id:"fax",name:"fax"}
      ,{tag:"div",style:"text-align:right;",elems:[
        {tag:"img",id:"companyStamp",style:"width:30%;position:relative;margin-top:-20px;"}
       ]}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",elems:[
   {tag:"label",text:"下記の通り御請求申し上げます。"}
  ]}
 ,{tag:"div",style:"font-size:20px;margin-top:30px;margin-bottom:30px;padding-top:10px;padding-bottom:10px;text-align:center;",elems:[
   {tag:"label",text:"ご請求金額",style:"padding-right:10px;border-bottom: 1px solid black;"}
  ,{tag:"label","data-db-key":"amountTotal",id:"amountTotal",name:"amountTotal",className:"FMT_AMOUNT",style:"border-bottom: 1px solid black;"}
  ,{tag:"label",text:"（消費税込）",style:"border-bottom: 1px solid black;"}
  ]}
 ,{tag:"table",id:"tbl_invoice_info_print",name:"tbl_invoice_info_print",style:"width:100%;margin-bottom:30px;",list_id:"tbl_invoice_info_print",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:150px;",elems:[
      {tag:"label",text:"件名"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"matterName",id:"matterName",name:"matterName"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"作業内容"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"matterInfo",id:"matterInfo",name:"matterInfo"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label",text:"開発期間"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"startDate",id:"startDate",name:"startDate",className:"FMT_YYYYMMDD"}
     ,{tag:"label",text:"～"}
     ,{tag:"label","data-db-key":"endDate",id:"endDate",name:"endDate",className:"FMT_YYYYMMDD"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",style:"vertical-align:top;",rowSpan:"3",elems:[
      {tag:"label",text:"お振込先"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"ginkoMei",name:"ginkoMei",style:"margin-right:10px;"}
     ,{tag:"label","data-db-key":"shitenMei",name:"shitenMei"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label","data-db-key":"kouzaTypeNm",name:"kouzaTypeNm",style:"margin-right:10px;"}
     ,{tag:"label","data-db-key":"kouzaNo",name:"kouzaNo"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label","data-db-key":"kouzaMei",name:"kouzaMei"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"table",id:"tbl_working_list_print",style:"width:100%;border:1px gray;",list_id:"tbl_working_list_print",rules:"all",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"NO"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"納品物"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"納品日"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"支払日"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"単位"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"数量"}
     ]}
    ,{tag:"th",style:"background-color:#ddd;",elems:[
      {tag:"label",text:"金額"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",style:"width:40px;text-align:right;",elems:[
      {tag:"label","data-db-key":"row_no",name:"row_no"}
     ]}
    ,{tag:"td",style:"width:40%;",elems:[
      {tag:"label","data-db-key":"workingInfo",name:"workingInfo"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"deliveryDate",name:"deliveryDate",className:"FMT_YYYYMMDD"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"dueDate",name:"dueDate",className:"FMT_YYYYMMDD"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"unitPriceNm",name:"unitPriceNm"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"quantity",name:"quantity"}
     ]}
    ,{tag:"td",style:"text-align:right;padding-right:10px;",elems:[
      {tag:"label","data-db-key":"amount",name:"amount",className:"FMT_AMOUNT"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"text-align:right;background-color:#ddd;",colSpan:"6",elems:[
      {tag:"label",text:"消費税："}
     ]}
    ,{tag:"td",style:"text-align:right;padding-right:10px;",colSpan:"2",elems:[
      {tag:"label","data-db-key":"taxAmount",name:"taxAmount",className:"FMT_AMOUNT"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",style:"text-align:right;background-color:#ddd;",colSpan:"6",elems:[
      {tag:"label",text:"合計："}
     ]}
    ,{tag:"td",style:"text-align:right;padding-right:10px;",colSpan:"2",elems:[
      {tag:"label","data-db-key":"amountTotal",name:"amountTotal",className:"FMT_AMOUNT"}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

