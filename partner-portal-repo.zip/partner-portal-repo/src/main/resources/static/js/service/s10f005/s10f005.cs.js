/*************************
 * S10F005-作業情報
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s10f005 = new s10f005_util();
        $("#h_title").text("スケジュール");
        // 画面表示
        $s.s10f005.change_month();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s10f005_util = function(){
    if ((this instanceof s10f005_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // 処理対象月
    this.terget_month = new Date();
    // 処理対象日
    this.terget_date = $s.dat.fmt("YYYYMMDD");
    // イベント
    this.event_init();
};
/**
 * イベントの初期化
 * */
s10f005_util.prototype.event_init = function(e) {
	try {
		$(document).on('click', '#h_title', function(e){ $s.s10f005._ctrlEditView(this); });
	    // クリック_先月へ
	    $(document).on('click', '#a_month_back', function(e){ $s.s10f005.change_month(-1);});
	    // クリック_来月へ
	    $(document).on('click', '#a_month_next', function(e){ $s.s10f005.change_month(1); });
	    // クリック_日付選択
	    $(document).on('click', '.aSchedule', function(e) {$s.s10f005.sel_data(this); });
	    // クリック_その他のユーザ
	    $(document).on('click', '[name=scheduleAll]', function(e) {$s.s10f005.sel_data_all(this); });

	    $(document).on('click', "[name=list_schedule_ctlr]", function(e) {$s.s10f005.list_schedule_ctlr(this); });

	    $(document).on('click', ".btn_row_add", function(e) {$s.s10f005.list_schedule_add(this); });

	    // クリック_検索
	    $(document).on('click', '#btn_search', function(e){ $s.s10f005.change_month(); });
	    // クリック_登録ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s10f005._update(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s10f005._ctrlEditView(this); });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};


/** カレンダー：年月変更 */
s10f005_util.prototype.change_month = function(addMonth) {
    // 対象年月再表示
    if ($s.com.isNotEmpty(addMonth)) {
        this.terget_month.setMonth(this.terget_month.getMonth() + addMonth);
    }
    // 対象年月再表示
    $('#inp_month').val($s.dat.fmt('YYYY年MM月', this.terget_month));
    $('#inp_month').prop("data_val", $s.dat.fmt('YYYYMM',this.terget_month));

    $(".ui-icon-carat-u").addClass('ui-icon-carat-d').removeClass('ui-icon-carat-u');

    var tbl_calendar_list = [];
    var month = this.terget_month.getMonth();
    var lastDate = (new Date(this.terget_month.getFullYear(), month + 1, 0)).getDate();
    var weekDay = (new Date(this.terget_month.getFullYear(), month, 1)).getDay();
    for (var i = 0; i < lastDate; i++) {
        var dd = ("0" + String(i + 1)).slice(-2);
        weekDay = (weekDay % 7);

        var mm = String(month + 1);
        if(mm.length == 1) {
        	mm = '0' + mm;
        }
        tbl_calendar_list[tbl_calendar_list.length] = {
            occurDate : mm + "/" + dd + " (" + $s.dat.week[weekDay] + ")"
           ,weekDay : weekDay
           ,dateId : this.terget_month.getFullYear() + "-" + mm + "-" + dd
        };
        weekDay = (weekDay + 1);
    }
    $s.com.set_val($("#div_calendar_list"), {"tbl_calendar_list":tbl_calendar_list});

    // 一覧表示制御
    $("table#tbl_calendar_list tbody").children().each(function(index, _r){
        // ID付与
    	var dkId = $(_r).find("[data-db-key=dateId]").val();
    	$(_r).find("div").prop("id",dkId);
        var mmdd = $(_r).find("[data-db-key=occurDate]");
        var day = $(_r).find("[data-db-key=weekDay]").val();
        var color = "";
        if (day == "0") {
        	color = "red";
        	$(_r).css("background-color","lemonchiffon");
        } else if (day == "6") {
        	color = "blue";
        	$(_r).css("background-color","aliceblue");
        } else {
        	color = "black";
        }
        mmdd.css("color", color);
    });

    // 画面一覧再表示
    $s.s10f005._search();
};

s10f005_util.prototype.sel_data = function(el) {
    $s.s10f005._ctrlEditView(el);
};

s10f005_util.prototype.sel_data_all = function(el) {
    // 対象スケジュール情報取得
    var send_data = {
    	sequence : $(el).closest("li").find("[data-db-key=sequence]").val()
    };
    // 成功時のコールバック
    var callback = {
        done : function(data, status, xhr){
            // 取得データ設定
            $s.com.set_val($("#schedule_all"), data);
    		var strDate = $(el).closest("tr").find("[data-db-key=dateId]").val();
    		var userName = $(el).closest("li").find("[name=userName]").val();
			$("#schedule_all #userName").text(userName);
			$("#schedule_all #scheduleDate").text(strDate);
			var opt = {title: "予定一覧", type:"master"};
			opt.html = $("#schedule_all").clone().css("display","").html();
			$s.apply._showPopup(opt);

        }
    };
    $s.com.ajax("GET", "_alldetails", send_data, callback);
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s10f005_util.prototype._ctrlEditView = function(el) {
	// 入力情報クリア
	$s.com.inputClear($("#div_schedule_edit"));
	if (el.tagName == "LI") {
		var sequence = $(el).closest("tr").find("[data-db-key=sequence]").val();
		var strDate = $(el).closest("tr").find("[data-db-key=dateId]").val();
		if ($(el).closest("li").index() == 0) {
		    // 編集モード
			$s.s10f005.mode = "edit";
			var hours = (new Date()).getHours();
			$("#tbl_schedule_info #userName").val($s._objs.loginUser);
			$("#tbl_schedule_info #scheduleDate").val(strDate);
			$("#tbl_schedule_list [name=startTime]").val(hours + ":00");
			$("#tbl_schedule_list [name=endTime]").val(hours + ":30");
		} else {
		    // 編集モード
			$s.s10f005.mode = "view";
		}
        $("table#tbl_schedule_info #sequence").val(sequence);
	    // 対象スケジュール情報取得
		var sequence = $(el).closest("li").find("[data-db-key=sequence]").val();
	    var send_data = {
	    	sequence : sequence
	    };
	    // 成功時のコールバック
	    var callback = {
	        done : function(data, status, xhr){
	            // 取得データ設定
	            $s.com.set_val($("#tbl_schedule_list"), data);
	        }
	    };
	    $s.com.ajax("GET", "_details", send_data, callback);

	} else {
		$s.s10f005.mode = "list";
	}

    // 表示制御
    if ($s.s10f005.mode == "list") {
        $("#div_calendar").css("display","block");
    	$("#div_calendar_list").css("display","block");
        $("#div_schedule_edit").css("display","none");
        $("#h_title").text("スケジュール一覧");
    } else {
        $("#div_calendar").css("display","none");
        $("#div_calendar_list").css("display","none");
        $("#div_schedule_edit").css("display","block");
        $("#h_title").text("スケジュール情報");
    }
};


/**
 * カレンダー一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s10f005_util.prototype._search = function(el) {
	var send_data = {
			scheduleYm : $("#inp_month").val().replace("年","-").replace("月","") ,
			searchConditions : $("#searchConditions").val()
	};
	var callback = {
		done : function(data,status,xhr){
            // 取得データ設定
            $s.com.set_val($("#div_calendar_list"), data);
            // ログインユーザスケジュール設定
            $(data.tbl_schedules_list).each(function(index, dat){
            	$("table#tbl_calendar_list #" + dat.scheduleDate + " [name=aSchedulesText]").text(dat.schedule);
            	$("table#tbl_calendar_list #" + dat.scheduleDate + " [name=sequence]").val(dat.sequence);
            });
            // 他ユーザスケジュール設定
            $(data.tbl_schedules_all_list).each(function(index, dat){
            	var userAllList = $("table#tbl_calendar_list #" + dat.scheduleDate + " .ulScheduleAllList");
            	userAllList.append("<li style='margin-top:5px;cursor: pointer;border-bottom:solid 1px wheat;'>"
            			+ "<a style='margin:3px;text-align:left;padding:3px;font-size:12px;' name='scheduleAll'>" + dat.schedule + "</a>"
            			+ "<input type='hidden' name='userName' value='" + dat.userName + "'>"
            			+ "<input type='hidden' name='sequence' data-db-key='sequence' value='" + dat.sequence + "'>"
            			+ "</li>");
            });
        }
	};
    $s.com.ajax("GET", "_search", send_data, callback);
};

s10f005_util.prototype.list_schedule_ctlr = function(el) {
	if ($(el).closest("td").length == 0) {
		if ($(el).hasClass("ui-icon-carat-d") == true) {
			$(".ui-icon-carat-d").addClass('ui-icon-carat-u').removeClass('ui-icon-carat-d');
			$(".ulScheduleAllList").css("display","");
		} else {
			$(".ui-icon-carat-u").addClass('ui-icon-carat-d').removeClass('ui-icon-carat-u');
			$(".ulScheduleAllList").css("display","none");
		}
	} else {
		if ($(el).hasClass("ui-icon-carat-d") == true) {
			$(el).removeClass('ui-icon-carat-d');
			$(el).addClass('ui-icon-carat-u');
			$(el).closest("tr").find(".ulScheduleAllList").css("display","");
		} else {
			$(el).removeClass('ui-icon-carat-u');
			$(el).addClass('ui-icon-carat-d');
			$(el).closest("tr").find(".ulScheduleAllList").css("display","none");
		}
	}
};

s10f005_util.prototype.list_schedule_add = function(el) {
	var now = new Date();
	$("#tbl_schedule_list [name=startTime]:last").val(now.getHours() + ":00");
	$("#tbl_schedule_list [name=endTime]:last").val(now.getHours() + ":30");
};

/**
 * スケジュール登録更新.
 * */
s10f005_util.prototype._update = function(el) {
	var checkList = [];

	var checkInputTimes = $("table#tbl_schedule_list [name=timeCheck]")[0];
	$(checkInputTimes).val("OK");
	$("table#tbl_schedule_list [data-db-key=startTime]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputTimes).val("");
		}
	});
	$("table#tbl_schedule_list [data-db-key=endTime]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputTimes).val("");
		}
	});

	var checkInputTitles = $("table#tbl_schedule_list [name=scheduleTitleCheck]")[0];
	$(checkInputTitles).val("OK");
	$("table#tbl_schedule_list [data-db-key=scheduleTitle]").each(function(index, el){
		if ($(el).val() == "") {
			$(checkInputTitles).val("");
		}
	});

	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) checkList[checkList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(checkList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}


	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	if ($("table#tbl_schedule_list tBody tr").length == 0) {
		opt = {title: "確認", msg:"予定を削除します。よろいですか？", type:"confirm"};
	}
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var sequence = $("table#tbl_schedule_info #sequence").val();
        if (sequence == "") sequence = "0";
        var send_data = {"sequence":sequence};
		var $tr = $("table#tbl_schedule_list tBody tr");
		var rowNumber = 0;
		send_data.scheduleList = [];
		send_data.scheduleDate = $("table#tbl_schedule_info #scheduleDate").val();
		for(var i = 0; i < $tr.size(); i++) {
			if (i % 2 == 0) {
				send_data.scheduleList[send_data.scheduleList.length] = { "sequence" : sequence, "rowNumber" : String(rowNumber++) };
			}
			$($tr[i]).find("[data-db-key]").each(function(index, el){ $s.com.getSendData(send_data.scheduleList[send_data.scheduleList.length - 1], el); });
		}

        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                	$s.s10f005.change_month();
                    $s.s10f005._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_update", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

/**
 * スケジュール削除.
 * */
s10f005_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"削除します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
        var send_data = {
				sequence:$("table#tbl_schedule_info [data-db-key=sequence]").val()
		};
        var callback = {
            done : function(data, status, xhr){
                if (data.msg) {
                    $s.s10f005._search();
                    $s.s10f005._ctrlEditView($("#btn_return")[0]);
                }
            }
        };
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};