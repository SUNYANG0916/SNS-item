/*************************
 * S20F001-基本情報
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s20f001 = new s20f001_util();

        $("#h_title").text("基本情報");
        // 画面表示
        $s.s20f001._search();
    } catch (e) { alert(e.message);}
};
/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f001_util = function(){
    if ((this instanceof s20f001_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }
    if ($s._objs.canEdit == false) {
        $s.com.view_mode($("#div_emp_info_edit")[0]);
    }
};

/**
 * イベントの初期化
 * */
s20f001_util.prototype.event_init = function(e) {
	try {
	    // 登録
	    $(document).on('click', '#btn_update', function(e){ $s.s20f001._update(this); });
	    // 郵便番号検索
	    $(document).on('click', '#a_post', function(e){ $s.s20f001._address(this); });
	    // 一覧へ戻る
	    $(document).on('click', '#a_return', function(e){
	    	location.href=$s.context + "/user/apply?applyId=s00f004";
	    });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f001_util.prototype._search = function(el) {
	var callback = {
		done : function(data, status, xhr){
	        // 取得データ設定
	        $s.com.set_val($("#div_emp_info_edit #tokui_gijutu_list")
	        		, {tokui_gijutu_list:$s._objs.tokui_gijutu_list_val
	        		, tokui_kotei_list:$s._objs.tokui_kotei_list_val}
	        );
	        $("#userName").text(data.userName);
	        $s.com.set_val($("#div_emp_info_edit"), data.empProfile);
	        $(".list_disp").each(function(index, el) {
	        	var $target = $(el).next("ul");
	    		var tmp = $target.find("label[for="+$target.find("input:radio:checked").attr("id")+"]").text();
	    		$target.find("input:checkbox:checked").each(function(i, elem) {
	    			if (tmp != "") tmp += ", ";
	    			tmp += $target.find("label[for=" + $(elem).attr("id")+"]").text();
	    		});
    			if (tmp == "") tmp = "未指定";
	    		$(el).text(tmp);
	        });
	        if ($s._objs.canEdit == false) {
	            $s.com.view_mode($("#div_emp_info_edit")[0]);
	        }
	        if (data.empProfile) {
	        	$("#selBusyoCd").attr("disabled", true);
	        }
		}
	};
    $s.com.ajax("GET", "_search", {}, callback);
};

/**
 * 郵便番号検索
 *
 * @param el イベント発火エレメント
 *  */
s20f001_util.prototype._address = function(el) {
	var send_data = {zipCd : $("[data-db-key=postNo]").val().replace("-","")};
	var callback = {
		done : function(data, status, xhr){
			if (data.length > 0) {
		        $("[data-db-key=todofukenCd]").val(data[0].todoufukenKanji);
		        $("[data-db-key=shikuchoson]").val(data[0].sikutyousonKanji + data[0].tyouikiKanji);
		    }
		}
	};
    $s.com.ajax("GET", "_address", send_data, callback);
};

/**
 * 基本情報登録更新
 * */
s20f001_util.prototype._update = function(el) {
	var empCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) empCheckList[empCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(empCheckList, "#applycationForm") == true) {
		var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
		opt.fnc_ok = function(el) {
		      // 送信データ取得
		      var send_data = {};
		      $("table#tbl_emp_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
		      // 更新処理実施
		      $s.com.ajax("POST", "_update", send_data, {});
		}
	    $s.apply._showPopup(opt);
	} else {
		$s.apply._showInputErrPopup();
	}
};

