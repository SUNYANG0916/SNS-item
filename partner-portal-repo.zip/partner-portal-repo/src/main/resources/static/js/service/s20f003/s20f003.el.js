//作成日時：2019/09/22 22:55:16
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_qua_info_edit",className:"sa-form-container",elems:[
 {tag:"div",elems:[
  {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
 ]}
,{tag:"div",id:"div_terget",className:"ui-grid-a",style:"display:none;",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h3","data-db-key":"tergetUser",id:"tergetUser",name:"tergetUser",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;",elems:[
   {tag:"a",text:"戻る",id:"a_return",name:"a_return",className:"ui-btn ui-corner-all",style:"padding:7px;margin:0px;"}
  ]}
 ]}
,{tag:"div",id:"div_qua_list",elems:[
  {tag:"table",id:"tbl_qua_list",name:"tbl_qua_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_qua_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:40px;",elems:[
      {tag:"a",id:"a_add",name:"a_add",className:"ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all",style:"margin:auto;"}
     ]}
    ,{tag:"th",elems:_els.getIconElems('ui-icon-plus'),elems:[
      {tag:"label",text:"資格名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"習得開始年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"取得年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"ＩＴスキル",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr","data-db-key":"selTr",name:"selTr",elems:[
     {tag:"td",style:"text-align:center;",elems:[
      {tag:"a",id:"a_edit",name:"a_edit",style:"font-size: 12px;",elems:[
       {tag:"label","data-db-key":"row_no",style:"font-size: 12px;"}
      ]}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"sikakuMei",name:"sikakuMei",style:"font-size: 12px;"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"syutokuKaisiYm",name:"syutokuKaisiYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"syutokuYm",name:"syutokuYm",className:"FMT_YYYYMM",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"label","data-db-key":"itSkilKbn",name:"itSkilKbn",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_qua_edit",style:"display:none;",elems:[
  {tag:"table",id:"tbl_qua_info",name:"tbl_qua_info",className:"sa-form",elems:[
   {tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"th",style:"width:40%;",elems:[
      {tag:"label",text:"資格名",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"width:60%;",elems:[
      {tag:"input",type:"text","data-db-key":"sikakuMei",name:"sikakuMei",style:"width:90%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ,{tag:"input",type:"hidden","data-db-key":"sequence",name:"sequence"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"習得開始年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"syutokuKaisiYm",name:"syutokuKaisiYm",style:"width:90%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"取得年月",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"input",type:"month","data-db-key":"syutokuYm",name:"syutokuYm",style:"width:90%;",validate:"{\"rules\":{\"required\":true},\"message\":{\"required\":\"必須項目です。\"}}"}
     ]}
    ]}
   ,{tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"ＩＴスキル",className:"sa-required",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",elems:[
      {tag:"select","data-db-key":"itSkilKbn",id:"selItSkilKbn",name:"selItSkilKbn",style:"margin:5px;"}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-b",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"登録",id:"btn_update",className:"afr_upd ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"削除",id:"btn_delete",className:"afr_del ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-c",elems:[
    {tag:"a",text:"戻る",id:"btn_return",className:"afr_rtn ui-btn ui-corner-all"}
   ]}
  ]}
 ]}
]}
];

