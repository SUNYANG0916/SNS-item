//作成日時：2019/07/09 23:04:35
//作成者：Gao JiaYi
var _els = new S_ElsUtil();
//
_els.APPLY_DATA = [
{tag:"div",id:"div_question_info_edit",className:"sa-form-container",elems:[
 {tag:"div",className:"ui-grid-b",elems:[
  {tag:"div",className:"ui-block-a",style:"width:calc(100% - 150px);",elems:[
   {tag:"h1",id:"h_title",className:"ss_title ui-btn",style:"padding:5px;margin:0px;"}
  ]}
 ,{tag:"div",className:"ui-block-b",style:"width:150px;","data-role":"navbar",elems:[
   {tag:"a",text:"一覧",id:"btn_new",name:"btn_new",className:"ui-btn ui-corner-all",style:"margin:2px;padding-top:5px;padding-bottom:5px;background-color:#38c;color:#fff;text-shadow: 0 1px 0 #059;"}
  ]}
 ]}
,{tag:"div",id:"div_question_list",elems:[
  {tag:"table",id:"tbl_question_list",className:"scroll_table",style:"width:100%;",list_id:"tbl_question_list",even_color:"#F1F4FF",elems:[
   {tag:"tHead",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"質問名",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"件数",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"実施状況",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"誤",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"点数",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",text:"実施",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ,{tag:"tBody",elems:[
    {tag:"tr",elems:[
     {tag:"td",elems:[
      {tag:"label","data-db-key":"questionName",name:"questionName",style:"font-size: 12px;"}
     ,{tag:"input",type:"hidden","data-db-key":"questionId",name:"questionId"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"detailsCnt",name:"detailsCnt",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"status",name:"status",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"wrongCnt",name:"wrongCnt",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"point",name:"point",style:"font-size: 12px;"}
     ]}
    ,{tag:"td",style:"text-align:center;",elems:[
      {tag:"a",text:"実施する",name:"a_exec",className:"ui-link",style:"cursor: hand; cursor:pointer;"}
     ]}
    ]}
   ]}
  ,{tag:"tFoot",elems:[
    {tag:"tr",elems:[
     {tag:"th",elems:[
      {tag:"label",text:"集計：",style:"font-size: 12px;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label","data-db-key":"totalCnt",name:"totalCnt",style:"font-size: 12px;text-align:center;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label","data-db-key":"totalStatus",name:"totalStatus",style:"font-size: 12px;text-align:center;"}
     ]}
    ,{tag:"th",style:"text-align:center;",elems:[
      {tag:"label","data-db-key":"totalWrong",name:"totalWrong",style:"font-size: 12px;text-align:center;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label","data-db-key":"totalPoint",name:"totalPoint",style:"font-size: 12px;text-align:center;"}
     ]}
    ,{tag:"th",elems:[
      {tag:"label",style:"font-size: 12px;"}
     ]}
    ]}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_question_info",style:"display:none;",elems:[
  {tag:"div",style:"padding: 4px;background: #5fc2f5;color: #FFF;font-weight: bold;",elems:[
   {tag:"input",type:"hidden","data-db-key":"questionId",name:"questionId"}
  ,{tag:"input",type:"hidden","data-db-key":"detailsCnt",name:"detailsCnt"}
  ,{tag:"label","data-db-key":"questionName",name:"questionName"}
  ,{tag:"label","data-db-key":"questionTarget",name:"questionTarget"}
  ]}
 ,{tag:"div",style:"background: #f1f1f1;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.22);",elems:[
   {tag:"table",id:"tbl_question_dtl_list",style:"width:100%;",list_id:"tbl_question_dtl_list",elems:[
    {tag:"tHead",elems:[
     {tag:"tr",elems:[
      {tag:"th",elems:[
       {tag:"label","data-db-key":"detailsNo",name:"detailsNo",style:"font-size: 12px;width:30px;"}
      ]}
     ,{tag:"th",style:"text-align:left;",elems:[
       {tag:"label","data-db-key":"questionInfo",name:"questionInfo",style:"font-size: 12px;"}
      ]}
     ]}
    ]}
   ,{tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"td",style:"width:30px;",colSpan:"2",elems:[
       {tag:"input",type:"hidden","data-db-key":"questionId",name:"questionId"}
      ,{tag:"input",type:"hidden","data-db-key":"detailsNo",name:"detailsNo"}
      ,{tag:"input",type:"hidden","data-db-key":"choicesType",name:"choicesType"}
      ,{tag:"label","data-db-key":"choicesInfo",for:"questionRadio",className:"radio",style:"display:none;",elems:[
        {tag:"input",type:"radio",name:"questionRadio",style:"display:none;"}
       ]}
      ,{tag:"label","data-db-key":"choicesInfo",for:"questionCheck",className:"check",style:"display:none;",elems:[
        {tag:"input",type:"checkbox",name:"questionCheck",style:"display:none;"}
       ]}
      ,{tag:"input",type:"hidden","data-db-key":"correct",name:"correct",style:"display:none;"}
      ,{tag:"textarea","data-db-key":"choicesInfo",name:"choicesInfo",style:"display:none;font-size: 12px;width:100%;padding-top:12px;height:200px;"}
      ,{tag:"img",name:"choicesImg",style:"display:none;width:100%;"}
      ]}
     ]}
    ]}
   ]}
  ]}
 ,{tag:"div",className:"ui-grid-a",elems:[
   {tag:"div",className:"ui-block-a",elems:[
    {tag:"a",text:"戻る",id:"btn_back",className:"ui-btn ui-corner-all"}
   ]}
  ,{tag:"div",className:"ui-block-b",elems:[
    {tag:"a",text:"ＯＫ",id:"btn_next",className:"ui-btn ui-corner-all",disabled:"disabled"}
   ]}
  ]}
 ]}
,{tag:"div",id:"div_question_result",style:"display:none;",elems:[
  {tag:"div",style:"padding: 4px;background: #5fc2f5;color: #FFF;font-weight: bold;",elems:[
   {tag:"input",type:"hidden","data-db-key":"questionId",name:"questionId"}
  ,{tag:"input",type:"hidden","data-db-key":"detailsCnt",name:"detailsCnt"}
  ,{tag:"label","data-db-key":"questionName",name:"questionName"}
  ,{tag:"label","data-db-key":"questionTarget",name:"questionTarget"}
  ]}
 ,{tag:"div",style:"background: #f1f1f1;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.22);padding-bottom:50px;",elems:[
   {tag:"table",id:"tbl_question_result_list",style:"width:100%;",list_id:"tbl_question_result_list",elems:[
    {tag:"tBody",elems:[
     {tag:"tr",elems:[
      {tag:"th",style:"width:50px;",elems:[
       {tag:"label","data-db-key":"detailsNo",name:"detailsNo",style:"font-size: 12px;display: inline-block;"}
      ,{tag:"label",text:"／",style:"font-size: 12px;display: inline-block;"}
      ,{tag:"label","data-db-key":"detailsTotal",name:"detailsTotal",style:"font-size: 12px;display: inline-block;"}
      ]}
     ,{tag:"th",style:"text-align:left;",elems:[
       {tag:"label","data-db-key":"questionInfo",name:"questionInfo",style:"font-size: 12px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td"}
     ,{tag:"td",elems:[
       {tag:"label","data-db-key":"status",name:"status",style:"font-size: 12px;display: inline-block;"}
      ,{tag:"label",text:"実施回数：",style:"font-size: 12px;display: inline-block;margin-left:10px;"}
      ,{tag:"label","data-db-key":"execCount",name:"execCount",style:"font-size: 12px;display: inline-block;"}
      ,{tag:"label",text:"最終実施日時：",style:"font-size: 12px;display: inline-block;margin-left:10px;"}
      ,{tag:"label","data-db-key":"lastTs",name:"lastTs",style:"font-size: 12px;display: inline-block;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td"}
     ,{tag:"td",style:"color: #5d627b;background: white;border-top: solid 3px #5d627b;box-shadow: 0 3px 5px rgba(0, 0, 0, 0.22);",elems:[
       {tag:"input",type:"hidden","data-db-key":"choicesType",name:"choicesType"}
      ,{tag:"label",text:"解説：",style:"font-size: 12px;display: inline-block;"}
      ,{tag:"label","data-db-key":"commentary",name:"commentary",style:"font-size: 12px;margin-top:10px;"}
      ]}
     ]}
    ,{tag:"tr",elems:[
      {tag:"td",style:"border-top:solid silver 1px;",colSpan:"2"}
     ]}
    ]}
   ]}
  ]}
 ]}
]}
];

