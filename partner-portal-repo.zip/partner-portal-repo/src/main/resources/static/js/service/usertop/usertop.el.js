//作成日時：2019/06/07 23:28:48
//作成者：Gao JiaYi
var _els_menu = new S_ElsUtil();
//
_els_menu.DATA = [
{tag:"div",id:"menubar",style:"margin-right:2px;",elems:[
 {tag:"ul","data-role":"listview","data-inset":"true",elems:[
  {tag:"li","data-icon":"false",elems:[
   {tag:"a",id:"a_password",style:"border-color:darkgray;",elems:[
    {tag:"label",name:"password",text:"パスワード",style:"font-size:12px;margin:0px;"},
    {tag:"input",type:"hidden",name:"applyId",value:"s00f003"}
   ]}
  ]},
  {tag:"li","data-icon":"false",elems:[
   {tag:"a",id:"a_logout",style:"border-color:darkgray;",elems:[
    {tag:"label",name:"logout",text:"ログアウト",style:"font-size:12px;margin:0px;"}
   ]}
  ]}
 ]}
]}
];

