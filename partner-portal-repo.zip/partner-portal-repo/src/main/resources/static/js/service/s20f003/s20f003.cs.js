/*************************
 * S20F003-資格情報
 * 画面初期ロード
 *************************/
function _init() {
    try {
        // 初期化
        $s.s20f003 = new s20f003_util();
        $("#h_title").text("資格情報");
        // 初期検索
        $s.s20f003._search();
    } catch (e) { alert(e.message);}
};

/**
 * ローカル関数オブジェクト（コンストラクタ）.
 * */
var s20f003_util = function(){
    if ((this instanceof s20f003_util) == false) {
        throw new Error("インスタンス生成失敗しました。");
    }
    // イベント
    this.event_init();
    if ($s._objs.isTarget == true) {
        $("#div_terget").css("display", "");
        $("#tergetUser").text($s._objs.userName);
    }
};
/**
 * イベントの初期化
 * */
s20f003_util.prototype.event_init = function(e) {
	try {
		$(document).on('click', '#h_title', function(e){ $s.s20f003._ctrlEditView(this); });
	    // クリック_新規
	    $(document).on('click', '#a_add', function(e){ $s.s20f003._ctrlEditView(this); });
	    // 一覧へ戻る
	    $(document).on('click', '#a_return', function(e){
	    	location.href=$s.context + "/user/apply?applyId=s00f004";
	    });
	    // クリック_行選択
	    $(document).on('click', '[data-db-key=selTr]', function(e){ $s.s20f003._selTr(this); });
	    // クリック_編集リンク
	    $(document).on('click', '[name=a_edit]', function(e){ $s.s20f003._ctrlEditView(this); });
	    // クリック_登録ボタン
	    $(document).on('click', '#btn_update', function(e){ $s.s20f003._update(this); });
	    // クリック_削除ボタン
	    $(document).on('click', '#btn_delete', function(e){ $s.s20f003._delete(this); });
	    // クリック_戻るボタン
	    $(document).on('click', '#btn_return', function(e){ $s.s20f003._ctrlEditView(this); });
	} catch (e) {
		setTimeout($s.apply._showPopup({title:"メッセージ", msg:e.message, type:"エラー発生"}), 300);
		jQuery.mobile.loading('hide');
	}
};

/**
 * 資格情報一覧検索.
 *
 * @param el イベント発火エレメント
 *  */
s20f003_util.prototype._search = function(el) {
    // 送信データオブジェクト初期化
    var callback = {
        done : function(data, status, xhr){
            // 取得データ設定
            $s.com.set_val($("#div_qua_info_edit"), data);
            if ($s._objs.canEdit == false) {
                $s.com.view_mode($("#div_qua_info_edit")[0]);
            }
        }
    };
    $s.com.ajax("GET", "_search", {}, callback);
};

/**
 * 資格詳細情報取得.
 *
 * @param el イベント発火エレメント
 *  */
s20f003_util.prototype._details = function(el) {
    // 送信データオブジェクト初期化
    var send_data = {
        gakkouMei : $(el).closest("tr").find("[data-db-key=sikakuMei]").text(),
		sequence : $(el).closest("tr").find("[data-db-key=sequence]").val()
    };
    // 成功時のコールバック
    var callback = {
        done : function(data, status, xhr){
            // 取得データ設定
            $s.com.set_val($("#tbl_qua_info"), data.tbl_qua_list);
        }
    };
    $s.com.ajax("GET", "_details", send_data, callback);
};


/**
 * 資格情報登録更新.
 * */
s20f003_util.prototype._update = function(el) {
	var quaCheckList = [];
	$("#applycationForm :input").each(function(index, el) {
	    if ($(el).prop("validate")) quaCheckList[quaCheckList.length] = el.name;
	});
    // 標準入力チェック
	if ($s.com.get_validate(quaCheckList, "#applycationForm") == false) {
		$s.apply._showPopup({title:"入力エラー", msg:"入力エラーがありました。ご確認ください。"});
	    return;
	}
	var opt = {title: "確認", msg:"登録します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
	    // 送信データ取得
        var send_data = {};
        $("table#tbl_qua_info [data-db-key]").each(function(index, el){ $s.com.getSendData(send_data, el); });
        // 成功時のコールバック
        var callback = {
        	done : function(data, status, xhr){
                if (data.msg) {
                    $s.s20f003._search();
                    $s.s20f003._ctrlEditView($("#btn_return")[0]);
                }
        	}
        };
        // 更新処理実施
	    $s.com.ajax("POST", "_update", send_data, callback);
	}
    $s.apply._showPopup(opt);
};

/**
 * 資格情報削除.
 * */
s20f003_util.prototype._delete = function(el) {
	var opt = {title: "確認", msg:"削除します。よろいですか？", type:"confirm"};
	opt.fnc_ok = function(el) {
        var send_data = {
				gakkouMei:$("table#tbl_qua_info [data-db-key=sikakuMei]").val(),
				sequence:$("table#tbl_qua_info [data-db-key=sequence]").val()
		};
        var callback = {
            done : function(data, status, xhr){
                if (data.msg) {
                    $s.s20f003._search();
                    $s.s20f003._ctrlEditView($("#btn_return")[0]);
                }
            }
        };
	    $s.com.ajax("POST", "_delete", send_data, callback);
	}
    $s.apply._showPopup(opt);
};
s20f003_util.prototype._selTr = function(el) {
	var edit = $(el).find("#a_edit");
	if (edit) {
		$s.s20f003._ctrlEditView(edit[0]);
	}
};

/**
 * 編集画面表示制御
 *
 * @param el イベント発火エレメント
 *  */
s20f003_util.prototype._ctrlEditView = function(el) {
	// 入力情報クリア
	$s.com.inputClear($("#div_qua_edit"));
    if (el.id == "a_add") {
        // 新規モード
    	$s.s20f003.mode = "create";
    } else if (el.id == "a_edit") {
        // 編集モード
    	$s.s20f003.mode = "edit";
        // 対象従業員の学歴情報取得
        this._details(el);
    } else if (el.id == "btn_return") {
    	$s.s20f003.mode = "list";
        $s.s20f003._search();
    }

    // 表示制御
    if ($s.s20f003.mode == "list") {
        $("#div_qua_list").css("display","block");
        $("#div_qua_edit").css("display","none");
        $("#h_title").text("資格一覧");
    } else {
        $("#div_qua_list").css("display","none");
        $("#div_qua_edit").css("display","block");
        $("#h_title").text("資格詳細");
    }
};